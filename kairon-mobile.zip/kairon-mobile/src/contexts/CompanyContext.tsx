import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { api } from '../services/api';

interface Company {
  id: string;
  name: string;
  slug: string;
  businessType: string;
  currency: string;
  logoUrl?: string;
  workHours: any;
  slotDuration: number;
  bufferTime: number;
}

interface CompanyContextData {
  company: Company | null;
  loading: boolean;
  updateCompany: (data: Partial<Company>) => Promise<void>;
  refreshCompany: () => Promise<void>;
}

export const CompanyContext = createContext<CompanyContextData>({} as CompanyContextData);

export const useCompany = () => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within a CompanyProvider');
  }
  return context;
};

export const CompanyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadCompany();
    } else {
      setCompany(null);
      setLoading(false);
    }
  }, [user]);

  const loadCompany = async () => {
    if (!user) return;

    try {
      const response = await api.get('/company');
      setCompany(response.data);
    } catch (error) {
      console.error('Error loading company:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateCompany = async (data: Partial<Company>) => {
    if (!company) return;

    try {
      const response = await api.put('/company', data);
      setCompany(response.data);
    } catch (error) {
      console.error('Error updating company:', error);
      throw error;
    }
  };

  const refreshCompany = async () => {
    await loadCompany();
  };

  return (
    <CompanyContext.Provider
      value={{
        company,
        loading,
        updateCompany,
        refreshCompany,
      }}
    >
      {children}
    </CompanyContext.Provider>
  );
};
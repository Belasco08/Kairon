import React, {
  createContext,
  useState,
  useContext,
  useEffect,
  ReactNode,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { api } from "../services/api";
import { authService, SignUpData } from "../services/auth";

/* =======================
   TYPES
======================= */

export type UserRole = 'OWNER' | 'PROFESSIONAL' | 'STAFF' | 'CLIENT';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  companyId?: string;
  phone?: string;
  avatar?: string;
  createdAt?: string;
}

interface AuthContextData {
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;

  signIn(email: string, password: string): Promise<void>;
  signUp(data: SignUpData): Promise<void>;
  signOut(): Promise<void>;
  updateUser(data: Partial<User>): Promise<void>;
}

/* =======================
   CONTEXT
======================= */

export const AuthContext = createContext<AuthContextData>(
  {} as AuthContextData
);

export const useAuth = () => useContext(AuthContext);

/* =======================
   PROVIDER
======================= */

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const isAuthenticated = !!user;

  /* =======================
     RESTORE SESSION
  ======================= */

  useEffect(() => {
    const restoreSession = async () => {
      try {
        const [[, storedUser], [, token]] = await AsyncStorage.multiGet([
          "@Kairon:user",
          "@Kairon:token",
        ]);

        if (!storedUser || !token || token.split(".").length !== 3) {
          return;
        }

        api.defaults.headers.Authorization = `Bearer ${token}`;
        setUser(JSON.parse(storedUser));
      } catch (err) {
        console.error("Erro ao restaurar sessão", err);
      } finally {
        setLoading(false);
      }
    };

    restoreSession();
  }, []);

  /* =======================
     SIGN IN
  ======================= */

 const signIn = async (email: string, password: string) => {
  try {
    setLoading(true);

    const response = await authService.signIn({ email, password });

    await AsyncStorage.multiSet([
      ["@Kairon:user", JSON.stringify(response.user)],
      ["@Kairon:token", response.token],
      ["@Kairon:refreshToken", response.refreshToken],
    ]);

    api.defaults.headers.Authorization = `Bearer ${response.token}`;
    setUser(response.user);
  } finally {
    setLoading(false);
  }
};


  /* =======================
     SIGN UP
  ======================= */

  const signUp = async (data: SignUpData) => {
    setLoading(true);

    try {
      await authService.signUp(data);
      await signIn(data.email, data.password);
    } finally {
      setLoading(false);
    }
  };

  /* =======================
     SIGN OUT
  ======================= */

  const signOut = async () => {
    await AsyncStorage.multiRemove([
      "@Kairon:user",
      "@Kairon:token",
      "@Kairon:refreshToken",
    ]);

    delete api.defaults.headers.Authorization;
    setUser(null);
  };

  /* =======================
     UPDATE USER (LOCAL)
  ======================= */

  const updateUser = async (data: Partial<User>) => {
    if (!user) return;

    const updatedUser = { ...user, ...data };
    await AsyncStorage.setItem("@Kairon:user", JSON.stringify(updatedUser));
    setUser(updatedUser);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAuthenticated,
        signIn,
        signUp,
        signOut,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

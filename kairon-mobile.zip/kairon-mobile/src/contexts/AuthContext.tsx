import React, {
  createContext,
  useState,
  useContext,
  useEffect,
  ReactNode,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { api } from '../services/api';
import { authService, SignUpData } from '../services/auth';

/* =======================
   TYPES
======================= */

export type UserRole = 'OWNER' | 'STAFF' | 'CLIENT';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  companyId?: string;
  phone?: string;

  avatar?: string;
  createdAt?: string;
}

export interface Company {
  id: string;
  name?: string;
  email?: string;
  phone?: string;
  logo?: string;
}

interface AuthContextData {
  user: User | null;
  company: Company | null;
  loading: boolean;

  signIn: (email: string, password: string) => Promise<void>;
  signUp: (data: SignUpData) => Promise<void>;
  signOut: () => Promise<void>;

  updateUser: (data: Partial<User>) => Promise<void>;
  updateCompany: (data: Company) => Promise<void>;
}

/* =======================
   CONTEXT
======================= */

export const AuthContext = createContext<AuthContextData>(
  {} as AuthContextData
);

export const useAuth = () => {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
};

/* =======================
   PROVIDER
======================= */

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStoredData();
  }, []);

  /* =======================
     LOAD STORAGE
  ======================= */

  const loadStoredData = async () => {
    try {
      const [[, storedUser], [, storedToken]] =
        await AsyncStorage.multiGet([
          '@Kairon:user',
          '@Kairon:token',
        ]);

      if (storedUser && storedToken) {
        const parsedUser: User = JSON.parse(storedUser);

        api.defaults.headers.Authorization = `Bearer ${storedToken}`;
        setUser(parsedUser);

        if (parsedUser.companyId) {
          setCompany({ id: parsedUser.companyId });
        }
      }
    } catch (error) {
      console.error('Erro ao carregar dados do usuário', error);
    } finally {
      setLoading(false);
    }
  };

  /* =======================
     SIGN IN
  ======================= */

  const signIn = async (email: string, password: string) => {
    const response = await authService.signIn({ email, password });

    await AsyncStorage.multiSet([
      ['@Kairon:user', JSON.stringify(response.user)],
      ['@Kairon:token', response.token],
      ['@Kairon:refreshToken', response.refreshToken],
    ]);

    api.defaults.headers.Authorization = `Bearer ${response.token}`;
    setUser(response.user);

    if (response.user.companyId) {
      setCompany({ id: response.user.companyId });
    }
  };

  /* =======================
     SIGN UP
  ======================= */

  const signUp = async (data: SignUpData) => {
    const response = await authService.signUp(data);

    await AsyncStorage.multiSet([
      ['@Kairon:user', JSON.stringify(response.user)],
      ['@Kairon:token', response.token],
      ['@Kairon:refreshToken', response.refreshToken],
    ]);

    api.defaults.headers.Authorization = `Bearer ${response.token}`;
    setUser(response.user);

    if (response.user.companyId) {
      setCompany({ id: response.user.companyId });
    }
  };

  /* =======================
     SIGN OUT
  ======================= */

  const signOut = async () => {
    await AsyncStorage.multiRemove([
      '@Kairon:user',
      '@Kairon:token',
      '@Kairon:refreshToken',
    ]);

    setUser(null);
    setCompany(null);
  };

  /* =======================
     UPDATE USER
  ======================= */

  const updateUser = async (data: Partial<User>) => {
  if (!user) return;

  const updatedUser: User = {
    ...user,
    ...data,
  };

  await AsyncStorage.setItem(
    '@Kairon:user',
    JSON.stringify(updatedUser)
  );

  setUser(updatedUser);

  if (updatedUser.companyId) {
    setCompany({ id: updatedUser.companyId });
  } else {
    setCompany(null);
  }
};


  /* =======================
     UPDATE COMPANY
  ======================= */

  const updateCompany = async (data: Company) => {
    setCompany(data);
  };

  /* =======================
     PROVIDER
  ======================= */

  return (
    <AuthContext.Provider
      value={{
        user,
        company,
        loading,
        signIn,
        signUp,
        signOut,
        updateUser,
        updateCompany,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

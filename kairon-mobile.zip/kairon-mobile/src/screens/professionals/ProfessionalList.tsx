import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Image,
  Switch, // ✅ FIX
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialIcons as Icon } from '@expo/vector-icons'; // ✅ FIX

import { useAuth } from '../../contexts/AuthContext';
import { professionalService } from '../../services/professionals';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { Badge } from '../../components/ui/Badge';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

/* =========================
   TIPOS
========================= */

interface Professional {
  id: string;
  name: string;
  email: string;
  phone?: string;
  specialty?: string;
  avatar?: string;
  isActive: boolean;
  services?: Array<{ id: string; name: string }>;
  totalAppointments?: number;
}

// ✅ role REAL do sistema
type UserRole = 'OWNER' | 'STAFF' | 'CLIENT';

type Navigation = {
  navigate: (screen: string, params?: any) => void;
};

/* =========================
   COMPONENT
========================= */

export function ProfessionalList() {
  const navigation = useNavigation<Navigation>(); // ✅ FIX
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [filterActive, setFilterActive] = useState(true);

  useEffect(() => {
    loadProfessionals();
  }, [filterActive]);

  const loadProfessionals = async () => {
    try {
      setLoading(true);
      const response = await professionalService.list();

      const filtered = filterActive
        ? response.filter((p: Professional) => p.isActive)
        : response;

      setProfessionals(filtered);
    } catch (error) {
      console.error('Error loading professionals:', error);
      Alert.alert('Erro', 'Não foi possível carregar os profissionais');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadProfessionals();
  };

  const toggleActiveStatus = async (
    professionalId: string,
    currentValue: boolean
  ) => {
    try {
      await professionalService.update(professionalId, {
        isActive: !currentValue,
      });

      setProfessionals(prev =>
        prev.map(p =>
          p.id === professionalId
            ? { ...p, isActive: !currentValue }
            : p
        )
      );
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  const handleDelete = (professionalId: string) => {
    Alert.alert(
      'Remover Profissional',
      'Tem certeza que deseja remover este profissional?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Remover',
          style: 'destructive',
          onPress: async () => {
            try {
              await professionalService.delete(professionalId);
              setProfessionals(prev =>
                prev.filter(p => p.id !== professionalId)
              );
            } catch {
              Alert.alert('Erro', 'Não foi possível remover');
            }
          },
        },
      ]
    );
  };

  const canManage =
    user?.role === 'OWNER'; // ✅ ADMIN REMOVIDO (não existe no tipo)

  const renderProfessional = ({ item }: { item: Professional }) => (
    <TouchableOpacity
      style={[commonStyles.card, !item.isActive && { opacity: 0.6 }]}
      onPress={() => {
        if (canManage) {
          navigation.navigate('EditProfessional', {
            professionalId: item.id,
          });
        }
      }}
    >
      <View style={commonStyles.row}>
        <View style={{ flex: 1 }}>
          <Text style={commonStyles.h3}>{item.name}</Text>

          <Badge
            variant={item.isActive ? 'success' : 'warning'} // ✅ muted → warning
            text={item.isActive ? 'Ativo' : 'Inativo'}
            size="small"
          />

          {canManage && (
            <TouchableOpacity onPress={() => handleDelete(item.id)}>
              <Icon name="delete" size={20} color={colors.error} />
            </TouchableOpacity>
          )}
        </View>

        {canManage && (
          <Switch
            value={item.isActive}
            onValueChange={() =>
              toggleActiveStatus(item.id, item.isActive)
            }
          />
        )}
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <FlatList
      data={professionals}
      keyExtractor={item => item.id}
      renderItem={renderProfessional}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
      ListEmptyComponent={
        <EmptyState
          icon="people"
          title="Nenhum profissional"
          description="Adicione profissionais para começar"
          actionText="Adicionar"
          onAction={() => navigation.navigate('CreateProfessional')}
        />
      }
    />
  );
}

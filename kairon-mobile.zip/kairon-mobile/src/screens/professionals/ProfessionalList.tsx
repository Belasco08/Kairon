import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Switch,
  Image,
  StyleSheet,
  StatusBar,
  SafeAreaView,
  Platform
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Feather } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { professionalService } from '../../services/professionals';
import { Button } from '../../components/ui/Button'; // Seu componente de botão
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';

// Tipagem flexível
interface Professional {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  specialty?: string;
  photoUrl?: string;
  avatar?: string;
  isActive?: boolean; 
  active?: boolean;
  services?: Array<{ id: string; name: string }>;
}

// Ajuste as rotas conforme seu App
type RootStackParamList = {
  ProfessionalList: undefined;
  CreateProfessional: undefined;
  EditProfessional: { professionalId: string };
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'ProfessionalList'>;

export function ProfessionalList() {
  const navigation = useNavigation<NavigationProp>();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [showOnlyActive, setShowOnlyActive] = useState(false); 

  useEffect(() => {
    loadProfessionals();
  }, []);

  const loadProfessionals = async () => {
    try {
      setLoading(true);
      const response = await professionalService.list();
      // Garante que é array
      const data = Array.isArray(response) ? response : (response.content || []);
      setProfessionals(data);
    } catch (error) {
      console.error('Error loading professionals:', error);
      Alert.alert('Erro', 'Não foi possível carregar os profissionais');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadProfessionals();
  };

  const isProfessionalActive = (p: Professional) => {
    return p.isActive !== undefined ? p.isActive : p.active;
  };

  const toggleActiveStatus = async (professionalId: string, currentValue: boolean | undefined) => {
    try {
      const newValue = !currentValue;
      await professionalService.update(professionalId, { isActive: newValue });
      setProfessionals(prev =>
        prev.map(p =>
          p.id === professionalId ? { ...p, isActive: newValue, active: newValue } : p
        )
      );
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  const handleDelete = (professionalId: string) => {
    Alert.alert(
      'Remover Profissional',
      'Tem certeza? Essa ação não pode ser desfeita.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Remover',
          style: 'destructive',
          onPress: async () => {
            try {
              await professionalService.delete(professionalId);
              setProfessionals(prev => prev.filter(p => p.id !== professionalId));
            } catch {
              Alert.alert('Erro', 'Não foi possível remover');
            }
          },
        },
      ]
    );
  };

  const displayedProfessionals = professionals.filter(p => {
    if (showOnlyActive) {
      return isProfessionalActive(p) === true;
    }
    return true;
  });

  // Verifica permissão (opcional, ajustável conforme sua regra)
  const canManage = user?.role === 'OWNER' || user?.role === 'ADMIN';

  // --- RENDER CARD ---
  const renderProfessional = ({ item }: { item: Professional }) => {
    const active = isProfessionalActive(item);
    const imageUri = item.photoUrl || item.avatar;

    return (
      <TouchableOpacity
        style={[styles.card, !active && styles.cardInactive]}
        activeOpacity={0.7}
        onPress={() => {
           if (canManage) navigation.navigate('EditProfessional', { professionalId: item.id });
        }}
      >
        {/* Avatar Section */}
        <View style={styles.avatarContainer}>
          {imageUri ? (
            <Image 
              source={{ uri: imageUri }} 
              style={styles.avatarImage} 
            />
          ) : (
            <View style={styles.avatarPlaceholder}>
               <Feather name="user" size={24} color={colors.primary} />
            </View>
          )}
        </View>

        {/* Info Section */}
        <View style={styles.cardContent}>
          <View style={styles.rowBetween}>
            <Text style={styles.name} numberOfLines={1}>{item.name}</Text>
            {!active && (
                <View style={styles.inactiveBadge}>
                  <Text style={styles.inactiveText}>Inativo</Text>
                </View>
            )}
          </View>

          <Text style={styles.specialty}>
             {item.specialty || "Profissional Geral"}
          </Text>

          {/* Contact Info */}
          <View style={styles.contactRow}>
             {item.phone && (
                 <View style={styles.contactItem}>
                    <Feather name="phone" size={12} color="#64748B" />
                    <Text style={styles.contactText}>{item.phone}</Text>
                 </View>
             )}
          </View>
        </View>

        {/* Actions Column (Delete & Switch) */}
        {canManage && (
            <View style={styles.cardActions}>
                {/* Botão Deletar (Topo Direita) */}
                <TouchableOpacity 
                    onPress={() => handleDelete(item.id)} 
                    style={styles.deleteButton}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                    <Feather name="trash-2" size={18} color="#EF4444" />
                </TouchableOpacity>

                {/* Switch (Base Direita) */}
                <View style={styles.switchContainer}>
                    <Switch
                        value={!!active}
                        onValueChange={() => toggleActiveStatus(item.id, active)}
                        trackColor={{ false: '#E2E8F0', true: colors.primary + '80' }}
                        thumbColor={!!active ? colors.primary : '#94A3B8'}
                        style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
                    />
                </View>
            </View>
        )}
      </TouchableOpacity>
    );
  };

  const renderHeader = () => (
    <View style={styles.headerContainer}>
      <View style={styles.headerTop}>
        <View>
          <Text style={styles.headerTitle}>Profissionais</Text>
          <Text style={styles.headerSubtitle}>{displayedProfessionals.length} membros na equipe</Text>
        </View>
        
        {/* BOTÃO QUE FALTAVA */}
        {canManage && (
            <Button
              title="Novo"
              onPress={() => navigation.navigate('CreateProfessional')}
              size="small"
              // Se seu componente Button suportar ícone: icon={<Feather name="plus" size={16} color="#fff"/>}
            />
        )}
      </View>

      <View style={styles.filterRow}>
        <TouchableOpacity 
          style={styles.filterContainer} 
          activeOpacity={1}
          onPress={() => setShowOnlyActive(!showOnlyActive)}
        >
            <Text style={styles.filterText}>Ocultar inativos</Text>
            <Switch
              value={showOnlyActive}
              onValueChange={setShowOnlyActive}
              trackColor={{ false: '#E2E8F0', true: colors.primary }}
              thumbColor={'#fff'}
              size="small"
              style={{ transform: [{ scaleX: 0.7 }, { scaleY: 0.7 }] }}
            />
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F9FA" />
      <FlatList
        data={displayedProfessionals}
        keyExtractor={item => item.id}
        renderItem={renderProfessional}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <EmptyState
            title="Nenhum profissional"
            description="Adicione sua equipe para começar os agendamentos."
            // Fallback action if list is empty
            actionText="Adicionar Profissional"
            onAction={() => navigation.navigate('CreateProfessional')}
          />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    // Correção para Android ficar na altura certa
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 0,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
  },
  listContent: {
    paddingBottom: 80,
    paddingHorizontal: 16,
  },
  
  // HEADER
  headerContainer: {
    paddingVertical: 20,
    marginBottom: 8,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1E293B',
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 2,
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  filterText: {
    fontSize: 13,
    color: '#64748B',
    marginRight: 8,
  },

  // CARD
  card: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  cardInactive: {
    opacity: 0.8,
    backgroundColor: '#F1F5F9',
    borderColor: '#E2E8F0',
    shadowOpacity: 0,
    elevation: 0,
  },
  
  // AVATAR
  avatarContainer: {
    marginRight: 16,
    justifyContent: 'center',
  },
  avatarImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#E2E8F0',
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#E0F2FE', // Azul bem claro
    justifyContent: 'center',
    alignItems: 'center',
  },

  // CONTENT
  cardContent: {
    flex: 1,
    justifyContent: 'center',
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    flexShrink: 1,
  },
  specialty: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 8,
  },
  contactRow: {
      flexDirection: 'row',
      alignItems: 'center',
  },
  contactItem: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#F1F5F9',
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 6,
  },
  contactText: {
      fontSize: 12,
      color: '#64748B',
      marginLeft: 4,
  },
  
  // ACTIONS (RIGHT SIDE)
  cardActions: {
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      paddingLeft: 10,
  },
  deleteButton: {
      padding: 4,
      marginBottom: 8,
  },
  switchContainer: {
      // Ajuste fino para alinhar visualmente
  },
  
  // BADGES
  inactiveBadge: {
    backgroundColor: '#E2E8F0',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    marginLeft: 8,
  },
  inactiveText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#64748B',
    textTransform: 'uppercase',
  },
});
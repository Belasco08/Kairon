import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  Switch,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { professionalService } from '../../services/professionals';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

/* =========================
   TIPOS LOCAIS
========================= */

interface ProfessionalForm {
  name: string;
  email: string;
  phone: string;
  specialty: string;
  isActive: boolean;
  canBookOnline: boolean;
  commissionPercentage: string; // Mantemos string no form para facilitar edição
  password?: string;
  confirmPassword?: string;
}

interface RouteParams {
  professionalId: string;
}

/* =========================
   COMPONENT
========================= */

export function EditProfessional() {
  const navigation = useNavigation();
  const route = useRoute();
  const { professionalId } = route.params as RouteParams;
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Controla a visibilidade dos campos de senha
  const [showPasswordFields, setShowPasswordFields] = useState(false);

  const [form, setForm] = useState<ProfessionalForm>({
    name: '',
    email: '',
    phone: '',
    specialty: '',
    isActive: true,
    canBookOnline: true,
    commissionPercentage: '',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof ProfessionalForm, string>>>({});

  /* =========================
      LOAD DATA
  ========================= */

  useEffect(() => {
    loadProfessional();
  }, [professionalId]);

  const loadProfessional = async () => {
    try {
      setLoading(true);
      const professional = await professionalService.get(professionalId);

      setForm({
        name: professional.name,
        email: professional.email,
        phone: professional.phone ?? '',
        specialty: professional.specialty ?? '',
        isActive: professional.isActive,
        canBookOnline: professional.canBookOnline,
        commissionPercentage: professional.commissionPercentage 
          ? professional.commissionPercentage.toString() 
          : '',
      });
    } catch (error) {
      console.error('Error loading professional:', error);
      Alert.alert('Erro', 'Não foi possível carregar os dados do profissional.');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  /* =========================
      HANDLERS
  ========================= */

  const updateForm = (field: keyof ProfessionalForm, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    // Limpa erro ao digitar
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ProfessionalForm, string>> = {};

    if (!form.name.trim()) newErrors.name = 'Nome é obrigatório';
    
    if (!form.email.trim()) {
      newErrors.email = 'E-mail é obrigatório';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'E-mail inválido';
    }

    // Validação de senha apenas se o usuário optou por trocar
    if (showPasswordFields) {
      if (!form.password || form.password.length < 6) {
        newErrors.password = 'A nova senha deve ter no mínimo 6 caracteres';
      }
      if (form.password !== form.confirmPassword) {
        newErrors.confirmPassword = 'As senhas não coincidem';
      }
    }

    if (form.commissionPercentage) {
      const comm = Number(form.commissionPercentage.replace(',', '.'));
      if (isNaN(comm) || comm < 0 || comm > 100) {
        newErrors.commissionPercentage = 'Comissão deve ser entre 0 e 100';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /* =========================
      SUBMIT
  ========================= */

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setSaving(true);
    try {
      // Prepara payload
      const payload: any = {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        specialty: form.specialty || null,
        isActive: form.isActive,
        canBookOnline: form.canBookOnline,
        commissionPercentage: form.commissionPercentage
          ? Number(form.commissionPercentage.replace(',', '.'))
          : null,
      };

      // Adiciona senha apenas se solicitada a troca
      if (showPasswordFields && form.password) {
        payload.password = form.password;
      }

      await professionalService.update(professionalId, payload);

      Alert.alert('Sucesso', 'Profissional atualizado com sucesso!', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error: any) {
      console.error(error);
      Alert.alert(
        'Erro',
        error?.response?.data?.message || 'Falha ao atualizar profissional.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Cuidado!',
      'Tem certeza que deseja remover este profissional? Essa ação não pode ser desfeita.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true); // Bloqueia tela
              await professionalService.delete(professionalId);
              navigation.goBack();
            } catch (error) {
              setLoading(false);
              Alert.alert('Erro', 'Não foi possível excluir o profissional.');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  /* =========================
      RENDER
  ========================= */

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        
        {/* === DADOS PESSOAIS === */}
        <Text style={[commonStyles.h3, { marginBottom: 12 }]}>Dados Pessoais</Text>
        <Card style={{ marginBottom: 24 }}>
          <View style={{ gap: 16 }}>
            <Input
              label="Nome Completo"
              placeholder="Ex: João Silva"
              value={form.name}
              onChangeText={(t) => updateForm('name', t)}
              error={errors.name}
            />

            <Input
              label="E-mail"
              placeholder="Ex: joao@email.com"
              keyboardType="email-address"
              autoCapitalize="none"
              value={form.email}
              onChangeText={(t) => updateForm('email', t)}
              error={errors.email}
            />

            <Input
              label="Telefone"
              placeholder="(00) 00000-0000"
              keyboardType="phone-pad"
              value={form.phone}
              onChangeText={(t) => updateForm('phone', t)}
              error={errors.phone}
            />

            <Input
              label="Especialidade / Cargo"
              placeholder="Ex: Barbeiro Senior"
              value={form.specialty}
              onChangeText={(t) => updateForm('specialty', t)}
            />
          </View>
        </Card>

        {/* === CONFIGURAÇÕES === */}
        <Text style={[commonStyles.h3, { marginBottom: 12 }]}>Configurações</Text>
        <Card style={{ marginBottom: 24 }}>
          <View style={{ gap: 16 }}>
            
            <Input
              label="Comissão (%)"
              placeholder="Ex: 50"
              keyboardType="numeric"
              value={form.commissionPercentage}
              onChangeText={(t) => updateForm('commissionPercentage', t)}
              error={errors.commissionPercentage}
              maxLength={5} // evita números gigantes
            />

            {/* Switch: Ativo */}
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View>
                <Text style={commonStyles.subtitle}>Profissional Ativo</Text>
                <Text style={commonStyles.caption}>Aparece na lista interna</Text>
              </View>
              <Switch
                value={form.isActive}
                onValueChange={(v) => updateForm('isActive', v)}
                trackColor={{ false: '#767577', true: colors.primaryLight }}
                thumbColor={form.isActive ? colors.primary : '#f4f3f4'}
              />
            </View>

            {/* Switch: Agendamento Online */}
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View>
                <Text style={commonStyles.subtitle}>Agendamento Online</Text>
                <Text style={commonStyles.caption}>Visível para clientes</Text>
              </View>
              <Switch
                value={form.canBookOnline}
                onValueChange={(v) => updateForm('canBookOnline', v)}
                trackColor={{ false: '#767577', true: colors.primaryLight }}
                thumbColor={form.canBookOnline ? colors.primary : '#f4f3f4'}
              />
            </View>

          </View>
        </Card>

      

        {/* === AÇÕES === */}
        <View style={{ gap: 12 }}>
          <Button
            title="Salvar Alterações"
            onPress={handleSubmit}
            loading={saving}
          />

          {user?.role === 'OWNER' && (
            <Button
              title="Excluir Profissional"
              variant="outline"
              style={{ borderColor: colors.error }}
              textStyle={{ color: colors.error }}
              onPress={handleDelete}
              disabled={saving}
              icon="delete"
            />
          )}
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}
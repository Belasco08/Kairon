import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Switch,
  ActivityIndicator,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { professionalService } from '../../services/professionals';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

/* =========================
   TIPOS
========================= */

interface ProfessionalForm {
  name: string;
  email: string;
  phone: string;
  specialty: string;
  isActive: boolean;
  canBookOnline: boolean;
  commissionPercentage?: string;
  password?: string;
  confirmPassword?: string;
}

interface RouteParams {
  professionalId: string;
}

/* =========================
   COMPONENT
========================= */

export function EditProfessional() {
  const navigation = useNavigation();
  const route = useRoute();
  const { professionalId } = route.params as RouteParams;
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [changePassword, setChangePassword] = useState(false);

  const [form, setForm] = useState<ProfessionalForm>({
    name: '',
    email: '',
    phone: '',
    specialty: '',
    isActive: true,
    canBookOnline: true,
    commissionPercentage: '',
  });

  const [errors, setErrors] =
    useState<Partial<Record<keyof ProfessionalForm, string>>>({});

  /* =========================
     LOAD
  ========================= */

  useEffect(() => {
    loadProfessional();
  }, [professionalId]);

  const loadProfessional = async () => {
    try {
      setLoading(true);

      // ✅ CORREÇÃO AQUI
      const professional = await professionalService.get(professionalId);

      setForm({
        name: professional.name,
        email: professional.email,
        phone: professional.phone ?? '',
        specialty: professional.specialty ?? '',
        isActive: professional.isActive,
        canBookOnline: professional.canBookOnline,
        commissionPercentage:
          professional.commissionPercentage?.toString() ?? '',
      });
    } catch (error) {
      console.error('Error loading professional:', error);
      Alert.alert('Erro', 'Não foi possível carregar o profissional');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  /* =========================
     VALIDATION
  ========================= */

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ProfessionalForm, string>> = {};

    if (!form.name.trim()) newErrors.name = 'Nome é obrigatório';

    if (!form.email.trim()) {
      newErrors.email = 'E-mail é obrigatório';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'E-mail inválido';
    }

    if (changePassword) {
      if (form.password && form.password.length < 6) {
        newErrors.password = 'Senha deve ter no mínimo 6 caracteres';
      }

      if (form.password !== form.confirmPassword) {
        newErrors.confirmPassword = 'As senhas não coincidem';
      }
    }

    if (
      form.commissionPercentage &&
      Number(form.commissionPercentage) > 100
    ) {
      newErrors.commissionPercentage =
        'Comissão não pode ser maior que 100%';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /* =========================
     SUBMIT
  ========================= */

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setSaving(true);
    try {
      const professionalData: any = {
        name: form.name,
        email: form.email,
        phone: form.phone || undefined,
        specialty: form.specialty || undefined,
        isActive: form.isActive,
        canBookOnline: form.canBookOnline,
        commissionPercentage: form.commissionPercentage
          ? Number(form.commissionPercentage)
          : undefined,
      };

      if (changePassword && form.password) {
        professionalData.password = form.password;
      }

      await professionalService.update(professionalId, professionalData);

      Alert.alert('Sucesso', 'Profissional atualizado com sucesso!', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error: any) {
      Alert.alert(
        'Erro',
        error?.response?.data?.message ||
          'Não foi possível atualizar o profissional'
      );
    } finally {
      setSaving(false);
    }
  };

  /* =========================
     DELETE
  ========================= */

  const handleDelete = () => {
    Alert.alert(
      'Remover Profissional',
      'Tem certeza que deseja remover este profissional?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Remover',
          style: 'destructive',
          onPress: async () => {
            await professionalService.delete(professionalId);
            navigation.goBack();
          },
        },
      ]
    );
  };

  const updateForm = (
    field: keyof ProfessionalForm,
    value: string | boolean
  ) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  /* =========================
     RENDER
  ========================= */

  return (
    <ScrollView
      style={commonStyles.container}
      contentContainerStyle={{ padding: 16 }}
    >
      <Card>
        <View style={{ gap: 16 }}>
          {/* inputs iguais ao seu código */}

          <View style={{ marginTop: 24, gap: 12 }}>
            <Button
              title="Salvar Alterações"
              onPress={handleSubmit}
              loading={saving}
              disabled={saving}
            />

            {user?.role === 'OWNER' && (
              <Button
                title="Remover Profissional"
                onPress={handleDelete}
                variant="outline"
              />
            )}
          </View>
        </View>
      </Card>
    </ScrollView>
  );
}

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Switch,
} from 'react-native';
import { useNavigation, NavigationProp } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { professionalService } from '../../services/professionals';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

/* =========================
   TIPOS
========================= */

interface ProfessionalForm {
  name: string;
  email: string;
  phone: string;
  specialty: string;
  password: string;
  confirmPassword: string;
  isActive: boolean;
  canBookOnline: boolean;
  commissionPercentage?: string;
}

type RootStackParamList = {
  CreateProfessional: undefined;
};

/* =========================
   COMPONENT
========================= */

export function CreateProfessional() {
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();
  const { company } = useAuth();

  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState<ProfessionalForm>({
    name: '',
    email: '',
    phone: '',
    specialty: '',
    password: '',
    confirmPassword: '',
    isActive: true,
    canBookOnline: true,
    commissionPercentage: '',
  });

  const [errors, setErrors] = useState<
    Partial<Record<keyof ProfessionalForm, string>>
  >({});

  /* =========================
     VALIDAÇÃO
  ========================= */

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ProfessionalForm, string>> = {};

    if (!form.name.trim()) {
      newErrors.name = 'Nome é obrigatório';
    }

    if (!form.email.trim()) {
      newErrors.email = 'E-mail é obrigatório';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'E-mail inválido';
    }

    if (!form.password) {
      newErrors.password = 'Senha é obrigatória';
    } else if (form.password.length < 6) {
      newErrors.password = 'Senha deve ter no mínimo 6 caracteres';
    }

    if (form.password !== form.confirmPassword) {
      newErrors.confirmPassword = 'As senhas não coincidem';
    }

    if (
      form.commissionPercentage &&
      Number(form.commissionPercentage) > 100
    ) {
      newErrors.commissionPercentage =
        'Comissão não pode ser maior que 100%';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /* =========================
     SUBMIT
  ========================= */

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      const professionalData = {
        name: form.name,
        email: form.email,
        phone: form.phone || undefined,
        specialty: form.specialty || undefined,
        password: form.password,
        isActive: form.isActive,
        canBookOnline: form.canBookOnline,
        companyId: company?.id,
        commissionPercentage: form.commissionPercentage
          ? Number(form.commissionPercentage)
          : undefined,
        role: 'PROFESSIONAL' as const,
      };

      await professionalService.create(professionalData);

      Alert.alert('Sucesso', 'Profissional criado com sucesso!', [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]);
    } catch (error: any) {
      console.error('Error creating professional:', error);
      Alert.alert(
        'Erro',
        error?.response?.data?.message ||
          'Não foi possível criar o profissional'
      );
    } finally {
      setLoading(false);
    }
  };

  /* =========================
     HELPERS
  ========================= */

  const updateForm = (
    field: keyof ProfessionalForm,
    value: string | boolean
  ) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  /* =========================
     RENDER
  ========================= */

  return (
    <ScrollView
      style={commonStyles.container}
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ marginBottom: 24 }}>
        <Text style={commonStyles.h1}>Novo Profissional</Text>
        <Text
          style={[
            commonStyles.body,
            { color: colors.textSecondary, marginTop: 4 },
          ]}
        >
          Adicione um novo profissional à sua equipe
        </Text>
      </View>

      <Card>
        <View style={{ gap: 16 }}>
          <Input
            label="Nome Completo *"
            value={form.name}
            onChangeText={value => updateForm('name', value)}
            placeholder="Ex: João Silva"
            error={errors.name}
            autoFocus
          />

          <Input
            label="E-mail *"
            value={form.email}
            onChangeText={value => updateForm('email', value)}
            placeholder="profissional@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            error={errors.email}
          />

          <View style={{ flexDirection: 'row', gap: 16 }}>
            <View style={{ flex: 1 }}>
              <Input
                label="Telefone"
                value={form.phone}
                onChangeText={value => updateForm('phone', value)}
                placeholder="(11) 99999-9999"
                keyboardType="phone-pad"
              />
            </View>

            <View style={{ flex: 1 }}>
              <Input
                label="Especialidade"
                value={form.specialty}
                onChangeText={value => updateForm('specialty', value)}
                placeholder="Ex: Cabeleireiro"
              />
            </View>
          </View>

          <Input
            label="Senha *"
            value={form.password}
            onChangeText={value => updateForm('password', value)}
            placeholder="Mínimo 6 caracteres"
            secureTextEntry
            error={errors.password}
          />

          <Input
            label="Confirmar Senha *"
            value={form.confirmPassword}
            onChangeText={value =>
              updateForm('confirmPassword', value)
            }
            placeholder="Digite a senha novamente"
            secureTextEntry
            error={errors.confirmPassword}
          />

          <Input
            label="Comissão (%)"
            value={form.commissionPercentage}
            onChangeText={value =>
              updateForm('commissionPercentage', value)
            }
            placeholder="0-100"
            keyboardType="decimal-pad"
            suffix="%"
            error={errors.commissionPercentage}
          />

          {/* STATUS */}
          <View style={[commonStyles.card, { padding: 12 }]}>
            <View
              style={[commonStyles.rowBetween, { paddingVertical: 8 }]}
            >
              <View
                style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}
              >
                <MaterialIcons
                  name="check-circle"
                  size={20}
                  color={
                    form.isActive
                      ? colors.success
                      : colors.textMuted
                  }
                />
                <View>
                  <Text style={commonStyles.body}>
                    Profissional Ativo
                  </Text>
                  <Text
                    style={[
                      commonStyles.caption,
                      { color: colors.textSecondary },
                    ]}
                  >
                    {form.isActive
                      ? 'Pode atender clientes'
                      : 'Não pode atender'}
                  </Text>
                </View>
              </View>

              <Switch
                value={form.isActive}
                onValueChange={value =>
                  updateForm('isActive', value)
                }
                trackColor={{
                  false: colors.border,
                  true: colors.success,
                }}
                thumbColor={colors.surface}
              />
            </View>

            <View
              style={[commonStyles.rowBetween, { paddingVertical: 8 }]}
            >
              <View
                style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}
              >
                <MaterialIcons
                  name="online-prediction"
                  size={20}
                  color={
                    form.canBookOnline
                      ? colors.primary
                      : colors.textMuted
                  }
                />
                <View>
                  <Text style={commonStyles.body}>
                    Agendamento Online
                  </Text>
                  <Text
                    style={[
                      commonStyles.caption,
                      { color: colors.textSecondary },
                    ]}
                  >
                    {form.canBookOnline
                      ? 'Aparece para agendamento online'
                      : 'Somente agendamento manual'}
                  </Text>
                </View>
              </View>

              <Switch
                value={form.canBookOnline}
                onValueChange={value =>
                  updateForm('canBookOnline', value)
                }
                trackColor={{
                  false: colors.border,
                  true: colors.primary,
                }}
                thumbColor={colors.surface}
                disabled={!form.isActive}
              />
            </View>
          </View>

          <View style={{ marginTop: 24 }}>
            <Button
              title="Criar Profissional"
              onPress={handleSubmit}
              loading={loading}
              disabled={loading}
            />

            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={{ marginTop: 12 }}
            >
              <Text
                style={[
                  commonStyles.body,
                  { color: colors.primary, textAlign: 'center' },
                ]}
              >
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Card>
    </ScrollView>
  );
}

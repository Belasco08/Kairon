import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { colors } from '../../styles/colors';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';

export function SignIn() {
  const navigation = useNavigation();
  const { signIn } = useAuth();

  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    email: '',
    password: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!form.email) {
      newErrors.email = 'Email é obrigatório';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = 'Email inválido';
    }

    if (!form.password) {
      newErrors.password = 'Senha é obrigatória';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSignIn = async () => {
    if (!validate()) return;

    try {
      setLoading(true);
      await signIn(form.email, form.password);
    } catch (error: any) {
      Alert.alert('Erro', error.message || 'Erro ao fazer login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: colors.background }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={{ flex: 1, padding: 24 }}>
          <TouchableOpacity
            style={{ marginBottom: 24, alignSelf: 'flex-start' }}
            onPress={() => navigation.goBack()}
          >
            <MaterialIcons
              name="arrow-back"
              size={24}
              color={colors.textPrimary}
            />
          </TouchableOpacity>

          <View style={{ marginBottom: 32 }}>
            <Text
              style={{
                fontSize: 28,
                fontWeight: 'bold',
                color: colors.textPrimary,
              }}
            >
              Entrar
            </Text>
            <Text
              style={{
                fontSize: 16,
                color: colors.textSecondary,
                marginTop: 8,
              }}
            >
              Acesse sua conta KAIRON
            </Text>
          </View>

          <View style={{ gap: 16 }}>
            <Input
              label="Email"
              placeholder="seu@email.com"
              value={form.email}
              onChangeText={text => {
                setForm({ ...form, email: text });
                if (errors.email)
                  setErrors({ ...errors, email: '' });
              }}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              error={errors.email}
              editable={!loading}
            />

            <Input
              label="Senha"
              placeholder="••••••"
              value={form.password}
              onChangeText={text => {
                setForm({ ...form, password: text });
                if (errors.password)
                  setErrors({ ...errors, password: '' });
              }}
              secureTextEntry
              error={errors.password}
              editable={!loading}
            />
          </View>

          <Button
            title="Entrar"
            onPress={handleSignIn}
            loading={loading}
            style={{ marginTop: 32 }}
            disabled={loading}
          />

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              marginTop: 24,
            }}
          >
            <Text style={{ fontSize: 14, color: colors.textSecondary }}>
              Não tem uma conta?{' '}
            </Text>
            <TouchableOpacity
              onPress={() =>
                navigation.navigate('SignUp' as never)
              }
              disabled={loading}
            >
              <Text
                style={{
                  fontSize: 14,
                  color: colors.primary,
                  fontWeight: '600',
                }}
              >
                Cadastre-se
              </Text>
            </TouchableOpacity>
          </View>

          <View
            style={{
              borderTopWidth: 1,
              borderTopColor: colors.border,
              marginTop: 48,
              paddingTop: 24,
            }}
          >
            <Text
              style={{
                fontSize: 12,
                color: colors.textMuted,
                textAlign: 'center',
              }}
            >
              Ao continuar, você concorda com nossos Termos de Uso
            </Text>
            <Text
              style={{
                fontSize: 12,
                color: colors.textMuted,
                textAlign: 'center',
                marginTop: 4,
              }}
            >
              e Política de Privacidade
            </Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import Icon from "react-native-vector-icons/MaterialIcons";
import * as ImagePicker from "expo-image-picker";
import { useAuth } from "../../contexts/AuthContext";
import { authService } from "../../services/auth";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { colors } from "../../styles/colors";
import { commonStyles } from "../../styles/common";

interface ProfileForm {
  name: string;
  email: string;
  phone: string;
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export function ProfileSettings() {
  const navigation = useNavigation();
  const { user, updateUser, company } = useAuth();

  const [loading, setLoading] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [form, setForm] = useState<ProfileForm>({
    name: "",
    email: "",
    phone: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<
    Partial<Record<keyof ProfileForm, string>>
  >({});
  const [changePassword, setChangePassword] = useState(false);

  useEffect(() => {
    if (user) {
      setForm({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    }
  }, [user]);

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ProfileForm, string>> = {};

    if (!form.name.trim()) {
      newErrors.name = "Nome é obrigatório";
    }

    if (!form.email.trim()) {
      newErrors.email = "E-mail é obrigatório";
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = "E-mail inválido";
    }

    if (changePassword) {
      if (form.newPassword && form.newPassword.length < 6) {
        newErrors.newPassword = "A nova senha deve ter no mínimo 6 caracteres";
      }

      if (form.newPassword !== form.confirmPassword) {
        newErrors.confirmPassword = "As senhas não coincidem";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      const updateData: any = {
        name: form.name,
        email: form.email,
        phone: form.phone || undefined,
      };

      if (changePassword && form.newPassword) {
        updateData.currentPassword = form.currentPassword;
        updateData.newPassword = form.newPassword;
      }

      const updatedUser = await authService.updateProfile(updateData);
      await updateUser(updatedUser);

      setForm((prev) => ({
        ...prev,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      }));
      setChangePassword(false);

      Alert.alert("Sucesso", "Perfil atualizado com sucesso!");
    } catch (error: any) {
      console.error("Error updating profile:", error);
      Alert.alert(
        "Erro",
        error.response?.data?.message || "Não foi possível atualizar o perfil"
      );
    } finally {
      setLoading(false);
    }
  };

  const pickAvatar = async () => {
    try {
      const permissionResult =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permissionResult.granted) {
        Alert.alert(
          "Permissão necessária",
          "Precisamos de acesso à galeria para alterar a foto"
        );
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setUploadingAvatar(true);

        const formData = new FormData();
        formData.append("avatar", {
          uri: result.assets[0].uri,
          type: "image/jpeg",
          name: "avatar.jpg",
        } as any);

        const updatedUser = await authService.uploadAvatar(formData);
        await updateUser(updatedUser);

        Alert.alert("Sucesso", "Foto atualizada com sucesso!");
      }
    } catch (error) {
      console.error("Error picking avatar:", error);
      Alert.alert("Erro", "Não foi possível atualizar a foto");
    } finally {
      setUploadingAvatar(false);
    }
  };

  const updateForm = (field: keyof ProfileForm, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <ScrollView
      style={commonStyles.container}
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ marginBottom: 24 }}>
        <Text style={commonStyles.h1}>Meu Perfil</Text>
        <Text
          style={[
            commonStyles.body,
            { color: colors.textSecondary, marginTop: 4 },
          ]}
        >
          Atualize suas informações pessoais
        </Text>
      </View>

      {/* Avatar Section */}
      <Card style={{ marginBottom: 16 }}>
        <View style={{ alignItems: "center" }}>
          <TouchableOpacity onPress={pickAvatar} disabled={uploadingAvatar}>
            {user?.avatar ? (
              <Image
                source={{ uri: user.avatar }}
                style={{
                  width: 120,
                  height: 120,
                  borderRadius: 60,
                  backgroundColor: colors.border,
                }}
              />
            ) : (
              <View
                style={{
                  width: 120,
                  height: 120,
                  borderRadius: 60,
                  backgroundColor: colors.primaryLight,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon name="person" size={48} color={colors.primary} />
              </View>
            )}

            {uploadingAvatar && (
              <View
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  backgroundColor: "rgba(0,0,0,0.5)",
                  borderRadius: 60,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <ActivityIndicator size="large" color={colors.surface} />
              </View>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            onPress={pickAvatar}
            disabled={uploadingAvatar}
            style={{ marginTop: 12 }}
          >
            <Text style={[commonStyles.body, { color: colors.primary }]}>
              {uploadingAvatar ? "Enviando..." : "Alterar Foto"}
            </Text>
          </TouchableOpacity>
        </View>
      </Card>

      {/* Personal Information */}
      <Card style={{ marginBottom: 16 }}>
        <Text style={[commonStyles.h3, { marginBottom: 16 }]}>
          Informações Pessoais
        </Text>
        <View style={{ gap: 16 }}>
          <Input
            label="Nome *"
            value={form.name}
            onChangeText={(value) => updateForm("name", value)}
            placeholder="Seu nome completo"
            error={errors.name}
          />

          <Input
            label="E-mail *"
            value={form.email}
            onChangeText={(value) => updateForm("email", value)}
            placeholder="seu@email.com"
            keyboardType="email-address"
            autoCapitalize="none"
            error={errors.email}
          />

          <Input
            label="Telefone"
            value={form.phone}
            onChangeText={(value) => updateForm("phone", value)}
            placeholder="(11) 99999-9999"
            keyboardType="phone-pad"
          />
        </View>
      </Card>

      {/* Change Password */}
      <Card style={{ marginBottom: 16 }}>
        <TouchableOpacity
          onPress={() => setChangePassword(!changePassword)}
          style={[
            commonStyles.rowBetween,
            { marginBottom: changePassword ? 16 : 0 },
          ]}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Icon name="lock" size={20} color={colors.primary} />
            <Text style={commonStyles.body}>Alterar Senha</Text>
          </View>
          <Icon
            name={changePassword ? "expand-less" : "expand-more"}
            size={24}
            color={colors.textSecondary}
          />
        </TouchableOpacity>

        {changePassword && (
          <View style={{ gap: 16 }}>
            <Input
              label="Senha Atual"
              value={form.currentPassword}
              onChangeText={(value) => updateForm("currentPassword", value)}
              placeholder="Digite sua senha atual"
              secureTextEntry
            />

            <Input
              label="Nova Senha"
              value={form.newPassword}
              onChangeText={(value) => updateForm("newPassword", value)}
              placeholder="Mínimo 6 caracteres"
              secureTextEntry
              error={errors.newPassword}
            />

            <Input
              label="Confirmar Nova Senha"
              value={form.confirmPassword}
              onChangeText={(value) => updateForm("confirmPassword", value)}
              placeholder="Digite a nova senha novamente"
              secureTextEntry
              error={errors.confirmPassword}
            />
          </View>
        )}
      </Card>

      {/* Account Information */}
      <Card style={{ marginBottom: 16 }}>
        <Text style={[commonStyles.h3, { marginBottom: 16 }]}>
          Informações da Conta
        </Text>
        <View style={{ gap: 12 }}>
          <View>
            <Text
              style={[commonStyles.caption, { color: colors.textSecondary }]}
            >
              Função
            </Text>
            <Text style={commonStyles.body}>
              {user?.role === "OWNER"
                ? "Proprietário"
                : user?.role === "STAFF"
                ? "Profissional"
                : "Cliente"}
            </Text>
          </View>

          <View>
            <Text
              style={[commonStyles.caption, { color: colors.textSecondary }]}
            >
              Empresa
            </Text>
            <Text style={commonStyles.body}>
              {company?.name || "Não vinculada"}
            </Text>
          </View>

          <View>
            <Text
              style={[commonStyles.caption, { color: colors.textSecondary }]}
            >
              Membro desde
            </Text>
            <Text style={commonStyles.body}>
              {user?.createdAt
                ? new Date(user.createdAt).toLocaleDateString("pt-BR")
                : "-"}
            </Text>
          </View>
        </View>
      </Card>

      {/* Actions */}
      <View style={{ gap: 12, marginBottom: 32 }}>
        <Button
          title={loading ? "Salvando..." : "Salvar Alterações"}
          onPress={handleSubmit}
          loading={loading}
          disabled={loading}
          icon="save"
        />

        <Button
          title="Sair"
          onPress={() => {
            Alert.alert("Sair", "Tem certeza que deseja sair?", [
              { text: "Cancelar", style: "cancel" },
              {
                text: "Sair",
                style: "destructive",
                onPress: () => {
                  // TODO: Implement logout
                  navigation.navigate("SignIn" as never);
                },
              },
            ]);
          }}
          variant="outline"
          color="error"
          icon="logout"
        />

        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{ marginTop: 8 }}
        >
          <Text
            style={[
              commonStyles.body,
              { color: colors.primary, textAlign: "center" },
            ]}
          >
            Cancelar
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

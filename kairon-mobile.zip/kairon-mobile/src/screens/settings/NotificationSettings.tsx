import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  Switch,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useAuth } from '../../contexts/AuthContext';
import { notificationService } from '../../services/notifications';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';


interface NotificationSettings {
  emailNotifications: {
    newAppointments: boolean;
    cancellations: boolean;
    reminders: boolean;
    promotions: boolean;
    newsletter: boolean;
  };
  pushNotifications: {
    newAppointments: boolean;
    cancellations: boolean;
    reminders: boolean;
    updates: boolean;
  };
  smsNotifications: {
    reminders: boolean;
    confirmations: boolean;
  };
  appointmentReminders: {
    enabled: boolean;
    hoursBefore: number;
    method: 'email' | 'sms' | 'both';
  };
}

export function NotificationSettings() {
  const navigation = useNavigation();
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<NotificationSettings>({
    emailNotifications: {
      newAppointments: true,
      cancellations: true,
      reminders: true,
      promotions: false,
      newsletter: false,
    },
    pushNotifications: {
      newAppointments: true,
      cancellations: true,
      reminders: true,
      updates: true,
    },
    smsNotifications: {
      reminders: true,
      confirmations: true,
    },
    appointmentReminders: {
      enabled: true,
      hoursBefore: 24,
      method: 'both',
    },
  });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const data = await notificationService.getSettings();
      if (data) {
        setSettings(data);
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await notificationService.updateSettings(settings);
      Alert.alert('Sucesso', 'Configurações salvas com sucesso!');
    } catch (error) {
      console.error('Error saving notification settings:', error);
      Alert.alert('Erro', 'Não foi possível salvar as configurações');
    } finally {
      setLoading(false);
    }
  };

  const updateEmailSetting = (key: keyof NotificationSettings['emailNotifications'], value: boolean) => {
    setSettings(prev => ({
      ...prev,
      emailNotifications: {
        ...prev.emailNotifications,
        [key]: value,
      },
    }));
  };

  const updatePushSetting = (key: keyof NotificationSettings['pushNotifications'], value: boolean) => {
    setSettings(prev => ({
      ...prev,
      pushNotifications: {
        ...prev.pushNotifications,
        [key]: value,
      },
    }));
  };

  const updateSmsSetting = (key: keyof NotificationSettings['smsNotifications'], value: boolean) => {
    setSettings(prev => ({
      ...prev,
      smsNotifications: {
        ...prev.smsNotifications,
        [key]: value,
      },
    }));
  };

  const updateReminderSetting = (key: keyof NotificationSettings['appointmentReminders'], value: any) => {
    setSettings(prev => ({
      ...prev,
      appointmentReminders: {
        ...prev.appointmentReminders,
        [key]: value,
      },
    }));
  };

  const renderNotificationItem = (
    title: string,
    description: string,
    value: boolean,
    onValueChange: (value: boolean) => void,
    icon: string
  ) => (
    <View style={[commonStyles.rowBetween, { paddingVertical: 12 }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
        <Icon name={icon} size={20} color={colors.textSecondary} style={{ marginRight: 12 }} />
        <View style={{ flex: 1 }}>
          <Text style={commonStyles.body}>{title}</Text>
          <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>{description}</Text>
        </View>
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: colors.border, true: colors.primary }}
        thumbColor={colors.surface}
      />
    </View>
  );

  return (
    <ScrollView 
      style={commonStyles.container}
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ marginBottom: 24 }}>
        <Text style={commonStyles.h1}>Notificações</Text>
        <Text style={[commonStyles.body, { color: colors.textSecondary, marginTop: 4 }]}>
          Configure como deseja receber notificações
        </Text>
      </View>

      {/* Email Notifications */}
      <Card style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
          <Icon name="email" size={24} color={colors.primary} style={{ marginRight: 12 }} />
          <Text style={commonStyles.h3}>Notificações por E-mail</Text>
        </View>

        {renderNotificationItem(
          'Novos Agendamentos',
          'Receba e-mail quando um novo agendamento for feito',
          settings.emailNotifications.newAppointments,
          (value) => updateEmailSetting('newAppointments', value),
          'calendar-today'
        )}

        {renderNotificationItem(
          'Cancelamentos',
          'Receba e-mail quando um agendamento for cancelado',
          settings.emailNotifications.cancellations,
          (value) => updateEmailSetting('cancellations', value),
          'cancel'
        )}

        {renderNotificationItem(
          'Lembretes',
          'Receba lembretes de agendamentos futuros',
          settings.emailNotifications.reminders,
          (value) => updateEmailSetting('reminders', value),
          'notifications'
        )}

        {renderNotificationItem(
          'Promoções',
          'Receba ofertas e promoções especiais',
          settings.emailNotifications.promotions,
          (value) => updateEmailSetting('promotions', value),
          'local-offer'
        )}

        {renderNotificationItem(
          'Newsletter',
          'Receba novidades e dicas sobre o sistema',
          settings.emailNotifications.newsletter,
          (value) => updateEmailSetting('newsletter', value),
          'newspaper'
        )}
      </Card>

      {/* Push Notifications */}
      <Card style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
          <Icon name="notifications" size={24} color={colors.primary} style={{ marginRight: 12 }} />
          <Text style={commonStyles.h3}>Notificações no App</Text>
        </View>

        {renderNotificationItem(
          'Novos Agendamentos',
          'Receba notificação quando um novo agendamento for feito',
          settings.pushNotifications.newAppointments,
          (value) => updatePushSetting('newAppointments', value),
          'calendar-today'
        )}

        {renderNotificationItem(
          'Cancelamentos',
          'Receba notificação quando um agendamento for cancelado',
          settings.pushNotifications.cancellations,
          (value) => updatePushSetting('cancellations', value),
          'cancel'
        )}

        {renderNotificationItem(
          'Lembretes',
          'Receba lembretes de agendamentos futuros',
          settings.pushNotifications.reminders,
          (value) => updatePushSetting('reminders', value),
          'notifications-active'
        )}

        {renderNotificationItem(
          'Atualizações',
          'Receba notificações sobre atualizações do sistema',
          settings.pushNotifications.updates,
          (value) => updatePushSetting('updates', value),
          'system-update'
        )}
      </Card>

      {/* SMS Notifications */}
      <Card style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
          <Icon name="sms" size={24} color={colors.primary} style={{ marginRight: 12 }} />
          <Text style={commonStyles.h3}>Notificações por SMS</Text>
          <Text style={[commonStyles.caption, { color: colors.textMuted, marginLeft: 8 }]}>
            * Pode haver custos adicionais
          </Text>
        </View>

        {renderNotificationItem(
          'Lembretes',
          'Receba lembretes de agendamentos por SMS',
          settings.smsNotifications.reminders,
          (value) => updateSmsSetting('reminders', value),
          'notifications'
        )}

        {renderNotificationItem(
          'Confirmações',
          'Receba confirmações de agendamento por SMS',
          settings.smsNotifications.confirmations,
          (value) => updateSmsSetting('confirmations', value),
          'check-circle'
        )}
      </Card>

      {/* Appointment Reminders */}
      <Card style={{ marginBottom: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
          <Icon name="access-alarm" size={24} color={colors.primary} style={{ marginRight: 12 }} />
          <Text style={commonStyles.h3}>Lembretes de Agendamento</Text>
        </View>

        <View style={[commonStyles.rowBetween, { paddingVertical: 12 }]}>
          <View style={{ flex: 1 }}>
            <Text style={commonStyles.body}>Lembretes Ativados</Text>
            <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>
              Enviar lembretes automáticos para clientes
            </Text>
          </View>
          <Switch
            value={settings.appointmentReminders.enabled}
            onValueChange={(value) => updateReminderSetting('enabled', value)}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor={colors.surface}
          />
        </View>

        {settings.appointmentReminders.enabled && (
          <View style={{ gap: 16, marginTop: 16 }}>
            <View>
              <Text style={[commonStyles.body, { marginBottom: 8 }]}>Enviar Lembrete</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <View style={{ flex: 1 }}>
                  <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>
                    {settings.appointmentReminders.hoursBefore} horas antes
                  </Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <TouchableOpacity
                    onPress={() => updateReminderSetting('hoursBefore', Math.max(1, settings.appointmentReminders.hoursBefore - 1))}
                    style={{ padding: 8 }}
                  >
                    <Icon name="remove" size={20} color={colors.primary} />
                  </TouchableOpacity>
                  <Text style={commonStyles.body}>{settings.appointmentReminders.hoursBefore}h</Text>
                  <TouchableOpacity
                    onPress={() => updateReminderSetting('hoursBefore', settings.appointmentReminders.hoursBefore + 1)}
                    style={{ padding: 8 }}
                  >
                    <Icon name="add" size={20} color={colors.primary} />
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <View>
              <Text style={[commonStyles.body, { marginBottom: 8 }]}>Método de Envio</Text>
              <View style={{ flexDirection: 'row', gap: 12 }}>
                {(['email', 'sms', 'both'] as const).map((method) => (
                  <TouchableOpacity
                    key={method}
                    style={[
                      {
                        flex: 1,
                        padding: 12,
                        borderRadius: 8,
                        borderWidth: 2,
                        alignItems: 'center',
                      },
                      settings.appointmentReminders.method === method
                        ? { borderColor: colors.primary, backgroundColor: colors.primaryLight }
                        : { borderColor: colors.border, backgroundColor: colors.surface }
                    ]}
                    onPress={() => updateReminderSetting('method', method)}
                  >
                    <Text style={[
                      commonStyles.bodySmall,
                      settings.appointmentReminders.method === method
                        ? { color: colors.primary, fontWeight: '600' }
                        : { color: colors.textSecondary }
                    ]}>
                      {method === 'email' ? 'E-mail' : 
                       method === 'sms' ? 'SMS' : 'Ambos'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        )}
      </Card>

      {/* Actions */}
      <View style={{ gap: 12, marginBottom: 32 }}>
        <Button
          title={loading ? "Salvando..." : "Salvar Configurações"}
          onPress={handleSubmit}
          loading={loading}
          disabled={loading}
          icon="save"
        />
        
        <Button
          title="Testar Notificações"
          onPress={async () => {
            try {
              await notificationService.testNotifications();
              Alert.alert('Sucesso', 'Notificação de teste enviada!');
            } catch (error) {
              Alert.alert('Erro', 'Não foi possível enviar notificação de teste');
            }
          }}
          variant="outline"
          icon="notifications"
        />
        
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{ marginTop: 8 }}
        >
          <Text style={[commonStyles.body, { color: colors.primary, textAlign: 'center' }]}>
            Cancelar
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Switch,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  KeyboardAvoidingView
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

import { useAuth } from '../../contexts/AuthContext';
import { companyService } from '../../services/company';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';

// =========================
// THEME & TYPES
// =========================

const theme = {
  primary: colors.primary || '#2563EB',
  background: '#F8F9FA',
  text: '#1E293B',
  textSecondary: '#64748B',
  border: '#E2E8F0',
  danger: '#EF4444',
  success: '#10B981'
};

interface BusinessHours {
  monday: { open: string; close: string };
  tuesday: { open: string; close: string };
  wednesday: { open: string; close: string };
  thursday: { open: string; close: string };
  friday: { open: string; close: string };
  saturday: { open: string; close: string };
  sunday: { open: string; close: string };
}

interface CompanySettings {
  onlineBooking: boolean;
  requireConfirmation: boolean;
  allowCancellations: boolean;
  cancellationNoticeHours: number;
  sendReminders: boolean;
  reminderHours: number;
}

interface CompanySettingsForm {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  website?: string;
  description?: string;
  businessHours: BusinessHours;
  settings: CompanySettings;
  logo?: string;
}

// =========================
// COMPONENT
// =========================

export function CompanySettings() {
  const navigation = useNavigation();
  const { company, signOut } = useAuth(); 

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  
  const [form, setForm] = useState<CompanySettingsForm>({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    website: '',
    description: '',
    businessHours: {
      monday: { open: '09:00', close: '18:00' },
      tuesday: { open: '09:00', close: '18:00' },
      wednesday: { open: '09:00', close: '18:00' },
      thursday: { open: '09:00', close: '18:00' },
      friday: { open: '09:00', close: '18:00' },
      saturday: { open: '09:00', close: '14:00' },
      sunday: { open: '', close: '' },
    },
    settings: {
      onlineBooking: true,
      requireConfirmation: false,
      allowCancellations: true,
      cancellationNoticeHours: 24,
      sendReminders: true,
      reminderHours: 24,
    },
  });

  const days = [
    { key: 'monday', label: 'Segunda' },
    { key: 'tuesday', label: 'Terça' },
    { key: 'wednesday', label: 'Quarta' },
    { key: 'thursday', label: 'Quinta' },
    { key: 'friday', label: 'Sexta' },
    { key: 'saturday', label: 'Sábado' },
    { key: 'sunday', label: 'Domingo' },
  ] as const;

  // CORREÇÃO AQUI: Lógica de carregamento blindada
  useEffect(() => {
    console.log("🔄 useEffect disparado. Company:", company);
    
    if (company?.id) {
      loadCompanyData();
    } else {
      // Se não tiver empresa (ou ainda estiver carregando o user), paramos o loading
      // para não travar a tela, mas mostramos um aviso ou estado vazio.
      console.log("⚠️ Nenhuma empresa encontrada no contexto.");
      setLoading(false);
    }
  }, [company]);

  const loadCompanyData = async () => {
    try {
      setLoading(true);
      if (!company?.id) return;
      
      console.log("🚀 Buscando dados da empresa ID:", company.id);
      const companyData = await companyService.getSettings(company.id);
      console.log("✅ Dados recebidos:", companyData);

      setForm(prev => ({
        ...prev,
        name: companyData.name || '',
        email: companyData.email || '',
        phone: companyData.phone || '',
        address: companyData.address || '',
        city: companyData.city || '',
        state: companyData.state || '',
        zipCode: companyData.zipCode || '',
        website: companyData.website || '',
        description: companyData.description || '',
        // Garante fallback se vier null do backend
        businessHours: companyData.businessHours || prev.businessHours,
        settings: companyData.settings || prev.settings,
        logo: companyData.logo, 
      }));
    } catch (error) {
      console.error('❌ Erro ao carregar empresa:', error);
      Alert.alert('Erro', 'Não foi possível carregar as configurações');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    if (!form.name.trim()) {
      Alert.alert('Erro', 'O nome da empresa é obrigatório');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    setSaving(true);
    try {
      if (!company?.id) throw new Error('Empresa não encontrada');

      const payload = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        address: form.address,
        city: form.city,
        state: form.state,
        zipCode: form.zipCode,
        website: form.website,
        description: form.description,
        businessHours: form.businessHours,
        settings: form.settings,
      };

      await companyService.updateSettings(company.id, payload);
      // Aqui você pode atualizar o contexto se tiver essa função exposta
      // if (updateCompany) await updateCompany(updatedCompany);

      Alert.alert('Sucesso', 'Configurações salvas!');
    } catch (error: any) {
      console.error("Erro ao salvar:", error);
      Alert.alert('Erro', error.message || 'Falha ao salvar');
    } finally {
      setSaving(false);
    }
  };

  const pickLogo = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Atenção', 'Precisamos de acesso à galeria.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.7,
      });

      if (!result.canceled && result.assets[0]?.uri) {
        setUploadingLogo(true);
        const formData = new FormData();
        formData.append('logo', {
          uri: result.assets[0].uri,
          type: 'image/jpeg',
          name: 'logo.jpg',
        } as any);

        if (!company?.id) throw new Error('ID indefinido');
        await companyService.uploadLogo(company.id, formData);
        
        // Atualiza localmente para feedback instantâneo
        setForm(prev => ({ ...prev, logo: result.assets[0].uri }));
        Alert.alert('Sucesso', 'Logo atualizado!');
      }
    } catch (error) {
      console.error("Erro upload logo:", error);
      Alert.alert('Erro', 'Falha ao enviar logo.');
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSignOut = () => {
    Alert.alert('Sair', 'Deseja realmente sair do app?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sair', style: 'destructive', onPress: signOut }
    ]);
  };

  const updateField = (field: keyof CompanySettingsForm, value: string) =>
    setForm(prev => ({ ...prev, [field]: value }));

  const updateBusinessHours = (day: keyof BusinessHours, field: 'open' | 'close', value: string) => {
    setForm(prev => ({
      ...prev,
      businessHours: {
        ...prev.businessHours,
        [day]: { ...prev.businessHours[day], [field]: value },
      },
    }));
  };

  const updateSetting = (field: keyof CompanySettings, value: boolean | number) =>
    setForm(prev => ({
      ...prev,
      settings: { ...prev.settings, [field]: value },
    }));

  // LOADING STATE
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={{marginTop: 10, color: theme.textSecondary}}>Carregando configurações...</Text>
      </View>
    );
  }

  // ESTADO SE NÃO TIVER EMPRESA VINCULADA (Evita tela branca)
  if (!company?.id) {
    return (
        <View style={styles.loadingContainer}>
            <Feather name="alert-circle" size={48} color={theme.textSecondary} />
            <Text style={{marginTop: 10, color: theme.text, fontSize: 16, fontWeight: 'bold'}}>Nenhuma empresa vinculada</Text>
            <Text style={{marginTop: 4, color: theme.textSecondary, textAlign: 'center', paddingHorizontal: 30}}>
                Parece que sua conta não tem uma empresa associada. Entre em contato com o suporte ou faça login novamente.
            </Text>
            <TouchableOpacity onPress={signOut} style={{marginTop: 20, padding: 10}}>
                <Text style={{color: theme.primary, fontWeight: 'bold'}}>Sair da conta</Text>
            </TouchableOpacity>
        </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={theme.primary} />
      
      {/* Header Fixo Azul */}
      <View style={[styles.headerBackground, { height: Platform.OS === 'ios' ? 200 : 180 }]} />

      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={{ flex: 1 }}
        >
          <ScrollView 
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {/* LOGO & TITLE SECTION */}
            <View style={styles.profileSection}>
              <TouchableOpacity 
                style={styles.logoContainer} 
                onPress={pickLogo}
                disabled={uploadingLogo}
              >
                {form.logo ? (
                  <Image source={{ uri: form.logo }} style={styles.logo} />
                ) : (
                  <View style={styles.logoPlaceholder}>
                    <Feather name="briefcase" size={40} color={theme.primary} />
                  </View>
                )}
                
                <View style={styles.cameraBadge}>
                  {uploadingLogo ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Feather name="camera" size={14} color="#fff" />
                  )}
                </View>
              </TouchableOpacity>
              
              <Text style={styles.companyNameTitle}>{form.name || 'Nome da Empresa'}</Text>
              <Text style={styles.companySubtitle}>Configurações Gerais</Text>
            </View>

            {/* SEÇÃO 1: DADOS GERAIS */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="info" size={18} color={theme.primary} />
                <Text style={styles.cardTitle}>Dados da Empresa</Text>
              </View>
              
              <View style={styles.inputGroup}>
                <Input label="Nome Fantasia" value={form.name} onChangeText={(v) => updateField('name', v)} />
                <Input label="E-mail de Contato" value={form.email} onChangeText={(v) => updateField('email', v)} keyboardType="email-address" />
                <Input label="Telefone" value={form.phone} onChangeText={(v) => updateField('phone', v)} keyboardType="phone-pad" />
                <Input label="Descrição Curta" value={form.description} onChangeText={(v) => updateField('description', v)} multiline />
              </View>
            </View>

            {/* SEÇÃO 2: HORÁRIOS */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="clock" size={18} color={theme.primary} />
                <Text style={styles.cardTitle}>Horário de Funcionamento</Text>
              </View>

              <View style={styles.hoursList}>
                {days.map(day => (
                  <View key={day.key} style={styles.dayRow}>
                    <Text style={styles.dayLabel}>{day.label}</Text>
                    <View style={styles.timeInputs}>
                      <Input
                        value={form.businessHours[day.key]?.open || ''}
                        onChangeText={(v) => updateBusinessHours(day.key, 'open', v)}
                        placeholder="00:00"
                        style={styles.timeInput}
                        containerStyle={{ marginBottom: 0 }}
                      />
                      <Text style={styles.timeSeparator}>-</Text>
                      <Input
                        value={form.businessHours[day.key]?.close || ''}
                        onChangeText={(v) => updateBusinessHours(day.key, 'close', v)}
                        placeholder="00:00"
                        style={styles.timeInput}
                        containerStyle={{ marginBottom: 0 }}
                      />
                    </View>
                  </View>
                ))}
              </View>
            </View>

            {/* SEÇÃO 3: REGRAS E PREFERÊNCIAS */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="sliders" size={18} color={theme.primary} />
                <Text style={styles.cardTitle}>Regras de Agendamento</Text>
              </View>

              <View style={styles.settingRow}>
                <Text style={styles.settingText}>Aceitar agendamento online</Text>
                <Switch 
                  value={form.settings.onlineBooking} 
                  onValueChange={(v) => updateSetting('onlineBooking', v)}
                  trackColor={{ false: theme.border, true: theme.primary }}
                />
              </View>

              <View style={styles.divider} />

              <View style={styles.settingRow}>
                <Text style={styles.settingText}>Exigir confirmação manual</Text>
                <Switch 
                  value={form.settings.requireConfirmation} 
                  onValueChange={(v) => updateSetting('requireConfirmation', v)}
                  trackColor={{ false: theme.border, true: theme.primary }}
                />
              </View>
              
              <View style={styles.divider} />

              <View style={styles.settingRow}>
                 <Text style={styles.settingText}>Permitir cancelamento</Text>
                 <Switch 
                    value={form.settings.allowCancellations} 
                    onValueChange={(v) => updateSetting('allowCancellations', v)}
                    trackColor={{ false: theme.border, true: theme.primary }}
                 />
              </View>
              
              {form.settings.allowCancellations && (
                 <View style={{ marginTop: 10 }}>
                    <Input 
                        label="Antecedência mínima (horas)" 
                        value={String(form.settings.cancellationNoticeHours)}
                        onChangeText={(v) => updateSetting('cancellationNoticeHours', Number(v))}
                        keyboardType="numeric"
                    />
                 </View>
              )}
            </View>

            {/* BOTÕES FINAIS */}
            <View style={styles.footerActions}>
              <Button 
                title={saving ? "Salvando..." : "Salvar Alterações"} 
                onPress={handleSubmit} 
                loading={saving} 
                icon="save"
              />
              
              <TouchableOpacity 
                style={styles.logoutButton}
                onPress={handleSignOut}
              >
                <Feather name="log-out" size={18} color={theme.danger} />
                <Text style={styles.logoutText}>Sair da Conta</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.versionInfo}>App Kairon v1.0</Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

// =========================
// STYLES
// =========================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.background,
  },
  headerBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: theme.primary,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },

  // PROFILE SECTION
  profileSection: {
    alignItems: 'center',
    marginTop: Platform.OS === 'android' ? 40 : 20,
    marginBottom: 20,
  },
  logoContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  logo: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 4,
    borderColor: '#fff',
    backgroundColor: '#fff',
  },
  logoPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#E2E8F0',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 4,
    borderColor: '#fff',
  },
  cameraBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: theme.primary,
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  companyNameTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
    textAlign: 'center',
  },
  companySubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },

  // CARDS
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
    paddingBottom: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: theme.text,
    marginLeft: 8,
  },
  inputGroup: {
    gap: 12,
  },

  // HOURS SECTION
  hoursList: {
    gap: 12,
  },
  dayRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayLabel: {
    fontSize: 14,
    color: theme.textSecondary,
    width: 80,
    fontWeight: '500',
  },
  timeInputs: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  timeInput: {
    width: 80,
    textAlign: 'center',
    height: 40,
  },
  timeSeparator: {
    color: theme.textSecondary,
  },

  // SETTINGS SECTION
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  settingText: {
    fontSize: 14,
    color: theme.text,
    flex: 1,
  },
  divider: {
    height: 1,
    backgroundColor: '#F1F5F9',
    marginVertical: 12,
  },

  // FOOTER
  footerActions: {
    gap: 16,
    marginTop: 8,
  },
  logoutButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FECACA',
    backgroundColor: '#FEF2F2',
  },
  logoutText: {
    marginLeft: 8,
    color: theme.danger,
    fontWeight: '600',
  },
  versionInfo: {
    textAlign: 'center',
    color: '#CBD5E1',
    fontSize: 12,
    marginTop: 24,
  },
});
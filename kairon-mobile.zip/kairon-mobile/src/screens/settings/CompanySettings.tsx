import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../contexts/AuthContext';
import { companyService } from '../../services/company';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';


// Tipagens
interface BusinessHours {
  monday: { open: string; close: string };
  tuesday: { open: string; close: string };
  wednesday: { open: string; close: string };
  thursday: { open: string; close: string };
  friday: { open: string; close: string };
  saturday: { open: string; close: string };
  sunday: { open: string; close: string };
}

interface CompanySettings {
  onlineBooking: boolean;
  requireConfirmation: boolean;
  allowCancellations: boolean;
  cancellationNoticeHours: number;
  sendReminders: boolean;
  reminderHours: number;
}

interface CompanySettingsForm {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  website?: string;
  description?: string;
  businessHours: BusinessHours;
  settings: CompanySettings;
  logo?: string; // somente para front
}

export function CompanySettings() {
  const navigation = useNavigation();
  const { company, updateCompany } = useAuth();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [form, setForm] = useState<CompanySettingsForm>({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    website: '',
    description: '',
    businessHours: {
      monday: { open: '09:00', close: '18:00' },
      tuesday: { open: '09:00', close: '18:00' },
      wednesday: { open: '09:00', close: '18:00' },
      thursday: { open: '09:00', close: '18:00' },
      friday: { open: '09:00', close: '18:00' },
      saturday: { open: '09:00', close: '14:00' },
      sunday: { open: '', close: '' },
    },
    settings: {
      onlineBooking: true,
      requireConfirmation: false,
      allowCancellations: true,
      cancellationNoticeHours: 24,
      sendReminders: true,
      reminderHours: 24,
    },
  });

  const days = [
    { key: 'monday', label: 'Segunda-feira' },
    { key: 'tuesday', label: 'Terça-feira' },
    { key: 'wednesday', label: 'Quarta-feira' },
    { key: 'thursday', label: 'Quinta-feira' },
    { key: 'friday', label: 'Sexta-feira' },
    { key: 'saturday', label: 'Sábado' },
    { key: 'sunday', label: 'Domingo' },
  ] as const;

  useEffect(() => {
    if (company?.id) loadCompanyData();
  }, [company]);

  const loadCompanyData = async () => {
    try {
      setLoading(true);
      const companyData = await companyService.getSettings(company!.id);

      setForm(prev => ({
        ...prev,
        name: companyData.name || '',
        email: companyData.email || '',
        phone: companyData.phone || '',
        address: companyData.address || '',
        city: companyData.city || '',
        state: companyData.state || '',
        zipCode: companyData.zipCode || '',
        website: companyData.website || '',
        description: companyData.description || '',
        businessHours: companyData.businessHours || prev.businessHours,
        settings: companyData.settings || prev.settings,
        logo: companyData.logo, // somente front
      }));
    } catch (error) {
      console.error('Erro ao carregar empresa:', error);
      Alert.alert('Erro', 'Não foi possível carregar as configurações da empresa');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    if (!form.name.trim()) {
      Alert.alert('Erro', 'O nome da empresa é obrigatório');
      return false;
    }
    if (!form.email.trim()) {
      Alert.alert('Erro', 'O e-mail é obrigatório');
      return false;
    }
    if (!form.phone.trim()) {
      Alert.alert('Erro', 'O telefone é obrigatório');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
  
    setSaving(true);
    try {
      if (!company?.id) throw new Error('Empresa não encontrada');
  
      const payload = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        address: form.address,
        city: form.city,
        state: form.state,
        zipCode: form.zipCode,
        website: form.website,
        description: form.description,
        businessHours: form.businessHours,
        settings: {
          onlineBooking: form.settings.onlineBooking,
          requireConfirmation: form.settings.requireConfirmation,
          allowCancellations: form.settings.allowCancellations,
          cancellationNoticeHours: form.settings.cancellationNoticeHours,
          sendReminders: form.settings.sendReminders,
          reminderHours: form.settings.reminderHours,
        },
      };
  
      const updatedCompany = await companyService.updateSettings(
        company.id,
        payload
      );
  
      if (updateCompany) {
        await updateCompany(updatedCompany);
      }
  
      Alert.alert('Sucesso', 'Configurações salvas com sucesso!');
    } catch (error: any) {
      console.error(error);
      Alert.alert(
        'Erro',
        error.message || 'Não foi possível salvar as configurações'
      );
    } finally {
      setSaving(false);
    }
  };
  

  const pickLogo = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Permissão necessária', 'Precisamos de acesso à galeria para alterar o logo');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]?.uri) {
        setUploadingLogo(true);

        const formData = new FormData();
        formData.append('logo', {
          uri: result.assets[0].uri,
          type: 'image/jpeg',
          name: 'logo.jpg',
        } as any);

        if (!company?.id) throw new Error('Empresa não encontrada');
        await companyService.uploadLogo(company.id, formData);

        const updatedCompany = await companyService.getSettings(company.id);
        if (updateCompany) await updateCompany(updatedCompany);

        Alert.alert('Sucesso', 'Logo atualizado com sucesso!');
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível atualizar o logo');
    } finally {
      setUploadingLogo(false);
    }
  };

  const updateField = (field: keyof CompanySettingsForm, value: string | number) =>
    setForm(prev => ({ ...prev, [field]: value }));

  const updateBusinessHours = (
    day: keyof BusinessHours,
    field: 'open' | 'close',
    value: string
  ) => {
    setForm(prev => ({
      ...prev,
      businessHours: {
        ...prev.businessHours,
        [day]: { ...prev.businessHours[day], [field]: value },
      },
    }));
  };

  const updateSetting = (field: keyof CompanySettings, value: boolean | number) =>
    setForm(prev => ({
      ...prev,
      settings: { ...prev.settings, [field]: value },
    }));

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={commonStyles.container} contentContainerStyle={{ padding: 16 }} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={{ marginBottom: 24 }}>
        <Text style={commonStyles.h1}>Configurações da Empresa</Text>
        <Text style={[commonStyles.body, { color: colors.textSecondary, marginTop: 4 }]}>
          Gerencie informações e configurações
        </Text>
      </View>

      {/* Logo */}
      <Card style={{ marginBottom: 16 }}>
        <View style={{ alignItems: 'center' }}>
          <TouchableOpacity onPress={pickLogo} disabled={uploadingLogo}>
            {form.logo ? (
              <Image source={{ uri: form.logo }} style={{ width: 120, height: 120, borderRadius: 60, backgroundColor: colors.border }} />
            ) : (
              <View style={{
                width: 120, height: 120, borderRadius: 60,
                backgroundColor: colors.primaryLight,
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name="business" size={48} color={colors.primary} />
              </View>
            )}

            {uploadingLogo && (
              <View style={{
                position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
                backgroundColor: 'rgba(0,0,0,0.5)',
                borderRadius: 60,
                alignItems: 'center', justifyContent: 'center',
              }}>
                <ActivityIndicator size="large" color={colors.surface} />
              </View>
            )}
          </TouchableOpacity>

          <TouchableOpacity onPress={pickLogo} disabled={uploadingLogo} style={{ marginTop: 12 }}>
            <Text style={[commonStyles.body, { color: colors.primary }]}>{uploadingLogo ? 'Enviando...' : 'Alterar Logo'}</Text>
          </TouchableOpacity>
        </View>
      </Card>

      {/* Basic Info */}
      <Card style={{ marginBottom: 16 }}>
        <Text style={[commonStyles.h3, { marginBottom: 16 }]}>Informações Básicas</Text>
        <View style={{ gap: 16 }}>
          <Input label="Nome *" value={form.name} onChangeText={(v) => updateField('name', v)} />
          <Input label="E-mail *" value={form.email} onChangeText={(v) => updateField('email', v)} />
          <Input label="Telefone *" value={form.phone} onChangeText={(v) => updateField('phone', v)} />
          <Input label="Website" value={form.website} onChangeText={(v) => updateField('website', v)} />
          <Input label="Descrição" value={form.description} onChangeText={(v) => updateField('description', v)} multiline numberOfLines={3} />
        </View>
      </Card>

      {/* Business Hours */}
      <Card style={{ marginBottom: 16 }}>
        <Text style={[commonStyles.h3, { marginBottom: 16 }]}>Horário de Funcionamento</Text>
        <View style={{ gap: 12 }}>
          {days.map(day => (
            <View key={day.key} style={[commonStyles.rowBetween, { paddingVertical: 8 }]}>
              <Text style={[commonStyles.body, { width: 120 }]}>{day.label}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Input
                  value={form.businessHours[day.key].open}
                  onChangeText={(v) => updateBusinessHours(day.key, 'open', v)}
                  placeholder="09:00" style={{ width: 80 }}
                />
                <Text style={commonStyles.body}>às</Text>
                <Input
                  value={form.businessHours[day.key].close}
                  onChangeText={(v) => updateBusinessHours(day.key, 'close', v)}
                  placeholder="18:00" style={{ width: 80 }}
                />
              </View>
              {(!form.businessHours[day.key].open || !form.businessHours[day.key].close) && (
                <Text style={[commonStyles.caption, { color: colors.textMuted }]}>Fechado</Text>
              )}
            </View>
          ))}
        </View>
      </Card>

      {/* Booking Settings */}
      <Card style={{ marginBottom: 16 }}>
        <Text style={[commonStyles.h3, { marginBottom: 16 }]}>Configurações de Agendamento</Text>
        <View style={{ gap: 16 }}>
          <View style={[commonStyles.rowBetween]}>
            <Text style={commonStyles.body}>Agendamento Online</Text>
            <Switch value={form.settings.onlineBooking} onValueChange={(v) => updateSetting('onlineBooking', v)} trackColor={{ false: colors.border, true: colors.primary }} thumbColor={colors.surface} />
          </View>
          <View style={[commonStyles.rowBetween]}>
            <Text style={commonStyles.body}>Exigir Confirmação</Text>
            <Switch value={form.settings.requireConfirmation} onValueChange={(v) => updateSetting('requireConfirmation', v)} trackColor={{ false: colors.border, true: colors.primary }} thumbColor={colors.surface} />
          </View>
          <View style={[commonStyles.rowBetween]}>
            <Text style={commonStyles.body}>Permitir Cancelamentos</Text>
            <Switch value={form.settings.allowCancellations} onValueChange={(v) => updateSetting('allowCancellations', v)} trackColor={{ false: colors.border, true: colors.primary }} thumbColor={colors.surface} />
          </View>
          {form.settings.allowCancellations && (
            <Input
              label="Prazo para Cancelamento (horas)"
              value={form.settings.cancellationNoticeHours.toString()}
              onChangeText={(v) => updateSetting('cancellationNoticeHours', parseInt(v) || 0)}
              placeholder="24"
              keyboardType="number-pad"
            />
          )}
          <View style={[commonStyles.rowBetween]}>
            <Text style={commonStyles.body}>Enviar Lembretes</Text>
            <Switch value={form.settings.sendReminders} onValueChange={(v) => updateSetting('sendReminders', v)} trackColor={{ false: colors.border, true: colors.primary }} thumbColor={colors.surface} />
          </View>
          {form.settings.sendReminders && (
            <Input
              label="Enviar Lembrete (horas antes)"
              value={form.settings.reminderHours.toString()}
              onChangeText={(v) => updateSetting('reminderHours', parseInt(v) || 0)}
              placeholder="24"
              keyboardType="number-pad"
            />
          )}
        </View>
      </Card>

      {/* Actions */}
      <View style={{ gap: 12, marginBottom: 32 }}>
        <Button title={saving ? 'Salvando...' : 'Salvar Alterações'} onPress={handleSubmit} loading={saving} disabled={saving} icon="save" />
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop: 8 }}>
          <Text style={[commonStyles.body, { color: colors.primary, textAlign: 'center' }]}>Cancelar</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

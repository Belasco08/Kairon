import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Switch,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  KeyboardAvoidingView
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

import { useAuth } from '../../contexts/AuthContext';
import { companyService } from '../../services/company';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';

// ==============================================================================
// ⚠️ ATENÇÃO: SUBSTITUA O 'X' PELO SEU IP (ex: 192.168.1.15)
// No Windows, abra o cmd e digite 'ipconfig' para ver o endereço IPv4.
// ==============================================================================
const API_URL = "http://192.168.1.5:8080"; 

const theme = {
  primary: colors.primary || '#2563EB',
  background: '#F8F9FA',
  text: '#1E293B',
  textSecondary: '#64748B',
  border: '#E2E8F0',
  danger: '#EF4444',
  success: '#10B981'
};

interface BusinessHours {
  monday: { open: string; close: string };
  tuesday: { open: string; close: string };
  wednesday: { open: string; close: string };
  thursday: { open: string; close: string };
  friday: { open: string; close: string };
  saturday: { open: string; close: string };
  sunday: { open: string; close: string };
}

interface CompanySettings {
  onlineBooking: boolean;
  requireConfirmation: boolean;
  allowCancellations: boolean;
  cancellationNoticeHours: number;
  sendReminders: boolean;
  reminderHours: number;
}

interface CompanySettingsForm {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  website?: string;
  description?: string;
  businessHours: BusinessHours;
  settings: CompanySettings;
  logo?: string;
}

export function CompanySettings() {
  const navigation = useNavigation();
  const { company, user, signOut } = useAuth() as any; 

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  
  // Estado para forçar atualização da imagem (cache busting)
  const [logoVersion, setLogoVersion] = useState(Date.now());
  
  const targetCompanyId = company?.id || user?.companyId;
  const isOwner = user?.role === 'OWNER';

  const [form, setForm] = useState<CompanySettingsForm>({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    website: '',
    description: '',
    businessHours: {
      monday: { open: '09:00', close: '18:00' },
      tuesday: { open: '09:00', close: '18:00' },
      wednesday: { open: '09:00', close: '18:00' },
      thursday: { open: '09:00', close: '18:00' },
      friday: { open: '09:00', close: '18:00' },
      saturday: { open: '09:00', close: '14:00' },
      sunday: { open: '', close: '' },
    },
    settings: {
      onlineBooking: true,
      requireConfirmation: false,
      allowCancellations: true,
      cancellationNoticeHours: 24,
      sendReminders: true,
      reminderHours: 24,
    },
  });

  const days = [
    { key: 'monday', label: 'Segunda' },
    { key: 'tuesday', label: 'Terça' },
    { key: 'wednesday', label: 'Quarta' },
    { key: 'thursday', label: 'Quinta' },
    { key: 'friday', label: 'Sexta' },
    { key: 'saturday', label: 'Sábado' },
    { key: 'sunday', label: 'Domingo' },
  ] as const;

  useEffect(() => {
    if (targetCompanyId) {
      loadCompanyData(targetCompanyId);
    } else {
      setLoading(false);
    }
  }, [targetCompanyId]);

  const loadCompanyData = async (id: string) => {
    try {
      setLoading(true);
      const data = await companyService.getSettings(id);
      
      console.log("📥 DADOS BACKEND:", data);

      setForm(prev => ({
        ...prev,
        name: data.name || '',
        email: data.email || '',
        phone: data.phone || '',
        address: data.address || '',
        city: data.city || '',
        state: data.state || '',
        zipCode: data.zipCode || '',
        website: data.website || '',
        description: data.description || '',
        
        logo: data.logoUrl || null, 
        
        businessHours: data.businessHours || prev.businessHours,
        settings: data.settings || prev.settings,
      }));
    } catch (error) {
      console.error('❌ Erro ao carregar empresa:', error);
      Alert.alert('Erro', 'Não foi possível carregar as configurações');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!isOwner) return;
    if (!targetCompanyId) return;

    setSaving(true);
    try {
      const updatedData = await companyService.updateSettings(targetCompanyId, form);
      
      setForm(prev => ({
         ...prev,
         ...updatedData, 
         logo: updatedData.logoUrl || prev.logo,
         businessHours: updatedData.businessHours || prev.businessHours
      }));

      Alert.alert('Sucesso', 'Configurações salvas!');
    } catch (error: any) {
      Alert.alert('Erro', error.message || 'Falha ao salvar');
    } finally {
      setSaving(false);
    }
  };

  const pickLogo = async () => {
    if (!isOwner) {
        Alert.alert('Acesso Restrito', 'Apenas o proprietário pode alterar o logo.');
        return;
    }
    if (!targetCompanyId) return;

    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
          Alert.alert('Permissão necessária', 'Precisamos de acesso à galeria.');
          return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.5, // 👇 Reduz qualidade para evitar erro de tamanho no Backend
      });

      if (!result.canceled && result.assets[0]?.uri) {
        setUploadingLogo(true);
        const formData = new FormData();
        
        // Monta o arquivo para envio
        formData.append('logo', {
          uri: result.assets[0].uri,
          type: 'image/jpeg', 
          name: 'logo.jpg',
        } as any);

        const updatedData = await companyService.uploadLogo(targetCompanyId, formData);
        
        console.log("📤 LOGO ATUALIZADO:", updatedData.logoUrl);

        setForm(prev => ({ 
            ...prev, 
            logo: updatedData.logoUrl 
        }));
        
        // Força a atualização visual da imagem
        setLogoVersion(Date.now());
        
        Alert.alert('Sucesso', 'Logo atualizado!');
      }
    } catch (error: any) {
      console.error("Erro upload logo:", error);
      Alert.alert('Erro', 'Falha ao enviar logo. Verifique se o tamanho é menor que 10MB.');
    } finally {
      setUploadingLogo(false);
    }
  };

  const updateField = (field: string, value: string) => {
    if (isOwner) setForm(prev => ({ ...prev, [field]: value }));
  };

  const updateBusinessHours = (day: string, field: string, value: string) => {
    if (!isOwner) return;
    setForm(prev => ({
      ...prev,
      businessHours: {
        ...prev.businessHours,
        [day]: { ...prev.businessHours[day], [field]: value },
      },
    }));
  };

  const updateSetting = (field: string, value: any) => {
    if (isOwner) setForm(prev => ({
        ...prev,
        settings: { ...prev.settings, [field]: value },
    }));
  };

  const handleSignOut = () => {
      Alert.alert('Sair', 'Deseja realmente sair?', [{text: 'Não'}, {text: 'Sim', onPress: signOut}]);
  }

  // 👇 LÓGICA ROBUSTA PARA EXIBIR IMAGEM
  const getLogoSource = () => {
      if (!form.logo) return null;
      
      // 1. Se for local (acabou de escolher na galeria)
      if (form.logo.startsWith('file://')) {
          return { uri: form.logo };
      }
      
      // 2. Se for URL absoluta (http...)
      if (form.logo.startsWith('http')) {
          return { uri: form.logo };
      }

      // 3. Se for caminho do backend (/api/uploads/...)
      // Remove barra extra se tiver
      const baseUrl = API_URL.endsWith('/') ? API_URL.slice(0, -1) : API_URL;
      const path = form.logo.startsWith('/') ? form.logo : `/${form.logo}`;
      
      const fullUrl = `${baseUrl}${path}?t=${logoVersion}`; // Adiciona timestamp para quebrar cache
      
      // console.log("🔍 Tentando carregar imagem:", fullUrl); // Descomente para debugar
      return { uri: fullUrl };
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
      <View style={[styles.headerBackground, { height: Platform.OS === 'ios' ? 200 : 180 }]} />

      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
          <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            
            {/* LOGO SECTION */}
            <View style={styles.profileSection}>
              <TouchableOpacity 
                style={styles.logoContainer} 
                onPress={pickLogo}
                disabled={uploadingLogo || !isOwner}
              >
                {form.logo ? (
                  <Image 
                    source={getLogoSource()} 
                    style={styles.logo} 
                    resizeMode="cover"
                  />
                ) : (
                  <View style={styles.logoPlaceholder}>
                    <Feather name="briefcase" size={40} color={colors.primary} />
                  </View>
                )}
                
                {isOwner && (
                    <View style={styles.cameraBadge}>
                    {uploadingLogo ? <ActivityIndicator size="small" color="#fff" /> : <Feather name="camera" size={14} color="#fff" />}
                    </View>
                )}
              </TouchableOpacity>
              
              <Text style={styles.companyNameTitle}>{form.name || 'Nome da Empresa'}</Text>
              {!isOwner && <Text style={{color: 'rgba(255,255,255,0.8)', fontSize: 12}}>Modo Visualização</Text>}
            </View>

            {/* DADOS GERAIS */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="info" size={18} color={colors.primary} />
                <Text style={styles.cardTitle}>Dados da Empresa</Text>
              </View>
              <View style={styles.inputGroup}>
                <Input label="Nome Fantasia" value={form.name} onChangeText={(v) => updateField('name', v)} editable={isOwner} />
                <Input label="E-mail" value={form.email} onChangeText={(v) => updateField('email', v)} editable={isOwner} />
                <Input label="Telefone" value={form.phone} onChangeText={(v) => updateField('phone', v)} editable={isOwner} />
                <Input label="Endereço" value={form.address} onChangeText={(v) => updateField('address', v)} editable={isOwner} />
                <Input label="Descrição" value={form.description} onChangeText={(v) => updateField('description', v)} multiline editable={isOwner} />
              </View>
            </View>

            {/* HORÁRIOS */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="clock" size={18} color={colors.primary} />
                <Text style={styles.cardTitle}>Horário de Funcionamento</Text>
              </View>
              <View style={styles.hoursList}>
                {days.map(day => (
                  <View key={day.key} style={styles.dayRow}>
                    <Text style={styles.dayLabel}>{day.label}</Text>
                    <View style={styles.timeInputs}>
                      <Input
                        value={form.businessHours[day.key]?.open}
                        onChangeText={(v) => updateBusinessHours(day.key, 'open', v)}
                        placeholder="00:00" style={styles.timeInput}
                        editable={isOwner}
                      />
                      <Text>-</Text>
                      <Input
                        value={form.businessHours[day.key]?.close}
                        onChangeText={(v) => updateBusinessHours(day.key, 'close', v)}
                        placeholder="00:00" style={styles.timeInput}
                        editable={isOwner}
                      />
                    </View>
                  </View>
                ))}
              </View>
            </View>

            {/* REGRAS */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Feather name="sliders" size={18} color={colors.primary} />
                <Text style={styles.cardTitle}>Regras</Text>
              </View>
              <View style={styles.settingRow}>
                <Text style={styles.settingText}>Aceitar agendamento online</Text>
                <Switch 
                  value={form.settings.onlineBooking} 
                  onValueChange={(v) => updateSetting('onlineBooking', v)}
                  disabled={!isOwner}
                />
              </View>
            </View>

            {/* BOTÕES FINAIS */}
            <View style={styles.footerActions}>
              {isOwner && (
                  <Button 
                    title={saving ? "Salvando..." : "Salvar Alterações"} 
                    onPress={handleSubmit} 
                    loading={saving} 
                    icon="save"
                  />
              )}
              <TouchableOpacity style={styles.logoutButton} onPress={handleSignOut}>
                <Feather name="log-out" size={18} color={theme.danger} />
                <Text style={styles.logoutText}>Sair da Conta</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.versionInfo}>App Kairon v1.0</Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

// Styles... (Mantenha os mesmos estilos que você já tem, não mudei nada neles)
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.background },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: theme.background },
  headerBackground: { position: 'absolute', top: 0, left: 0, right: 0, backgroundColor: theme.primary, borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  scrollContent: { paddingHorizontal: 16, paddingBottom: 40 },
  profileSection: { alignItems: 'center', marginTop: Platform.OS === 'android' ? 40 : 20, marginBottom: 20 },
  logoContainer: { position: 'relative', marginBottom: 12 },
  logo: { width: 100, height: 100, borderRadius: 50, borderWidth: 4, borderColor: '#fff', backgroundColor: '#fff' },
  logoPlaceholder: { width: 100, height: 100, borderRadius: 50, backgroundColor: '#E2E8F0', justifyContent: 'center', alignItems: 'center', borderWidth: 4, borderColor: '#fff' },
  cameraBadge: { position: 'absolute', bottom: 0, right: 0, backgroundColor: theme.primary, width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: '#fff' },
  companyNameTitle: { fontSize: 22, fontWeight: 'bold', color: '#fff', marginBottom: 4, textAlign: 'center' },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, borderBottomWidth: 1, borderBottomColor: '#F1F5F9', paddingBottom: 10 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: theme.text, marginLeft: 8 },
  inputGroup: { gap: 12 },
  hoursList: { gap: 12 },
  dayRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  dayLabel: { fontSize: 14, color: theme.textSecondary, width: 80, fontWeight: '500' },
  timeInputs: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  timeInput: { width: 80, textAlign: 'center', height: 40 },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 4 },
  settingText: { fontSize: 14, color: theme.text, flex: 1 },
  footerActions: { gap: 16, marginTop: 8 },
  logoutButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 12, borderRadius: 12, borderWidth: 1, borderColor: '#FECACA', backgroundColor: '#FEF2F2' },
  logoutText: { marginLeft: 8, color: theme.danger, fontWeight: '600' },
  versionInfo: { textAlign: 'center', color: '#CBD5E1', fontSize: 12, marginTop: 24 },
});
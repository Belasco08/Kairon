import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
  StyleSheet,
  StatusBar,
  SafeAreaView,
  Platform,
  Alert
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { LineChart } from 'react-native-chart-kit';

// 1. IMPORTAÇÕES PARA O PDF
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

import { financeService, DashboardData } from '../../services/finance';
import { colors } from '../../styles/colors';

// Configuração Visual (Tema)
const theme = {
  primary: colors.primary || '#2563EB',
  secondary: '#64748B',
  success: '#10B981', // Verde
  danger: '#EF4444',  // Vermelho
  warning: '#F59E0B', // Laranja
  background: '#F8F9FA',
  white: '#FFFFFF',
  text: '#1E293B'
};

/* =========================
   TIPOS
========================= */

type Period = 'day' | 'week' | 'month' | 'year';

interface FinanceSummary {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  appointmentsCount: number;
  averageTicket: number;
}

interface RevenueData {
  labels: string[];
  values: number[];
}

/* =========================
   COMPONENT
========================= */

export function FinanceDashboard() {
  const navigation = useNavigation<any>();
  const screenWidth = Dimensions.get('window').width;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [period, setPeriod] = useState<Period>('month');
  
  // Estado para o Loading do PDF
  const [generatingPdf, setGeneratingPdf] = useState(false);

  const [summary, setSummary] = useState<FinanceSummary>({
    totalRevenue: 0,
    totalExpenses: 0,
    netProfit: 0,
    appointmentsCount: 0,
    averageTicket: 0,
  });

  const [revenueData, setRevenueData] = useState<RevenueData>({
    labels: [],
    values: [],
  });

  /* =========================
     HELPERS & DATA
  ========================= */

  const loadData = useCallback(async () => {
    try {
      setLoading(true);

      const dashboard = await financeService.getDashboard({ period });
      const chartResponse = await financeService.getRevenueChart?.({ period });

      const revenue = dashboard?.revenue ?? 0;
      const expenses = dashboard?.expenses ?? 0;
      const appointments = dashboard?.appointments ?? 0;
      
      setSummary({
        totalRevenue: revenue,
        totalExpenses: expenses,
        netProfit: revenue - expenses,
        appointmentsCount: appointments,
        averageTicket: appointments > 0 ? revenue / appointments : 0,
      });

      const rawLabels = chartResponse?.labels || [];
      const rawValues = chartResponse?.values || [];
      
      setRevenueData({
        labels: rawLabels,
        values: rawValues.length > 0 ? rawValues : [0, 0, 0, 0, 0, 0],
      });

    } catch (error) {
      console.error('Error loading finance data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [period]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);

  /* =========================
     PDF GENERATION LOGIC
  ========================= */
  const generatePDF = async () => {
    try {
      setGeneratingPdf(true);

      const periodLabel = { day: 'Hoje', week: 'Esta Semana', month: 'Este Mês', year: 'Este Ano' }[period];
      const date = new Date().toLocaleDateString('pt-BR');

      // HTML do Relatório
      const htmlContent = `
        <html>
          <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
            <style>
              body { font-family: 'Helvetica', sans-serif; padding: 20px; color: #333; }
              .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid ${theme.primary}; padding-bottom: 20px; }
              .title { font-size: 24px; font-weight: bold; color: ${theme.primary}; }
              .subtitle { font-size: 14px; color: #666; margin-top: 5px; }
              
              .cards-container { display: flex; flex-wrap: wrap; justify-content: space-between; margin-bottom: 30px; }
              .card { width: 48%; background-color: #f8f9fa; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin-bottom: 15px; box-sizing: border-box; }
              .card-label { font-size: 12px; color: #64748b; text-transform: uppercase; }
              .card-value { font-size: 18px; font-weight: bold; margin-top: 5px; color: #1e293b; }
              .highlight { color: ${theme.primary}; }
              .success { color: ${theme.success}; }
              .danger { color: ${theme.danger}; }

              table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              th { background-color: ${theme.primary}; color: white; padding: 10px; text-align: left; }
              td { border-bottom: 1px solid #ddd; padding: 10px; }
              tr:nth-child(even) { background-color: #f2f2f2; }
              
              .footer { margin-top: 40px; text-align: center; font-size: 10px; color: #999; border-top: 1px solid #eee; padding-top: 10px; }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="title">Relatório Financeiro</div>
              <div class="subtitle">Gerado em ${date} • Período: ${periodLabel}</div>
            </div>

            <div class="cards-container">
              <div class="card">
                <div class="card-label">Receita</div>
                <div class="card-value success">${formatCurrency(summary.totalRevenue)}</div>
              </div>
              <div class="card">
                <div class="card-label">Despesas</div>
                <div class="card-value danger">${formatCurrency(summary.totalExpenses)}</div>
              </div>
              <div class="card">
                <div class="card-label">Lucro Líquido</div>
                <div class="card-value highlight">${formatCurrency(summary.netProfit)}</div>
              </div>
              <div class="card">
                <div class="card-label">Ticket Médio</div>
                <div class="card-value">${formatCurrency(summary.averageTicket)}</div>
              </div>
            </div>

            <h3>Detalhamento</h3>
            <table>
              <thead>
                <tr>
                  <th>Métrica</th>
                  <th>Valor</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Total de Atendimentos</td>
                  <td>${summary.appointmentsCount}</td>
                </tr>
                <tr>
                  <td>Faturamento Bruto</td>
                  <td>${formatCurrency(summary.totalRevenue)}</td>
                </tr>
                 <tr>
                  <td>Custos Operacionais</td>
                  <td>${formatCurrency(summary.totalExpenses)}</td>
                </tr>
                <tr>
                  <td><strong>Lucro Líquido</strong></td>
                  <td><strong>${formatCurrency(summary.netProfit)}</strong></td>
                </tr>
              </tbody>
            </table>

            <div class="footer">Relatório automático do App.</div>
          </body>
        </html>
      `;

      // 1. Gera PDF
      const { uri } = await Print.printToFileAsync({
        html: htmlContent,
        base64: false
      });

      // 2. Abre menu de compartilhar
      await Sharing.shareAsync(uri, { UTI: '.pdf', mimeType: 'application/pdf' });

    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível gerar o PDF.');
    } finally {
      setGeneratingPdf(false);
    }
  };

  /* =========================
     RENDER COMPONENTS
  ========================= */

  const renderStatCard = (title: string, value: string, icon: keyof typeof Feather.glyphMap, color: string, subValue?: string) => (
    <View style={styles.statCard}>
      <View style={[styles.iconContainer, { backgroundColor: color + '20' }]}>
        <Feather name={icon} size={20} color={color} />
      </View>
      <View style={{ marginTop: 12 }}>
        <Text style={styles.statLabel}>{title}</Text>
        <Text style={[styles.statValue, { color: color }]}>{value}</Text>
        {subValue && <Text style={styles.statSub}>{subValue}</Text>}
      </View>
    </View>
  );

  const renderPeriodSelector = () => (
    <View style={styles.periodContainer}>
      {(['day', 'week', 'month', 'year'] as Period[]).map((p) => {
        const isActive = period === p;
        const labels = { day: 'Hoje', week: 'Semana', month: 'Mês', year: 'Ano' };
        
        return (
          <TouchableOpacity
            key={p}
            onPress={() => setPeriod(p)}
            style={[styles.periodButton, isActive && styles.periodButtonActive]}
          >
            <Text style={[styles.periodText, isActive && styles.periodTextActive]}>
              {labels[p]}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      <StatusBar barStyle="light-content" backgroundColor={theme.primary} />
      <View style={[styles.headerBackground, { height: Platform.OS === 'ios' ? 280 : 260 }]} />

      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingBottom: 100 }}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />
          }
          showsVerticalScrollIndicator={false}
        >
          {/* HEADER SECTION */}
          <View style={styles.headerContent}>
            <View style={styles.headerTopRow}>
              <View>
                <Text style={styles.headerTitle}>Visão Financeira</Text>
                <Text style={styles.headerSubtitle}>Fluxo de caixa atualizado</Text>
              </View>
              
              {/* BOTÃO DE COMPARTILHAR PDF */}
              <TouchableOpacity 
                style={styles.reportButton}
                onPress={generatePDF}
                disabled={generatingPdf}
              >
                {generatingPdf ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Feather name="share" size={20} color="#fff" />
                )}
              </TouchableOpacity>
            </View>

            {/* MAIN BALANCE */}
            <View style={styles.balanceContainer}>
              <Text style={styles.balanceLabel}>Lucro Líquido ({period === 'day' ? 'Hoje' : period === 'month' ? 'Mensal' : period})</Text>
              <Text style={styles.balanceValue}>{formatCurrency(summary.netProfit)}</Text>
            </View>

            {/* PERIOD SELECTOR INSIDE HEADER */}
            {renderPeriodSelector()}
          </View>

          {/* DASHBOARD CONTENT */}
          <View style={styles.mainContent}>
            
            {/* GRID DE CARDS */}
            <View style={styles.gridContainer}>
              {/* Linha 1 */}
              <View style={styles.gridRow}>
                {renderStatCard('Receita', formatCurrency(summary.totalRevenue), 'arrow-up-circle', theme.success)}
                {renderStatCard('Despesas', formatCurrency(summary.totalExpenses), 'arrow-down-circle', theme.danger)}
              </View>
              {/* Linha 2 */}
              <View style={styles.gridRow}>
                {renderStatCard('Atendimentos', summary.appointmentsCount.toString(), 'calendar', theme.primary)}
                {renderStatCard('Ticket Médio', formatCurrency(summary.averageTicket), 'bar-chart-2', theme.warning)}
              </View>
            </View>

            {/* GRÁFICO */}
            <View style={styles.chartCard}>
              <View style={styles.chartHeader}>
                <Text style={styles.sectionTitle}>Evolução da Receita</Text>
                <Feather name="trending-up" size={20} color={theme.success} />
              </View>
              
              {revenueData.values.length > 0 && !revenueData.values.every(v => v === 0) ? (
                <LineChart
                  data={{
                    labels: revenueData.labels,
                    datasets: [{ data: revenueData.values }],
                  }}
                  width={screenWidth - 48}
                  height={220}
                  yAxisLabel="R$"
                  yAxisSuffix=""
                  yAxisInterval={1}
                  chartConfig={{
                    backgroundColor: "#fff",
                    backgroundGradientFrom: "#fff",
                    backgroundGradientTo: "#fff",
                    decimalPlaces: 0,
                    color: (opacity = 1) => `rgba(37, 99, 235, ${opacity})`,
                    labelColor: (opacity = 1) => `rgba(100, 116, 139, ${opacity})`,
                    style: { borderRadius: 16 },
                    propsForDots: {
                      r: "4",
                      strokeWidth: "2",
                      stroke: theme.primary
                    }
                  }}
                  bezier
                  style={{
                    marginVertical: 8,
                    borderRadius: 16,
                    marginLeft: -10 
                  }}
                />
              ) : (
                <View style={styles.emptyChart}>
                   <Feather name="bar-chart" size={40} color="#CBD5E1" />
                   <Text style={styles.emptyChartText}>Sem dados suficientes para exibir o gráfico.</Text>
                </View>
              )}
            </View>

            {/* LISTA RÁPIDA */}
            <View style={styles.sectionContainer}>
                <Text style={[styles.sectionTitle, { marginBottom: 12, marginLeft: 4 }]}>Resumo Rápido</Text>
                <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Total Bruto</Text>
                    <Text style={styles.summaryValue}>{formatCurrency(summary.totalRevenue)}</Text>
                </View>
                <View style={[styles.summaryRow, { borderBottomWidth: 0 }]}>
                    <Text style={styles.summaryLabel}>Margem de Lucro</Text>
                    <Text style={[styles.summaryValue, { color: theme.success }]}>
                        {summary.totalRevenue > 0 
                            ? `${((summary.netProfit / summary.totalRevenue) * 100).toFixed(1)}%` 
                            : '0%'}
                    </Text>
                </View>
            </View>

          </View>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

/* =========================
   STYLES
========================= */
const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
  },
  // Header Background
  headerBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: theme.primary,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  headerContent: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'android' ? 40 : 10,
    marginBottom: 20,
  },
  headerTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  reportButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 10,
    borderRadius: 12,
  },
  
  // Balance Area
  balanceContainer: {
    marginBottom: 24,
  },
  balanceLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  balanceValue: {
    fontSize: 36,
    fontWeight: '800',
    color: '#fff',
  },

  // Period Selector
  periodContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.1)',
    borderRadius: 12,
    padding: 4,
    justifyContent: 'space-between',
  },
  periodButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 8,
  },
  periodButtonActive: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  periodText: {
    fontSize: 13,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.7)',
  },
  periodTextActive: {
    color: theme.primary,
    fontWeight: '700',
  },

  // Main Content Area
  mainContent: {
    paddingHorizontal: 20,
  },
  
  // Grid System
  gridContainer: {
    gap: 12,
    marginBottom: 20,
  },
  gridRow: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-start',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748B',
    marginBottom: 4,
    fontWeight: '500',
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
  },
  statSub: {
    fontSize: 10,
    color: '#94A3B8',
    marginTop: 2,
  },

  // Chart Card
  chartCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    paddingHorizontal: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1E293B',
  },
  emptyChart: {
      height: 180,
      justifyContent: 'center',
      alignItems: 'center',
  },
  emptyChartText: {
      marginTop: 8,
      color: '#94A3B8',
      fontSize: 14
  },

  // Summary List
  sectionContainer: {
      marginBottom: 20,
  },
  summaryRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      backgroundColor: '#fff',
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: '#F1F5F9',
  },
  summaryLabel: {
      fontSize: 14,
      color: '#64748B',
  },
  summaryValue: {
      fontSize: 14,
      fontWeight: '600',
      color: '#1E293B',
  }
});
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';
import { LineChart } from 'react-native-chart-kit';

import { useAuth } from '../../contexts/AuthContext';
import { financeService, DashboardData } from '../../services/finance';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { StatCard } from '../../components/finance/StatCard';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

/* =========================
   TIPOS
========================= */

type Period = 'day' | 'week' | 'month' | 'year';

interface FinanceSummary {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  appointmentsCount: number;
  averageTicket: number;
  growthPercentage: number;
}

interface RevenueData {
  labels: string[];
  values: number[];
}

interface ComparisonData {
  previousPeriodRevenue: number;
  growthPercentage: number;
}

/* =========================
   COMPONENT
========================= */

export function FinanceDashboard() {
  const navigation = useNavigation<any>();
  const { company } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [period, setPeriod] = useState<Period>('month');

  const [summary, setSummary] = useState<FinanceSummary | null>(null);
  const [revenueData, setRevenueData] = useState<RevenueData>({
    labels: [],
    values: [],
  });
  const [comparisonData, setComparisonData] = useState<ComparisonData>({
    previousPeriodRevenue: 0,
    growthPercentage: 0,
  });

  useEffect(() => {
    loadData();
  }, [period]);

  /* =========================
     DATA LOAD
  ========================= */

  const mapDashboardToSummary = (data: DashboardData): FinanceSummary => ({
    totalRevenue: data.revenue,
    totalExpenses: 0,
    netProfit: data.revenue,
    appointmentsCount: data.appointments,
    averageTicket: data.averageTicket,
    growthPercentage: 0,
  });

  const loadData = async () => {
    try {
      setLoading(true);

      const dashboard = await financeService.getDashboard({ period });
      const chart = await financeService.getRevenueChart?.({ period });
      const comparison = await financeService.getComparison?.({ period });

      setSummary(mapDashboardToSummary(dashboard));

      setRevenueData(
        chart ?? {
          labels: [],
          values: [],
        }
      );

      setComparisonData(
        comparison ?? {
          previousPeriodRevenue: 0,
          growthPercentage: 0,
        }
      );
    } catch (error) {
      console.error('Error loading finance data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  /* =========================
     HELPERS
  ========================= */

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);

  const getPeriodLabel = (p: Period) =>
    ({
      day: 'Hoje',
      week: 'Esta Semana',
      month: 'Este Mês',
      year: 'Este Ano',
    }[p]);

  const screenWidth = Dimensions.get('window').width - 32;

  const chartConfig = {
    backgroundGradientFrom: colors.surface,
    backgroundGradientTo: colors.surface,
    decimalPlaces: 0,
    color: () => colors.primary,
    labelColor: () => colors.textSecondary,
    propsForDots: {
      r: '6',
      strokeWidth: '2',
      stroke: colors.primary,
    },
  };

  if (loading && !refreshing) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  /* =========================
     RENDER
  ========================= */

  return (
    <ScrollView
      style={commonStyles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={{ backgroundColor: colors.primary, padding: 24 }}>
        <View style={[commonStyles.rowBetween, { marginBottom: 16 }]}>
          <View>
            <Text style={[commonStyles.h1, { color: colors.surface }]}>
              Financeiro
            </Text>
            <Text style={[commonStyles.body, { color: 'rgba(255,255,255,0.8)' }]}>
              {getPeriodLabel(period)}
            </Text>
          </View>

          <Button
            title="Relatórios"
            onPress={() => navigation.navigate('Reports')}
            variant="outline"
            size="small"
          />
        </View>

        {/* Period Selector */}
        <View style={[commonStyles.row, { gap: 8 }]}>
          {(['day', 'week', 'month', 'year'] as Period[]).map((p) => (
            <TouchableOpacity
              key={p}
              onPress={() => setPeriod(p)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 20,
                backgroundColor:
                  period === p
                    ? colors.surface
                    : 'rgba(255,255,255,0.2)',
              }}
            >
              <Text
                style={[
                  commonStyles.bodySmall,
                  {
                    color: period === p ? colors.primary : colors.surface,
                  },
                ]}
              >
                {p === 'day'
                  ? 'Dia'
                  : p === 'week'
                  ? 'Semana'
                  : p === 'month'
                  ? 'Mês'
                  : 'Ano'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Stats */}
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 16 }}>
          <StatCard
            title="Faturamento"
            value={formatCurrency(summary?.totalRevenue ?? 0)}
            icon="trending-up"
            color="success"
          />

          <StatCard
            title="Lucro Líquido"
            value={formatCurrency(summary?.netProfit ?? 0)}
            icon="account-balance"
            color="primary"
          />

          <StatCard
            title="Atendimentos"
            value={String(summary?.appointmentsCount ?? 0)}
            icon="calendar-today"
            color="info"
          />
        </View>
      </View>

      {/* Chart */}
      <Card style={{ margin: 16 }}>
        {revenueData.values.length > 0 ? (
          <LineChart
            data={{
              labels: revenueData.labels,
              datasets: [{ data: revenueData.values }],
            }}
            width={screenWidth}
            height={220}
            chartConfig={chartConfig}
            bezier
          />
        ) : (
          <View
            style={{
              height: 220,
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <MaterialIcons
              name="show-chart"
              size={48}
              color={colors.border}
            />
            <Text style={{ marginTop: 12, color: colors.textSecondary }}>
              Sem dados para o período selecionado
            </Text>
          </View>
        )}
      </Card>
    </ScrollView>
  );
}

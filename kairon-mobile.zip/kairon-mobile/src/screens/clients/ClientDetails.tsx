import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  Linking,
} from 'react-native';
import {
  useNavigation,
  useRoute,
  RouteProp,
} from '@react-navigation/native';
import type { AppNavigation } from '../../@types/navigation';
import { MaterialIcons as Icon } from '@expo/vector-icons';

import { clientService } from '../../services/clients';
import { appointmentService } from '../../services/appointments';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

/* =========================
   TIPAGEM DE ROTAS
========================= */

interface RouteParams {
  clientId: string;
}

type ClientDetailsRouteProp = RouteProp<
  { ClientDetails: RouteParams },
  'ClientDetails'
>;

export function ClientDetails() {
  const navigation = useNavigation<AppNavigation>();
  const route = useRoute<ClientDetailsRouteProp>();
  const { clientId } = route.params;

  const [loading, setLoading] = useState<boolean>(true);
  const [appointmentsLoading, setAppointmentsLoading] = useState<boolean>(false);
  const [client, setClient] = useState<any>(null);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'info' | 'appointments'>('info');

  useEffect(() => {
    loadClient();
    loadAppointments();
  }, [clientId]);

  const loadClient = async () => {
    try {
      const data = await clientService.get(clientId);
      setClient(data);
    } catch {
      Alert.alert('Erro', 'Cliente não encontrado');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  const loadAppointments = async () => {
    try {
      setAppointmentsLoading(true);
      const data = await appointmentService.list({
        clientId,
        limit: 10,
      });
      setAppointments(data);
    } finally {
      setAppointmentsLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!client) {
    return (
      <EmptyState
        icon="error"
        title="Cliente não encontrado"
        description="Este cliente não existe"
        actionText="Voltar"
        onAction={() => navigation.goBack()}
      />
    );
  }

  return (
    <ScrollView style={commonStyles.container}>
      <View style={{ padding: 16 }}>
        <Text style={[commonStyles.body, { fontSize: 18, fontWeight: '600' }]}>
          {client.name}
        </Text>

        <Button
          title="Criar Agendamento"
          onPress={() =>
            navigation.navigate('CreateAppointment', {
              clientId: client.id,
            })
          }
        />

        {activeTab === 'appointments' && (
          appointmentsLoading ? (
            <ActivityIndicator />
          ) : appointments.length === 0 ? (
            <EmptyState
              icon="event-busy"
              title="Nenhum agendamento"
              description="Esse cliente ainda não tem agendamentos"
              actionText="Agendar"
              onAction={() =>
                navigation.navigate('CreateAppointment', {
                  clientId: client.id,
                })
              }
            />
          ) : (
            appointments.map(item => (
              <TouchableOpacity
                key={item.id}
                onPress={() =>
                  navigation.navigate('AppointmentDetails', {
                    appointmentId: item.id,
                  })
                }
              >
                <Card>
                  <Text>{item.status}</Text>
                </Card>
              </TouchableOpacity>
            ))
          )
        )}
      </View>
    </ScrollView>
  );
}

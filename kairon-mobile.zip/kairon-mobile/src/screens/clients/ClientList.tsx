import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Image,
  StyleSheet,
  StatusBar,
  SafeAreaView,
  Platform
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { AppNavigation } from '../../@types/navigation';
// Padronizando com Feather
import { Feather } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { clientService } from '../../services/clients';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
// Badge customizada (ou usamos uma View simples se preferir)
import { colors } from '../../styles/colors';

interface Client {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  totalAppointments: number;
  totalSpent: number;
  lastAppointment?: string;
  isActive: boolean;
  notes?: string;
}

export function ClientList() {
  const navigation = useNavigation<AppNavigation>();
  const { user } = useAuth();

  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [clients, setClients] = useState<Client[]>([]);
  const [search, setSearch] = useState<string>('');

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    try {
      setLoading(true);
      const response = await clientService.list();
      setClients(response);
    } catch (error) {
      console.error('Error loading clients:', error);
      Alert.alert('Erro', 'Não foi possível carregar os clientes');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadClients();
  };

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(search.toLowerCase()) ||
    client.email.toLowerCase().includes(search.toLowerCase()) ||
    (client.phone && client.phone.includes(search))
  );

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Nunca';
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  // --- RENDERIZAÇÃO DO CARD ---
  const renderClient = ({ item }: { item: Client }) => (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.7}
      onPress={() => navigation.navigate('ClientDetails', { clientId: item.id })}
    >
      <View style={styles.cardMainRow}>
        {/* Avatar Section */}
        <View style={styles.avatarContainer}>
          {item.avatar ? (
            <Image
              source={{ uri: item.avatar }}
              style={styles.avatarImage}
            />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <Text style={styles.avatarText}>
                {item.name.charAt(0).toUpperCase()}
              </Text>
            </View>
          )}
        </View>

        {/* Info Section */}
        <View style={styles.cardContent}>
          <View style={styles.headerRow}>
            <Text style={styles.clientName} numberOfLines={1}>{item.name}</Text>
            
            {/* Badge de Atendimentos */}
            {item.totalAppointments > 0 && (
                <View style={[
                    styles.badge, 
                    item.totalAppointments > 10 ? styles.badgeSuccess : styles.badgeInfo
                ]}>
                    <Text style={[
                        styles.badgeText,
                        item.totalAppointments > 10 ? styles.badgeTextSuccess : styles.badgeTextInfo
                    ]}>
                        {item.totalAppointments} atend.
                    </Text>
                </View>
            )}
          </View>

          {/* Contatos */}
          <View style={styles.contactContainer}>
             <View style={styles.contactRow}>
                <Feather name="mail" size={12} color="#94A3B8" />
                <Text style={styles.contactText} numberOfLines={1}>{item.email}</Text>
             </View>
             
             {item.phone && (
                <View style={styles.contactRow}>
                    <Feather name="phone" size={12} color="#94A3B8" />
                    <Text style={styles.contactText}>{item.phone}</Text>
                </View>
             )}
          </View>
        </View>
      </View>

      {/* Footer do Card (Divisor) */}
      <View style={styles.cardFooter}>
         <View>
            <Text style={styles.footerLabel}>Total Gasto</Text>
            <Text style={styles.footerValuePrimary}>{formatCurrency(item.totalSpent)}</Text>
         </View>
         
         <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.footerLabel}>Última Visita</Text>
            <Text style={styles.footerValueSecondary}>{formatDate(item.lastAppointment)}</Text>
         </View>
      </View>
    </TouchableOpacity>
  );

  const renderHeader = () => (
    <View style={styles.headerContainer}>
        {/* Topo: Título e Botão Novo */}
        <View style={styles.headerTop}>
            <View>
                <Text style={styles.headerTitle}>Clientes</Text>
                <Text style={styles.headerSubtitle}>{filteredClients.length} cadastrados</Text>
            </View>
            <Button
                title="Novo"
                onPress={() => navigation.navigate('CreateClient')} // Ajuste a rota se necessário
                size="small"
                // icon={<Feather name="plus" size={16} color="#fff"/>}
            />
        </View>

        {/* Busca */}
        <View style={styles.searchContainer}>
             <Input
                placeholder="Buscar cliente..."
                value={search}
                onChangeText={setSearch}
                // Se o seu componente Input suportar prop icon:
                // icon="search"
                // Se não suportar, pode remover ou ajustar
             />
        </View>
    </View>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F9FA" />
      <FlatList
        data={filteredClients}
        keyExtractor={(item) => item.id}
        renderItem={renderClient}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <EmptyState
            title="Nenhum cliente"
            description="Use a busca ou cadastre um novo cliente."
          />
        }
      />
    </SafeAreaView>
  );
}

// 🎨 ESTILOS PROFISSIONAIS
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    // Ajuste seguro para Android
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 0,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
  },
  listContent: {
    paddingBottom: 80,
    paddingHorizontal: 16,
  },

  // HEADER
  headerContainer: {
    paddingVertical: 10,
    marginBottom: 10,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1E293B',
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 2,
  },
  searchContainer: {
    // Caso queira adicionar sombra ou fundo na busca
  },

  // CARD
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  cardMainRow: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  
  // AVATAR
  avatarContainer: {
    marginRight: 16,
  },
  avatarImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E2E8F0',
  },
  avatarPlaceholder: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E0F2FE', // Azul bem claro
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.primary, // Sua cor primária
  },

  // INFO CONTENT
  cardContent: {
    flex: 1,
    justifyContent: 'center',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  clientName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    flexShrink: 1,
    marginRight: 8,
  },
  contactContainer: {
    marginTop: 2,
    gap: 4,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contactText: {
    fontSize: 13,
    color: '#64748B',
    marginLeft: 6,
  },

  // BADGES
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
  },
  badgeInfo: { backgroundColor: '#F1F5F9' },
  badgeSuccess: { backgroundColor: '#DCFCE7' }, // Verde claro
  
  badgeText: { fontSize: 11, fontWeight: '600' },
  badgeTextInfo: { color: '#64748B' },
  badgeTextSuccess: { color: '#166534' }, // Verde escuro

  // FOOTER (Separador)
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 12,
    marginTop: 4,
  },
  footerLabel: {
    fontSize: 11,
    color: '#94A3B8',
    textTransform: 'uppercase',
    fontWeight: '600',
    marginBottom: 2,
  },
  footerValuePrimary: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.success || '#16A34A', // Verde sucesso
  },
  footerValueSecondary: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1E293B',
  },
});
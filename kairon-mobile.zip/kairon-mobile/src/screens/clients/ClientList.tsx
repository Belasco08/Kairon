import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Image,
  StyleSheet,
  StatusBar,
  SafeAreaView,
  Platform
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { clientService } from '../../services/clients'; 
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';

interface Client {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  totalAppointments: number;
  totalSpent: number;
  // lastAppointment?: string; // Removido do uso, não precisamos mais tipar se não formos usar
  notes?: string;
}

export function ClientList() {
  const navigation = useNavigation<any>();
  const { user } = useAuth(); 

  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [clients, setClients] = useState<Client[]>([]);
  const [search, setSearch] = useState<string>('');

  const loadClients = async () => {
    try {
      // SEGURANÇA: Se não tiver usuário logado carregado ainda, não busca nada
      // Isso evita que o backend receba null e devolva "todos os clientes da empresa"
      if (!user?.id) {
          console.log("Aguardando usuário carregar...");
          return;
      }

      console.log("Buscando clientes para o profissional:", user.id);

      if (!refreshing) setLoading(true);
      
      const response = await clientService.list({ 
          professionalId: user.id 
      }); 
      
      setClients(response);
    } catch (error) {
      console.error('Error loading clients:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadClients();
    }, [user?.id]) // Adicionado user?.id na dependência para recarregar quando o user for identificado
  );

  const onRefresh = () => {
    setRefreshing(true);
    loadClients();
  };

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(search.toLowerCase()) ||
    (client.email && client.email.toLowerCase().includes(search.toLowerCase())) ||
    (client.phone && client.phone.includes(search))
  );

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const renderClient = ({ item }: { item: Client }) => (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.7}
      onPress={() => navigation.navigate('ClientDetails', { clientId: item.id })}
    >
      <View style={styles.cardMainRow}>
        <View style={styles.avatarContainer}>
           <View style={styles.avatarPlaceholder}>
              <Text style={styles.avatarText}>
                {item.name.charAt(0).toUpperCase()}
              </Text>
           </View>
        </View>

        <View style={styles.cardContent}>
          <View style={styles.headerRow}>
            <Text style={styles.clientName} numberOfLines={1}>{item.name}</Text>
            
            {item.totalAppointments > 0 && (
                <View style={[
                    styles.badge, 
                    item.totalAppointments > 5 ? styles.badgeSuccess : styles.badgeInfo
                ]}>
                    <Text style={[
                        styles.badgeText,
                        item.totalAppointments > 5 ? styles.badgeTextSuccess : styles.badgeTextInfo
                    ]}>
                        {item.totalAppointments} idas
                    </Text>
                </View>
            )}
          </View>

          <View style={styles.contactContainer}>
             {item.phone && (
                <View style={styles.contactRow}>
                    <Feather name="phone" size={12} color="#94A3B8" />
                    <Text style={styles.contactText}>{item.phone}</Text>
                </View>
             )}
          </View>
        </View>
      </View>

      <View style={styles.cardFooter}>
         {/* APENAS TOTAL GASTO AGORA */}
         <View>
            <Text style={styles.footerLabel}>Total Gasto</Text>
            <Text style={styles.footerValuePrimary}>{formatCurrency(item.totalSpent)}</Text>
         </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F9FA" />
      
      <View style={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 8 }}>
         <View style={styles.headerTop}>
             <View>
                 <Text style={styles.headerTitle}>Clientes</Text>
                 <Text style={styles.headerSubtitle}>{filteredClients.length} cadastrados</Text>
             </View>
             <Button
                 title="Novo"
                 onPress={() => navigation.navigate('CreateClient')}
             />
         </View>

         <Input
            placeholder="Buscar por nome ou telefone..."
            value={search}
            onChangeText={setSearch}
         />
      </View>

      {loading && !refreshing ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={filteredClients}
          keyExtractor={(item) => item.id}
          renderItem={renderClient}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <EmptyState
              title="Nenhum cliente encontrado"
              description={search ? "Tente buscar por outro termo." : "Você ainda não atendeu nenhum cliente."}
            />
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) : 0,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: 80,
    paddingHorizontal: 16,
    paddingTop: 8
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1E293B',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748B',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  cardMainRow: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  avatarContainer: {
    marginRight: 12,
  },
  avatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E0F2FE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.primary,
  },
  cardContent: {
    flex: 1,
    justifyContent: 'center',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  clientName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    flex: 1,
    marginRight: 8,
  },
  contactContainer: {
    marginTop: 2,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contactText: {
    fontSize: 13,
    color: '#64748B',
    marginLeft: 6,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  badgeInfo: { backgroundColor: '#F1F5F9' },
  badgeSuccess: { backgroundColor: '#DCFCE7' },
  badgeText: { fontSize: 10, fontWeight: '700' },
  badgeTextInfo: { color: '#64748B' },
  badgeTextSuccess: { color: '#166534' },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-start', // Mudado para ficar à esquerda
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingTop: 12,
    marginTop: 4,
  },
  footerLabel: {
    fontSize: 10,
    color: '#94A3B8',
    fontWeight: '700',
    textTransform: 'uppercase',
    marginBottom: 2,
  },
  footerValuePrimary: {
    fontSize: 14,
    fontWeight: '700',
    color: '#16A34A',
  },
});
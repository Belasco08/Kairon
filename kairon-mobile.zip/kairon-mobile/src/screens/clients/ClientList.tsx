import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { AppNavigation } from '../../@types/navigation';
import { MaterialIcons as Icon } from '@expo/vector-icons';

import { useAuth } from '../../contexts/AuthContext';
import { clientService } from '../../services/clients';
import { Input } from '../../components/ui/Input';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { Badge } from '../../components/ui/Badge';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

interface Client {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  totalAppointments: number;
  totalSpent: number;
  lastAppointment?: string;
  isActive: boolean;
  notes?: string;
}

export function ClientList() {
  const navigation = useNavigation<AppNavigation>();
  const { user, company } = useAuth();

  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [clients, setClients] = useState<Client[]>([]);
  const [search, setSearch] = useState<string>('');

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    try {
      setLoading(true);
      const response = await clientService.list();
      setClients(response);
    } catch (error) {
      console.error('Error loading clients:', error);
      Alert.alert('Erro', 'Não foi possível carregar os clientes');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadClients();
  };

  const filteredClients = clients.filter(client =>
    client.name.toLowerCase().includes(search.toLowerCase()) ||
    client.email.toLowerCase().includes(search.toLowerCase()) ||
    (client.phone && client.phone.includes(search))
  );

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Nunca';
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  const renderClient = ({ item }: { item: Client }) => (
    <TouchableOpacity
      style={commonStyles.card}
      onPress={() =>
        navigation.navigate('ClientDetails', {
          clientId: item.id,
        })
      }
    >
      <View style={[commonStyles.row, { alignItems: 'flex-start' }]}>
        <View style={{ marginRight: 16 }}>
          {item.avatar ? (
            <Image
              source={{ uri: item.avatar }}
              style={{
                width: 60,
                height: 60,
                borderRadius: 30,
                backgroundColor: colors.border,
              }}
            />
          ) : (
            <View
              style={{
                width: 60,
                height: 60,
                borderRadius: 30,
                backgroundColor: colors.primaryLight,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={[commonStyles.h2, { color: colors.primary }]}>
                {item.name.charAt(0).toUpperCase()}
              </Text>
            </View>
          )}
        </View>

        <View style={{ flex: 1 }}>
          <View style={[commonStyles.rowBetween, { marginBottom: 8 }]}>
            <Text style={[commonStyles.h3, { flex: 1 }]}>{item.name}</Text>

            <Badge
              variant={
                item.totalAppointments > 10
                  ? 'success'
                  : item.totalAppointments > 0
                  ? 'info'
                  : 'info' // 🔧 muted → info (tipagem corrigida)
              }
              text={`${item.totalAppointments} atend.`}
              size="small"
            />
          </View>

          <View style={{ marginBottom: 8 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Icon name="email" size={14} color={colors.textSecondary} />
              <Text style={[commonStyles.bodySmall, { marginLeft: 6 }]}>
                {item.email}
              </Text>
            </View>

            {item.phone && (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Icon name="phone" size={14} color={colors.textSecondary} />
                <Text style={[commonStyles.bodySmall, { marginLeft: 6 }]}>
                  {item.phone}
                </Text>
              </View>
            )}
          </View>

          <View style={[commonStyles.rowBetween, { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 8 }]}>
            <View>
              <Text style={commonStyles.caption}>Gasto Total</Text>
              <Text style={{ color: colors.success }}>
                {formatCurrency(item.totalSpent)}
              </Text>
            </View>

            <View style={{ alignItems: 'flex-end' }}>
              <Text style={commonStyles.caption}>Última Visita</Text>
              <Text>{formatDate(item.lastAppointment)}</Text>
            </View>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderHeader = () => (
    <View style={{ padding: 16 }}>
      <Input
        placeholder="Buscar por nome, e-mail ou telefone..."
        value={search}
        onChangeText={setSearch}
        {...({ icon: 'search' } as any)} // 🔧 extensão segura de tipagem
        style={{ marginBottom: 16 }}
      />
    </View>
  );

  if (loading && !refreshing) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={commonStyles.container}>
      <FlatList
        data={filteredClients}
        keyExtractor={(item) => item.id}
        renderItem={renderClient}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={
          <EmptyState
            icon="people"
            title="Nenhum cliente encontrado"
            description="Tente buscar com outros termos"
          />
        }
      />
    </View>
  );
}

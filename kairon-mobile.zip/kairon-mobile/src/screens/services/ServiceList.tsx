import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Switch,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useAuth } from '../../contexts/AuthContext';
import { serviceService } from '../../services/services';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  duration: number;
  category?: string;
  isActive: boolean;
  onlineBooking: boolean;
  professional?: {
    id: string;
    name: string;
  };
}

// Defina as rotas e params do stack
type RootStackParamList = {
  ServiceList: undefined;
  CreateService: undefined;
  EditService: { serviceId: string };
};

// Tipagem da navegação para ServiceList
type ServiceListNavigationProp = NativeStackNavigationProp<RootStackParamList, 'ServiceList'>;

export function ServiceList() {
  const navigation = useNavigation<ServiceListNavigationProp>();
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [services, setServices] = useState<Service[]>([]);
  const [filterActive, setFilterActive] = useState(true);

  useEffect(() => {
    loadServices();
  }, [filterActive]);

  const loadServices = async () => {
    try {
      setLoading(true);
      const response = await serviceService.list();
      const filtered = filterActive 
        ? response.filter((s: any) => s.isActive)
        : response;
      setServices(filtered);
    } catch (error) {
      console.error('Error loading services:', error);
      Alert.alert('Erro', 'Não foi possível carregar os serviços');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadServices();
  };

  const toggleOnlineBooking = async (serviceId: string, currentValue: boolean) => {
    try {
      await serviceService.update(serviceId, { onlineBooking: !currentValue });
      setServices(prev =>
        prev.map(s => s.id === serviceId ? { ...s, onlineBooking: !currentValue } : s)
      );
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o serviço');
    }
  };

  const toggleActiveStatus = async (serviceId: string, currentValue: boolean) => {
    try {
      await serviceService.update(serviceId, { isActive: !currentValue });
      setServices(prev =>
        prev.map(s => s.id === serviceId ? { ...s, isActive: !currentValue } : s)
      );
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  const handleDelete = async (serviceId: string) => {
    Alert.alert('Excluir Serviço', 'Tem certeza que deseja excluir este serviço?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: async () => {
          try {
            await serviceService.delete(serviceId);
            setServices(prev => prev.filter(s => s.id !== serviceId));
            Alert.alert('Sucesso', 'Serviço excluído com sucesso');
          } catch {
            Alert.alert('Erro', 'Não foi possível excluir o serviço');
          }
        },
      },
    ]);
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  const renderService = ({ item }: { item: Service }) => (
    <TouchableOpacity
      style={[commonStyles.card, !item.isActive && { opacity: 0.6 }]}
      onPress={() => {
        if (user?.role === 'OWNER') {
          navigation.navigate('EditService', { serviceId: item.id });
        }
      }}
    >
      <View style={[commonStyles.rowBetween, { marginBottom: 12 }]}>
        <View style={{ flex: 1 }}>
          <View style={[commonStyles.row, { marginBottom: 4 }]}>
            <Text style={[commonStyles.body, { fontWeight: '600', flex: 1 }]}>
              {item.name}
            </Text>
            {!item.isActive && (
              <Text style={[commonStyles.caption, { color: colors.textMuted, marginLeft: 8 }]}>
                Inativo
              </Text>
            )}
          </View>

          {item.description && (
            <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginBottom: 4 }]}>
              {item.description}
            </Text>
          )}

          {item.category && (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
              <Icon name="category" size={14} color={colors.textSecondary} />
              <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginLeft: 4 }]}>
                {item.category}
              </Text>
            </View>
          )}

          {item.professional && (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Icon name="person" size={14} color={colors.textSecondary} />
              <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginLeft: 4 }]}>
                {item.professional.name}
              </Text>
            </View>
          )}
        </View>

        <View style={{ alignItems: 'flex-end', gap: 8 }}>
          <Text style={[commonStyles.h3, { color: colors.primary }]}>
            {formatCurrency(item.price)}
          </Text>
          <Text style={[commonStyles.caption, { color: colors.textMuted }]}>
            {item.duration} min
          </Text>
        </View>
      </View>

      <View style={[commonStyles.rowBetween, { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12 }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginRight: 8 }]}>Ativo</Text>
            <Switch
              value={item.isActive}
              onValueChange={() => toggleActiveStatus(item.id, item.isActive)}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.surface}
            />
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginRight: 8 }]}>Online</Text>
            <Switch
              value={item.onlineBooking}
              onValueChange={() => toggleOnlineBooking(item.id, item.onlineBooking)}
              trackColor={{ false: colors.border, true: colors.success }}
              thumbColor={colors.surface}
              disabled={!item.isActive}
            />
          </View>
        </View>

        {user?.role === 'OWNER' && (
          <TouchableOpacity onPress={() => handleDelete(item.id)} style={{ padding: 8 }}>
            <Icon name="delete" size={20} color={colors.error} />
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );

  const renderHeader = () => (
    <View style={{ backgroundColor: colors.surface, padding: 16 }}>
      <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
        <Text style={commonStyles.h2}>Serviços</Text>
        {user?.role === 'OWNER' && (
          <Button
            title="+ Novo"
            onPress={() => navigation.navigate('CreateService')}
            size="small"
          />
        )}
      </View>

      <View style={[commonStyles.rowBetween]}>
        <View>
          <Text style={commonStyles.body}>{services.length} serviços</Text>
          <Text style={[commonStyles.caption, { color: colors.textMuted }]}>
            {services.filter(s => s.onlineBooking).length} disponíveis online
          </Text>
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginRight: 8 }]}>
            Mostrar inativos
          </Text>
          <Switch
            value={filterActive}
            onValueChange={setFilterActive}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor={colors.surface}
          />
        </View>
      </View>
    </View>
  );

  if (loading && !refreshing) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={commonStyles.container}>
      <FlatList
        data={services}
        keyExtractor={(item) => item.id}
        renderItem={renderService}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        contentContainerStyle={{ padding: 16 }}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={
          <EmptyState
            icon="style"
            title="Nenhum serviço cadastrado"
            description="Comece cadastrando seus primeiros serviços"
            actionText="Criar Serviço"
            onAction={() => navigation.navigate('CreateService')}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

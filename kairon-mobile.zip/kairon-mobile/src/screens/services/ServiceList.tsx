import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Switch,
  StyleSheet,
  StatusBar,
  SafeAreaView, // 1. Importar SafeAreaView
  Platform      // 2. Importar Platform para detectar se é Android/iOS
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Feather } from '@expo/vector-icons'; 

import { useAuth } from '../../contexts/AuthContext';
import { serviceService } from '../../services/services';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';

interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  duration: number;
  category?: string;
  isActive?: boolean; 
  active?: boolean;
  onlineBooking: boolean;
  professionalId?: string; 
  professionalName?: string;
}

type RootStackParamList = {
  ServiceList: undefined;
  CreateService: undefined;
  EditService: { serviceId: string };
};

type ServiceListNavigationProp = NativeStackNavigationProp<RootStackParamList, 'ServiceList'>;

export function ServiceList() {
  const navigation = useNavigation<ServiceListNavigationProp>();
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [services, setServices] = useState<Service[]>([]);
  const [showOnlyActive, setShowOnlyActive] = useState(false); 

  useEffect(() => {
    loadServices();
  }, []); 

  const loadServices = async () => {
    try {
      setLoading(true);
      const response = await serviceService.list();
      const data = Array.isArray(response) ? response : (response.content || []);
      setServices(data);
    } catch (error) {
      console.error('Error loading services:', error);
      Alert.alert('Erro', 'Não foi possível carregar os serviços');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadServices();
  };

  const isServiceActive = (service: Service) => {
    return service.isActive !== undefined ? service.isActive : service.active;
  };

  const toggleActiveStatus = async (serviceId: string, currentStatus: boolean | undefined) => {
    try {
      const newValue = !currentStatus;
      await serviceService.update(serviceId, { isActive: newValue } as any);
      setServices(prev => prev.map(s => 
        s.id === serviceId ? { ...s, isActive: newValue, active: newValue } : s
      ));
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  const filteredServices = services.filter(service => {
    if (showOnlyActive) {
      return isServiceActive(service) === true;
    }
    return true;
  });

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  // --- RENDERIZAÇÃO DO CARD ---
  const renderService = ({ item }: { item: Service }) => {
    const active = isServiceActive(item);

    return (
      <TouchableOpacity
        style={[styles.card, !active && styles.cardInactive]}
        activeOpacity={0.7}
        onPress={() => navigation.navigate('EditService', { serviceId: item.id })}
      >
        <View style={styles.cardContent}>
          <View style={styles.cardHeader}>
            <Text style={styles.serviceName} numberOfLines={1}>{item.name}</Text>
            {!active && (
              <View style={styles.inactiveBadge}>
                <Text style={styles.inactiveText}>Inativo</Text>
              </View>
            )}
          </View>

          {item.description ? (
            <Text style={styles.serviceDescription} numberOfLines={2}>
              {item.description}
            </Text>
          ) : null}

          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <Feather name="clock" size={14} color={colors.textSecondary || '#666'} />
              <Text style={styles.metaText}>{item.duration} min</Text>
            </View>

            {item.category && (
              <View style={styles.metaItem}>
                <Feather name="tag" size={14} color={colors.textSecondary || '#666'} />
                <Text style={styles.metaText}>{item.category}</Text>
              </View>
            )}
            
            {item.professionalName && (
               <View style={styles.metaItem}>
                <Feather name="user" size={14} color={colors.textSecondary || '#666'} />
                <Text style={styles.metaText}>{item.professionalName}</Text>
              </View>
            )}
          </View>
        </View>

        <View style={styles.cardActions}>
          <Text style={styles.servicePrice}>{formatCurrency(item.price)}</Text>
          
          <View style={styles.switchContainer}>
            <Switch
              value={!!active}
              onValueChange={() => toggleActiveStatus(item.id, active)}
              trackColor={{ false: '#E2E8F0', true: colors.primary + '80' }}
              thumbColor={!!active ? colors.primary : '#94A3B8'}
              style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
            />
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderHeader = () => (
    <View style={styles.headerContainer}>
      <View style={styles.headerTop}>
        <View>
          <Text style={styles.headerTitle}>Serviços</Text>
          <Text style={styles.headerSubtitle}>{filteredServices.length} cadastrados</Text>
        </View>
        <Button
          title="Novo Serviço"
          onPress={() => navigation.navigate('CreateService')}
          size="small"
        />
      </View>

      <View style={styles.filterRow}>
        <TouchableOpacity 
          style={styles.filterContainer} 
          activeOpacity={1}
          onPress={() => setShowOnlyActive(!showOnlyActive)}
        >
            <Text style={styles.filterText}>Ocultar inativos</Text>
            <Switch
              value={showOnlyActive}
              onValueChange={setShowOnlyActive}
              trackColor={{ false: '#E2E8F0', true: colors.primary }}
              thumbColor={'#fff'}
              size="small"
              style={{ transform: [{ scaleX: 0.7 }, { scaleY: 0.7 }] }}
            />
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    // 3. Substituímos View por SafeAreaView
    <SafeAreaView style={styles.container}>
      {/* StatusBar configura a cor dos ícones da barra (bateria, wifi) */}
      <StatusBar barStyle="dark-content" backgroundColor="#F8F9FA" />
      
      <FlatList
        data={filteredServices}
        keyExtractor={(item) => item.id}
        renderItem={renderService}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <EmptyState
            title="Nenhum serviço"
            description="Cadastre seus serviços para começar a agendar."
          />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    // 4. FIX FINAL: Adiciona padding no topo baseado no SO
    // Se for Android, pega a altura da barra de status + 10px de respiro
    // Se for iOS, o SafeAreaView já cuida do notch, não precisa adicionar muito extra
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 0,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
  },
  listContent: {
    paddingBottom: 80,
    paddingHorizontal: 16,
  },
  
  // Header
  headerContainer: {
    paddingVertical: 20, // Esse padding vertical dá um "ar" extra entre o topo e o título
    backgroundColor: '#F8F9FA',
    marginBottom: 8,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1E293B',
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 2,
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  filterText: {
    fontSize: 13,
    color: '#64748B',
    marginRight: 8,
  },

  // Card Styles
  card: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  cardInactive: {
    opacity: 0.8,
    backgroundColor: '#F1F5F9',
    borderColor: '#E2E8F0',
    shadowOpacity: 0,
    elevation: 0,
  },
  cardContent: {
    flex: 1,
    marginRight: 12,
  },
  cardActions: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingLeft: 8,
    borderLeftWidth: 1,
    borderLeftColor: '#F1F5F9',
  },
  
  // Conteúdo Interno do Card
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    marginRight: 8,
    flexShrink: 1,
  },
  inactiveBadge: {
    backgroundColor: '#E2E8F0',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  inactiveText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#64748B',
    textTransform: 'uppercase',
  },
  serviceDescription: {
    fontSize: 13,
    color: '#64748B',
    marginBottom: 12,
    lineHeight: 18,
  },
  
  // Metadados
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 12,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  metaText: {
    fontSize: 12,
    color: '#64748B',
    marginLeft: 4,
    fontWeight: '500',
  },

  // Coluna da Direita
  servicePrice: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.primary,
  },
  switchContainer: {
    marginTop: 8,
  },
});
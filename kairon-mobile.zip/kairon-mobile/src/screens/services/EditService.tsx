import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Switch,
  ActivityIndicator,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useCompany } from '../../hooks/useCompany';
import { serviceService } from '../../services/services';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

interface ServiceForm {
  name: string;
  description: string;
  price: string;
  duration: string;
  category: string;
  isActive: boolean;
  onlineBooking: boolean;
  professionalId?: string;
}

interface RouteParams {
  serviceId: string;
}

export function EditService() {
  const navigation = useNavigation();
  const route = useRoute();
  const { serviceId } = route.params as RouteParams;
  const { company } = useCompany();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<ServiceForm>({
    name: '',
    description: '',
    price: '',
    duration: '',
    category: '',
    isActive: true,
    onlineBooking: true,
  });
  const [errors, setErrors] = useState<Partial<Record<keyof ServiceForm, string>>>({});

  useEffect(() => {
    loadService();
  }, [serviceId]);

  const loadService = async () => {
    try {
      setLoading(true);
      const service = await serviceService.get(serviceId);
      
      setForm({
        name: service.name,
        description: service.description || '',
        price: service.price.toString(),
        duration: service.duration.toString(),
        category: service.category || '',
        isActive: service.isActive,
        onlineBooking: service.onlineBooking,
        professionalId: service.professionalId,
      });
    } catch (error) {
      console.error('Error loading service:', error);
      Alert.alert('Erro', 'Não foi possível carregar o serviço');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ServiceForm, string>> = {};

    if (!form.name.trim()) {
      newErrors.name = 'Nome é obrigatório';
    }

    if (!form.price) {
      newErrors.price = 'Preço é obrigatório';
    } else if (parseFloat(form.price) <= 0) {
      newErrors.price = 'Preço deve ser maior que zero';
    }

    if (!form.duration) {
      newErrors.duration = 'Duração é obrigatória';
    } else if (parseInt(form.duration) <= 0) {
      newErrors.duration = 'Duração deve ser maior que zero';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setSaving(true);
    try {
      const serviceData = {
        ...form,
        price: parseFloat(form.price),
        duration: parseInt(form.duration),
        companyId: company?.id,
      };

      await serviceService.update(serviceId, serviceData);
      
      Alert.alert(
        'Sucesso',
        'Serviço atualizado com sucesso!',
        [
          {
            text: 'OK',
            onPress: () => navigation.goBack(),
          },
        ]
      );
    } catch (error: any) {
      console.error('Error updating service:', error);
      Alert.alert(
        'Erro',
        error.response?.data?.message || 'Não foi possível atualizar o serviço'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Excluir Serviço',
      'Tem certeza que deseja excluir este serviço? Esta ação não pode ser desfeita.',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              await serviceService.delete(serviceId);
              Alert.alert('Sucesso', 'Serviço excluído com sucesso');
              navigation.goBack();
            } catch (error) {
              Alert.alert('Erro', 'Não foi possível excluir o serviço');
            }
          },
        },
      ]
    );
  };

  const updateForm = (field: keyof ServiceForm, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView 
      style={commonStyles.container}
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ marginBottom: 24 }}>
        <Text style={commonStyles.h1}>Editar Serviço</Text>
        <Text style={[commonStyles.body, { color: colors.textSecondary, marginTop: 4 }]}>
          Atualize as informações do serviço
        </Text>
      </View>

      <Card>
        <View style={{ gap: 16 }}>
          <Input
            label="Nome do Serviço *"
            value={form.name}
            onChangeText={(value) => updateForm('name', value)}
            placeholder="Ex: Corte de Cabelo"
            error={errors.name}
          />

          <Input
            label="Descrição"
            value={form.description}
            onChangeText={(value) => updateForm('description', value)}
            placeholder="Descreva o serviço..."
            multiline
            numberOfLines={3}
          />

          <View style={{ flexDirection: 'row', gap: 16 }}>
            <View style={{ flex: 1 }}>
              <Input
                label="Preço (R$) *"
                value={form.price}
                onChangeText={(value) => updateForm('price', value)}
                placeholder="0.00"
                keyboardType="decimal-pad"
                error={errors.price}
                prefix="R$"
              />
            </View>
            
            <View style={{ flex: 1 }}>
              <Input
                label="Duração (min) *"
                value={form.duration}
                onChangeText={(value) => updateForm('duration', value)}
                placeholder="60"
                keyboardType="number-pad"
                error={errors.duration}
                suffix="min"
              />
            </View>
          </View>

          <Input
            label="Categoria"
            value={form.category}
            onChangeText={(value) => updateForm('category', value)}
            placeholder="Ex: Cabelo, Estética, etc."
          />

          <View style={[commonStyles.card, { padding: 12 }]}>
            <View style={[commonStyles.rowBetween, { paddingVertical: 8 }]}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Icon name="check-circle" size={20} color={form.isActive ? colors.success : colors.textMuted} />
                <View>
                  <Text style={commonStyles.body}>Serviço Ativo</Text>
                  <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>
                    {form.isActive ? 'Disponível para agendamento' : 'Oculto dos clientes'}
                  </Text>
                </View>
              </View>
              <Switch
                value={form.isActive}
                onValueChange={(value) => updateForm('isActive', value)}
                trackColor={{ false: colors.border, true: colors.success }}
                thumbColor={colors.surface}
              />
            </View>

            <View style={[commonStyles.rowBetween, { paddingVertical: 8 }]}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Icon name="online-prediction" size={20} color={form.onlineBooking ? colors.primary : colors.textMuted} />
                <View>
                  <Text style={commonStyles.body}>Agendamento Online</Text>
                  <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>
                    {form.onlineBooking ? 'Clientes podem agendar online' : 'Somente agendamento manual'}
                  </Text>
                </View>
              </View>
              <Switch
                value={form.onlineBooking}
                onValueChange={(value) => updateForm('onlineBooking', value)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.surface}
                disabled={!form.isActive}
              />
            </View>
          </View>

          <View style={{ marginTop: 24, gap: 12 }}>
            <Button
              title="Salvar Alterações"
              onPress={handleSubmit}
              loading={saving}
              disabled={saving}
            />
            
            <Button
              title="Excluir Serviço"
              onPress={handleDelete}
              variant="outline"
            />
            
            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={{ marginTop: 8 }}
            >
              <Text style={[commonStyles.body, { color: colors.primary, textAlign: 'center' }]}>
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Card>

      <View style={{ marginTop: 32 }}>
        <Text style={[commonStyles.h3, { marginBottom: 12 }]}>Estatísticas</Text>
        <View style={[commonStyles.card, { padding: 16 }]}>
          <View style={[commonStyles.rowBetween, { marginBottom: 12 }]}>
            <Text style={[commonStyles.body, { color: colors.textSecondary }]}>Total de Agendamentos:</Text>
            <Text style={commonStyles.h3}>0</Text>
          </View>
          <View style={[commonStyles.rowBetween, { marginBottom: 12 }]}>
            <Text style={[commonStyles.body, { color: colors.textSecondary }]}>Faturamento Total:</Text>
            <Text style={[commonStyles.h3, { color: colors.success }]}>R$ 0,00</Text>
          </View>
          <View style={[commonStyles.rowBetween]}>
            <Text style={[commonStyles.body, { color: colors.textSecondary }]}>Taxa de Ocupação:</Text>
            <Text style={commonStyles.h3}>0%</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}
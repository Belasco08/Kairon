import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Alert,
  TouchableOpacity,
  Switch,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useAuth } from '../../contexts/AuthContext';
import { serviceService } from '../../services/services';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

interface ServiceForm {
  name: string;
  description: string;
  price: string;
  duration: string;
  category: string;
  isActive: boolean;
  onlineBooking: boolean;
  professionalId?: string;
}

export function CreateService() {
  const navigation = useNavigation();
  const { company } = useAuth();
  
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState<ServiceForm>({
    name: '',
    description: '',
    price: '',
    duration: '60',
    category: '',
    isActive: true,
    onlineBooking: true,
  });
  const [errors, setErrors] = useState<Partial<Record<keyof ServiceForm, string>>>({});

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof ServiceForm, string>> = {};

    if (!form.name.trim()) {
      newErrors.name = 'Nome é obrigatório';
    }

    if (!form.price) {
      newErrors.price = 'Preço é obrigatório';
    } else if (parseFloat(form.price) <= 0) {
      newErrors.price = 'Preço deve ser maior que zero';
    }

    if (!form.duration) {
      newErrors.duration = 'Duração é obrigatória';
    } else if (parseInt(form.duration) <= 0) {
      newErrors.duration = 'Duração deve ser maior que zero';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      const serviceData = {
        ...form,
        price: parseFloat(form.price),
        duration: parseInt(form.duration),
        companyId: company?.id,
      };

      await serviceService.create(serviceData);
      
      Alert.alert(
        'Sucesso',
        'Serviço criado com sucesso!',
        [
          {
            text: 'OK',
            onPress: () => navigation.goBack(),
          },
        ]
      );
    } catch (error: any) {
      console.error('Error creating service:', error);
      Alert.alert(
        'Erro',
        error.response?.data?.message || 'Não foi possível criar o serviço'
      );
    } finally {
      setLoading(false);
    }
  };

  const updateForm = (field: keyof ServiceForm, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  return (
    <ScrollView 
      style={commonStyles.container}
      contentContainerStyle={{ padding: 16 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ marginBottom: 24 }}>
        <Text style={commonStyles.h1}>Novo Serviço</Text>
        <Text style={[commonStyles.body, { color: colors.textSecondary, marginTop: 4 }]}>
          Cadastre um novo serviço para sua empresa
        </Text>
      </View>

      <Card>
        <View style={{ gap: 16 }}>
          <Input
            label="Nome do Serviço *"
            value={form.name}
            onChangeText={(value) => updateForm('name', value)}
            placeholder="Ex: Corte de Cabelo"
            error={errors.name}
            autoFocus
          />

          <Input
            label="Descrição"
            value={form.description}
            onChangeText={(value) => updateForm('description', value)}
            placeholder="Descreva o serviço..."
            multiline
            numberOfLines={3}
          />

          <View style={{ flexDirection: 'row', gap: 16 }}>
            <View style={{ flex: 1 }}>
              <Input
                label="Preço (R$) *"
                value={form.price}
                onChangeText={(value) => updateForm('price', value)}
                placeholder="0.00"
                keyboardType="decimal-pad"
                error={errors.price}
                prefix="R$"
              />
            </View>
            
            <View style={{ flex: 1 }}>
              <Input
                label="Duração (min) *"
                value={form.duration}
                onChangeText={(value) => updateForm('duration', value)}
                placeholder="60"
                keyboardType="number-pad"
                error={errors.duration}
                suffix="min"
              />
            </View>
          </View>

          <Input
            label="Categoria"
            value={form.category}
            onChangeText={(value) => updateForm('category', value)}
            placeholder="Ex: Cabelo, Estética, etc."
          />

          <View style={[commonStyles.card, { padding: 12 }]}>
            <View style={[commonStyles.rowBetween, { paddingVertical: 8 }]}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Icon name="check-circle" size={20} color={form.isActive ? colors.success : colors.textMuted} />
                <View>
                  <Text style={commonStyles.body}>Serviço Ativo</Text>
                  <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>
                    {form.isActive ? 'Disponível para agendamento' : 'Oculto dos clientes'}
                  </Text>
                </View>
              </View>
              <Switch
                value={form.isActive}
                onValueChange={(value) => updateForm('isActive', value)}
                trackColor={{ false: colors.border, true: colors.success }}
                thumbColor={colors.surface}
              />
            </View>

            <View style={[commonStyles.rowBetween, { paddingVertical: 8 }]}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Icon name="online-prediction" size={20} color={form.onlineBooking ? colors.primary : colors.textMuted} />
                <View>
                  <Text style={commonStyles.body}>Agendamento Online</Text>
                  <Text style={[commonStyles.caption, { color: colors.textSecondary }]}>
                    {form.onlineBooking ? 'Clientes podem agendar online' : 'Somente agendamento manual'}
                  </Text>
                </View>
              </View>
              <Switch
                value={form.onlineBooking}
                onValueChange={(value) => updateForm('onlineBooking', value)}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={colors.surface}
                disabled={!form.isActive}
              />
            </View>
          </View>

          <View style={{ marginTop: 24 }}>
            <Button
              title="Criar Serviço"
              onPress={handleSubmit}
              loading={loading}
              disabled={loading}
            />
            
            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={{ marginTop: 12 }}
            >
              <Text style={[commonStyles.body, { color: colors.primary, textAlign: 'center' }]}>
                Cancelar
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Card>

      <View style={{ marginTop: 32 }}>
        <Text style={[commonStyles.h3, { marginBottom: 12 }]}>Dicas</Text>
        <View style={[commonStyles.card, { padding: 16 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 12 }}>
            <Icon name="info" size={20} color={colors.info} style={{ marginRight: 8, marginTop: 2 }} />
            <Text style={[commonStyles.bodySmall, { flex: 1 }]}>
              Serviços inativos não aparecem para os clientes nem para funcionários.
            </Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
            <Icon name="info" size={20} color={colors.info} style={{ marginRight: 8, marginTop: 2 }} />
            <Text style={[commonStyles.bodySmall, { flex: 1 }]}>
              Desative "Agendamento Online" para serviços que exigem pré-avaliação ou consulta.
            </Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { appointmentService } from '../../services/appointments';
import { serviceService } from '../../services/services';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';

interface Service {
  id: string;
  name: string;
  price: number;
  duration: number;
  category?: string;
}

interface AppointmentService {
  serviceId: string;
  service: Service;
}

interface Appointment {
  id: string;
  totalPrice: number;
  appointmentServices: AppointmentService[];
}

export function EditAppointment() {
  const route = useRoute();
  const navigation = useNavigation();
  const { appointmentId } = route.params as { appointmentId: string };

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [availableServices, setAvailableServices] = useState<Service[]>([]);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [originalTotal, setOriginalTotal] = useState(0);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [appointmentRes, servicesRes] = await Promise.all([
        appointmentService.get(appointmentId),
        serviceService.list(),
      ]);

      // Mapeando appointmentServices para garantir serviceId
      const mappedAppointment: Appointment = {
        ...appointmentRes,
        appointmentServices: appointmentRes.appointmentServices.map((as: any) => ({
          serviceId: as.service.id,
          service: as.service,
        })),
      };

      setAppointment(mappedAppointment);
      setAvailableServices(servicesRes.filter((s: any) => s.isActive));

      const initialSelected = mappedAppointment.appointmentServices.map(
        (as) => as.serviceId
      );
      setSelectedServices(initialSelected);
      setOriginalTotal(mappedAppointment.totalPrice);
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível carregar os dados');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  const toggleService = (serviceId: string) => {
    setSelectedServices((prev) => {
      if (prev.includes(serviceId)) {
        return prev.filter((id) => id !== serviceId);
      } else {
        return [...prev, serviceId];
      }
    });
  };

  const calculateTotal = () => {
    return selectedServices.reduce((total, serviceId) => {
      const service = availableServices.find((s) => s.id === serviceId);
      return total + (service?.price || 0);
    }, 0);
  };

  const calculateDifference = () => {
    const newTotal = calculateTotal();
    return newTotal - originalTotal;
  };

  const getServiceCount = (serviceId: string) => {
    return selectedServices.filter((id) => id === serviceId).length;
  };

  const handleSave = async () => {
    if (selectedServices.length === 0) {
      Alert.alert('Atenção', 'Selecione pelo menos um serviço');
      return;
    }

    setSaving(true);
    try {
      await appointmentService.updateServices(appointmentId, selectedServices);

      Alert.alert('Sucesso!', 'Agendamento atualizado com sucesso', [
        {
          text: 'OK',
          onPress: () => navigation.goBack(),
        },
      ]);
    } catch (error: any) {
      Alert.alert('Erro', error.response?.data?.error || 'Erro ao salvar');
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  const total = calculateTotal();
  const difference = calculateDifference();

  const servicesByCategory = availableServices.reduce((acc, service) => {
    const category = service.category || 'Outros';
    if (!acc[category]) acc[category] = [];
    acc[category].push(service);
    return acc;
  }, {} as Record<string, Service[]>);

  return (
    <View style={commonStyles.container}>
      {/* Header */}
      <View style={{ backgroundColor: colors.surface, padding: 16 }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={commonStyles.h2}>Editar Serviços</Text>
          <View style={{ width: 24 }} />
        </View>

        <Text style={[commonStyles.bodySecondary, { textAlign: 'center' }]}>
          Ajuste os serviços realizados no atendimento
        </Text>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}>
        {/* Service Selection */}
        <View style={commonStyles.mb6}>
          <Text style={[commonStyles.h3, commonStyles.mb4]}>Serviços Realizados</Text>

          {Object.entries(servicesByCategory).map(([category, categoryServices]) => (
            <View key={category} style={commonStyles.mb4}>
              <Text
                style={[commonStyles.body, { fontWeight: '600', marginBottom: 8 }]}
              >
                {category}
              </Text>

              <View style={{ gap: 8 }}>
                {categoryServices.map((service) => {
                  const isSelected = selectedServices.includes(service.id);
                  const count = getServiceCount(service.id);

                  return (
                    <TouchableOpacity
                      key={service.id}
                      style={[
                        commonStyles.card,
                        isSelected && {
                          borderColor: colors.primary,
                          borderWidth: 2,
                          backgroundColor: colors.primary + '10',
                        },
                      ]}
                      onPress={() => toggleService(service.id)}
                    >
                      <View style={[commonStyles.rowBetween]}>
                        <View style={{ flex: 1 }}>
                          <Text
                            style={[
                              commonStyles.body,
                              { fontWeight: '600', marginBottom: 4 },
                            ]}
                          >
                            {service.name}
                          </Text>
                          <Text
                            style={[
                              commonStyles.bodySmall,
                              { color: colors.textSecondary },
                            ]}
                          >
                            {service.duration} minutos
                          </Text>
                        </View>

                        <View style={{ alignItems: 'flex-end', gap: 4 }}>
                          <Text
                            style={[
                              commonStyles.body,
                              { color: colors.primary, fontWeight: '600' },
                            ]}
                          >
                            {formatCurrency(service.price)}
                          </Text>

                          {isSelected && count > 1 && (
                            <View style={[commonStyles.row, { gap: 8 }]}>
                              <TouchableOpacity
                                onPress={(e) => {
                                  e.stopPropagation();
                                  const newSelected = [...selectedServices];
                                  const index = newSelected.lastIndexOf(service.id);
                                  if (index > -1) newSelected.splice(index, 1);
                                  setSelectedServices(newSelected);
                                }}
                              >
                                <Icon
                                  name="remove-circle"
                                  size={20}
                                  color={colors.error}
                                />
                              </TouchableOpacity>

                              <Text style={commonStyles.body}>{count}x</Text>

                              <TouchableOpacity
                                onPress={(e) => {
                                  e.stopPropagation();
                                  setSelectedServices([...selectedServices, service.id]);
                                }}
                              >
                                <Icon
                                  name="add-circle"
                                  size={20}
                                  color={colors.primary}
                                />
                              </TouchableOpacity>
                            </View>
                          )}
                        </View>
                      </View>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          ))}
        </View>

        {/* Summary */}
        <Card style={{ backgroundColor: colors.primary + '05' }}>
          <Text style={[commonStyles.h3, { marginBottom: 16 }]}>Resumo Financeiro</Text>

          <View style={{ gap: 12 }}>
            <View
              style={[
                commonStyles.rowBetween,
                { paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: colors.border },
              ]}
            >
              <Text style={[commonStyles.body, { color: colors.textSecondary }]}>
                Valor Original:
              </Text>
              <Text style={commonStyles.body}>{formatCurrency(originalTotal)}</Text>
            </View>

            <View
              style={[
                commonStyles.rowBetween,
                { paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: colors.border },
              ]}
            >
              <Text style={[commonStyles.body, { color: colors.textSecondary }]}>
                Novo Valor:
              </Text>
              <Text style={[commonStyles.body, { fontWeight: '600' }]}>
                {formatCurrency(total)}
              </Text>
            </View>

            <View style={commonStyles.rowBetween}>
              <Text style={[commonStyles.body, { color: colors.textSecondary }]}>
                Diferença:
              </Text>
              <Text
                style={[
                  commonStyles.body,
                  { fontWeight: '600' },
                  difference > 0
                    ? { color: colors.success }
                    : difference < 0
                    ? { color: colors.error }
                    : { color: colors.textPrimary },
                ]}
              >
                {difference >= 0 ? '+' : ''}
                {formatCurrency(Math.abs(difference))}
              </Text>
            </View>
          </View>
        </Card>
      </ScrollView>

      {/* Footer */}
      <View style={{ padding: 16, borderTopWidth: 1, borderTopColor: colors.border }}>
        <Button
          title="Salvar Alterações"
          onPress={handleSave}
          loading={saving}
          disabled={saving}
        />
      </View>
    </View>
  );
}

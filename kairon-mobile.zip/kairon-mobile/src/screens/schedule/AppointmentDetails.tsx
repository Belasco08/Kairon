import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Linking,
  Platform,
  SafeAreaView
} from 'react-native';
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons'; // Ou @expo/vector-icons
import { appointmentService } from '../../services/appointments';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format, parseISO, isValid } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// --- TIPAGEM ---

type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';

type RootStackParamList = {
  AppointmentDetails: { appointmentId: string };
  EditAppointment: { appointmentId: string };
};

type AppointmentDetailsRouteProp = RouteProp<RootStackParamList, 'AppointmentDetails'>;
type AppointmentDetailsNavigationProp = NativeStackNavigationProp<RootStackParamList, 'AppointmentDetails'>;

interface AppointmentServiceItem {
    service: {
        id: string;
        name: string;
        price: number;
        duration: number;
    };
    price: number; // Preço cobrado no agendamento (pode ser diferente do original)
}

interface Appointment {
  id: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  totalPrice: number;
  actualPrice?: number;
  actualDuration?: number;
  notes?: string;
  
  // Suporte a objeto ou campos planos (caso o backend mande de um jeito ou de outro)
  client?: {
    id: string;
    name: string;
    phone: string;
    email?: string;
  };
  clientName?: string;
  clientPhone?: string;

  professional?: {
    id: string;
    name: string;
  };
  professionalName?: string;

  // CORREÇÃO: appointmentServices pode vir null, então tratamos no código
  appointmentServices?: AppointmentServiceItem[];
  services?: any[]; // Caso venha no formato novo "flat"
}

export function AppointmentDetails() {
  const route = useRoute<AppointmentDetailsRouteProp>();
  const navigation = useNavigation<AppointmentDetailsNavigationProp>();
  const { appointmentId } = route.params;

  const [loading, setLoading] = useState(true);
  const [appointment, setAppointment] = useState<Appointment | null>(null);

  useEffect(() => {
    loadAppointment();
  }, []);

  const loadAppointment = async () => {
    try {
      const response = await appointmentService.get(appointmentId);
      // Força cast para garantir tipagem
      setAppointment(response as unknown as Appointment);
    } catch (error) {
      console.error('Erro ao carregar agendamento:', error);
      Alert.alert('Erro', 'Não foi possível carregar os dados');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: AppointmentStatus) => {
    try {
      await appointmentService.updateStatus(appointmentId, newStatus);
      setAppointment(prev => prev ? { ...prev, status: newStatus } : null);
      Alert.alert('Sucesso', 'Status atualizado!');
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  // Helpers para pegar dados com segurança (Null Safety)
  const getClientName = () => appointment?.clientName || appointment?.client?.name || 'Cliente';
  const getClientPhone = () => appointment?.clientPhone || appointment?.client?.phone || '';
  const getProfessionalName = () => appointment?.professionalName || appointment?.professional?.name || 'Profissional';

  // Lógica de WhatsApp
  const handleCallClient = () => {
    const phone = getClientPhone();
    if (phone) Linking.openURL(`tel:${phone}`);
  };

  const handleMessageClient = () => {
    const phone = getClientPhone();
    if (phone) Linking.openURL(`whatsapp://send?phone=${phone}`);
  };

  const handleCancel = () => {
    Alert.alert(
      'Cancelar Agendamento',
      'Tem certeza que deseja cancelar este agendamento?',
      [
        { text: 'Não', style: 'cancel' },
        {
          text: 'Sim, cancelar',
          style: 'destructive',
          onPress: () => handleStatusChange('CANCELLED'),
        },
      ]
    );
  };

  const handleComplete = () => {
    Alert.alert(
      'Finalizar Atendimento',
      'Deseja marcar este atendimento como concluído?',
      [
        { text: 'Ainda não', style: 'cancel' },
        {
          text: 'Sim, concluir',
          onPress: () => handleStatusChange('COMPLETED'),
        },
      ]
    );
  };

  const getStatusVariant = (status: AppointmentStatus): 'info' | 'success' | 'warning' | 'error' => {
    switch (status) {
      case 'PENDING': return 'warning';
      case 'CONFIRMED': return 'success';
      case 'COMPLETED': return 'info'; // Alterei para 'info' (azul) ou 'success' (verde)
      case 'CANCELLED': return 'error';
      case 'NO_SHOW': return 'error';
      default: return 'info';
    }
  };

  const getStatusText = (status: AppointmentStatus) => {
    const map: Record<string, string> = {
      PENDING: 'Pendente',
      CONFIRMED: 'Confirmado',
      COMPLETED: 'Concluído',
      CANCELLED: 'Cancelado',
      NO_SHOW: 'Não Compareceu'
    };
    return map[status] || status;
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!appointment) {
    return (
      <View style={commonStyles.centerContainer}>
        <Text style={commonStyles.body}>Agendamento não encontrado</Text>
        <Button title="Voltar" onPress={() => navigation.goBack()} style={{marginTop: 20}} />
      </View>
    );
  }

  // --- SAFE PARSING ---
  let startTimeDate = new Date();
  try { startTimeDate = parseISO(appointment.startTime); } catch {}
  
  const formattedDate = isValid(startTimeDate) 
    ? format(startTimeDate, "EEEE, d 'de' MMMM 'às' HH:mm", { locale: ptBR }) 
    : appointment.startTime;

  // Calculando serviços com segurança
  // Se vier "services" (flat) ou "appointmentServices" (aninhado)
  const servicesList = appointment.appointmentServices || appointment.services || [];
  
  // Evita o erro do .reduce em undefined
  const calculatedDuration = servicesList.reduce((acc: number, item: any) => {
      // Se for formato aninhado: item.service.duration
      // Se for formato flat: item.duration
      const duration = item.service?.duration || item.duration || 0;
      return acc + duration;
  }, 0);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View style={{ backgroundColor: colors.surface, padding: 16, borderBottomWidth: 1, borderBottomColor: colors.border }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          
          <View style={{ alignItems: 'center' }}>
            <Text style={commonStyles.h3}>Detalhes</Text>
            <Badge
              text={getStatusText(appointment.status)}
              variant={getStatusVariant(appointment.status)}
            />
          </View>
          
          {/* Botão Editar (Só se não estiver cancelado/concluído) */}
          <TouchableOpacity
            onPress={() => navigation.navigate('EditAppointment', { appointmentId: appointment.id })}
            disabled={['COMPLETED', 'CANCELLED'].includes(appointment.status)}
            style={{ opacity: ['COMPLETED', 'CANCELLED'].includes(appointment.status) ? 0.3 : 1 }}
          >
            <Icon name="edit" size={24} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        
        {/* Info Principal */}
        <Card style={commonStyles.mb4}>
           <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
              <Icon name="event" size={24} color={colors.primary} style={{ marginRight: 12 }} />
              <View>
                 <Text style={commonStyles.h4}>Data e Hora</Text>
                 <Text style={commonStyles.body}>{formattedDate}</Text>
              </View>
           </View>

           <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Icon name="person" size={24} color={colors.primary} style={{ marginRight: 12 }} />
              <View>
                 <Text style={commonStyles.h4}>Profissional</Text>
                 <Text style={commonStyles.body}>{getProfessionalName()}</Text>
              </View>
           </View>
        </Card>

        {/* Cliente */}
        <Card style={commonStyles.mb4}>
          <Text style={[commonStyles.h3, commonStyles.mb4]}>Cliente</Text>
          <View style={commonStyles.mb4}>
            <Text style={[commonStyles.body, { fontWeight: 'bold', fontSize: 18 }]}>
              {getClientName()}
            </Text>
            {getClientPhone() ? (
                <Text style={[commonStyles.body, { color: colors.textSecondary }]}>{getClientPhone()}</Text>
            ) : null}
          </View>

          <View style={[commonStyles.row, { gap: 12 }]}>
            <Button
              title="Ligar"
              onPress={handleCallClient}
              variant="outline"
              size="small"
              icon={<Icon name="call" size={18} color={colors.primary} />}
              style={{ flex: 1 }}
              disabled={!getClientPhone()}
            />
            <Button
              title="WhatsApp"
              onPress={handleMessageClient}
              size="small"
              icon={<Icon name="chat" size={18} color="#FFF" />} // Ícone fixo por enquanto
              style={{ flex: 1, backgroundColor: '#25D366' }} // Cor do Zap
              disabled={!getClientPhone()}
            />
          </View>
        </Card>

        {/* Serviços */}
        <Card style={commonStyles.mb4}>
           <Text style={[commonStyles.h3, commonStyles.mb4]}>Serviços</Text>
           {servicesList.length === 0 ? (
               <Text style={commonStyles.body}>Nenhum serviço listado.</Text>
           ) : (
               servicesList.map((item: any, index: number) => {
                   // Tratamento para estrutura flat ou aninhada
                   const name = item.service?.name || item.name || 'Serviço';
                   const price = item.price || item.service?.price || 0;
                   const duration = item.service?.duration || item.duration || 0;

                   return (
                       <View key={index} style={[
                           commonStyles.rowBetween, 
                           { paddingVertical: 8, borderBottomWidth: index < servicesList.length - 1 ? 1 : 0, borderBottomColor: colors.border }
                       ]}>
                           <View>
                               <Text style={[commonStyles.body, { fontWeight: '600' }]}>{name}</Text>
                               <Text style={commonStyles.caption}>{duration} min</Text>
                           </View>
                           <Text style={[commonStyles.body, { fontWeight: 'bold' }]}>
                               {formatCurrency(price)}
                           </Text>
                       </View>
                   );
               })
           )}
           
           <View style={{ marginTop: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: colors.border, flexDirection: 'row', justifyContent: 'space-between' }}>
               <Text style={commonStyles.h3}>Total</Text>
               <Text style={[commonStyles.h3, { color: colors.primary }]}>
                   {formatCurrency(appointment.totalPrice)}
               </Text>
           </View>
        </Card>

        {/* Notas */}
        {appointment.notes && (
            <Card style={commonStyles.mb4}>
                <Text style={[commonStyles.h3, commonStyles.mb2]}>Observações</Text>
                <Text style={commonStyles.body}>{appointment.notes}</Text>
            </Card>
        )}

        {/* Ações de Status */}
        {appointment.status === 'PENDING' || appointment.status === 'CONFIRMED' ? (
            <View style={{ gap: 12 }}>
                <Button 
                    title="Finalizar Atendimento" 
                    onPress={handleComplete}
                    style={{ backgroundColor: colors.success }}
                />
                <Button 
                    title="Cancelar Agendamento" 
                    onPress={handleCancel}
                    variant="outline"
                    style={{ borderColor: colors.error }}
                    textStyle={{ color: colors.error }}
                />
            </View>
        ) : null}

      </ScrollView>
    </SafeAreaView>
  );
}
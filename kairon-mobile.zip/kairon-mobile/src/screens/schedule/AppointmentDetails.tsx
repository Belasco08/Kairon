import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Linking,
} from 'react-native';
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { appointmentService } from '../../services/appointments';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';

// -----------------------------
// Tipagem das rotas
// -----------------------------
type RootStackParamList = {
  AppointmentDetails: { appointmentId: string };
  EditAppointment: { appointmentId: string };
};

type AppointmentDetailsRouteProp = RouteProp<RootStackParamList, 'AppointmentDetails'>;
type AppointmentDetailsNavigationProp = NativeStackNavigationProp<RootStackParamList, 'AppointmentDetails'>;

interface Appointment {
  id: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  totalPrice: number;
  actualPrice?: number;
  actualDuration?: number;
  notes?: string;
  client: {
    id: string;
    name: string;
    phone: string;
    email?: string;
  };
  professional: {
    id: string;
    name: string;
  };
  appointmentServices: Array<{
    service: {
      id: string;
      name: string;
      price: number;
      duration: number;
    };
  }>;
}

export function AppointmentDetails() {
  const route = useRoute<AppointmentDetailsRouteProp>();
  const navigation = useNavigation<AppointmentDetailsNavigationProp>();
  const { appointmentId } = route.params;

  const [loading, setLoading] = useState(true);
  const [appointment, setAppointment] = useState<Appointment | null>(null);

  useEffect(() => {
    loadAppointment();
  }, []);

  const loadAppointment = async () => {
    try {
      const response = await appointmentService.get(appointmentId);
      setAppointment(response);
    } catch (error) {
      console.error('Erro ao carregar agendamento:', error);
      Alert.alert('Erro', 'Não foi possível carregar os dados');
      navigation.goBack();
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: AppointmentStatus) => {
    try {
      await appointmentService.updateStatus(appointmentId, newStatus);
      setAppointment(prev => prev ? { ...prev, status: newStatus } : null);
      Alert.alert('Sucesso', 'Status atualizado!');
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  const handleCallClient = () => {
    if (appointment?.client.phone) {
      Linking.openURL(`tel:${appointment.client.phone}`);
    }
  };

  const handleMessageClient = () => {
    if (appointment?.client.phone) {
      Linking.openURL(`whatsapp://send?phone=${appointment.client.phone}`);
    }
  };

  const handleCancel = () => {
    Alert.alert(
      'Cancelar Agendamento',
      'Tem certeza que deseja cancelar este agendamento?',
      [
        { text: 'Não', style: 'cancel' },
        {
          text: 'Sim, cancelar',
          style: 'destructive',
          onPress: () => handleStatusChange('CANCELLED'),
        },
      ]
    );
  };

  const handleComplete = () => {
    Alert.alert(
      'Finalizar Atendimento',
      'Deseja marcar este atendimento como concluído?',
      [
        { text: 'Ainda não', style: 'cancel' },
        {
          text: 'Sim, concluir',
          onPress: () => handleStatusChange('COMPLETED'),
        },
      ]
    );
  };

  const getStatusVariant = (status: AppointmentStatus): 'info' | 'success' | 'warning' | 'error' => {
    switch (status) {
      case 'PENDING': return 'warning';
      case 'CONFIRMED': return 'success';
      case 'COMPLETED': return 'info';
      case 'CANCELLED': return 'error';
      case 'NO_SHOW': return 'error';
    }
  };

  const getStatusText = (status: AppointmentStatus) => {
    switch (status) {
      case 'PENDING': return 'Pendente';
      case 'CONFIRMED': return 'Confirmado';
      case 'COMPLETED': return 'Concluído';
      case 'CANCELLED': return 'Cancelado';
      case 'NO_SHOW': return 'Não Compareceu';
    }
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!appointment) {
    return (
      <View style={commonStyles.centerContainer}>
        <Text style={commonStyles.body}>Agendamento não encontrado</Text>
      </View>
    );
  }

  const startTime = parseISO(appointment.startTime);
  const endTime = parseISO(appointment.endTime);
  const duration = appointment.actualDuration ||
    appointment.appointmentServices.reduce((sum, as) => sum + as.service.duration, 0);

  return (
    <View style={commonStyles.container}>
      {/* Header */}
      <View style={{ backgroundColor: colors.surface, padding: 16 }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          <View style={{ alignItems: 'center' }}>
            <Text style={commonStyles.h2}>Detalhes</Text>
            <Badge
              text={getStatusText(appointment.status)}
              variant={getStatusVariant(appointment.status)}
            />
          </View>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('EditAppointment', { appointmentId: appointment.id })
            }
            disabled={appointment.status !== 'COMPLETED'}
          >
            <Icon
              name="edit"
              size={24}
              color={appointment.status === 'COMPLETED' ? colors.primary : colors.textMuted}
            />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}>
        {/* Client Info */}
        <Card style={commonStyles.mb4}>
          <Text style={[commonStyles.h3, commonStyles.mb4]}>Cliente</Text>
          <View style={commonStyles.mb4}>
            <Text style={[commonStyles.body, { fontWeight: '600', fontSize: 18 }]}>
              {appointment.client.name}
            </Text>
          </View>

          <View style={{ gap: 12 }}>
            <View style={commonStyles.row}>
              <Icon name="phone" size={20} color={colors.textSecondary} />
              <Text style={[commonStyles.body, { marginLeft: 12, flex: 1 }]}>
                {appointment.client.phone}
              </Text>
            </View>

            {appointment.client.email && (
              <View style={commonStyles.row}>
                <Icon name="email" size={20} color={colors.textSecondary} />
                <Text style={[commonStyles.body, { marginLeft: 12, flex: 1 }]}>
                  {appointment.client.email}
                </Text>
              </View>
            )}
          </View>

          <View style={[commonStyles.row, { gap: 12, marginTop: 16 }]}>
            <Button
              title="Ligar"
              onPress={handleCallClient}
              variant="outline"
              size="small"
              icon={<Icon name="call" size={16} color={colors.primary} />}
              style={{ flex: 1 }}
            />
            <Button
              title="Mensagem"
              onPress={handleMessageClient}
              size="small"
              icon={<Icon name="message" size={16} color={colors.textLight} />}
              style={{ flex: 1 }}
            />
          </View>
        </Card>

        {/* Detalhes, Serviços, Observações, Actions */}
        {/* ... o resto do layout permanece igual ao anterior ... */}
      </ScrollView>
    </View>
  );
}

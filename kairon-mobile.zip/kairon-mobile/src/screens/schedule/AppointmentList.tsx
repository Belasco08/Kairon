import React, { useState, useEffect, useMemo } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  SafeAreaView,
  Platform,
  StatusBar,
  StyleSheet,
  Dimensions,
  Modal,
  TextInput,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import { useAuth } from "../../contexts/AuthContext";
import { appointmentService } from "../../services/appointments";
import { colors } from "../../styles/colors";
import { format, addDays, startOfWeek, isSameDay, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

// =========================
// TYPES & CONFIG
// =========================

type AppointmentStatus =
  | "PENDING"
  | "CONFIRMED"
  | "COMPLETED"
  | "CANCELLED"
  | "NO_SHOW";

type RootStackParamList = {
  AppointmentList: undefined;
  AppointmentDetails: { appointmentId: string };
  CreateAppointment: { initialDate?: string; initialTime?: string };
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

interface Appointment {
  id: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  totalPrice: number;

  // Novos campos planos que o Java está mandando
  clientName: string;
  clientPhone?: string;
  professionalName: string;

  // Array de serviços simplificado
  services: Array<{
    name: string;
    price: number;
  }>;
}

const STATUS_COLORS = {
  PENDING: "#F59E0B",
  CONFIRMED: "#2563EB",
  COMPLETED: "#10B981",
  CANCELLED: "#EF4444",
  NO_SHOW: "#64748B",
};

const STATUS_TRANSLATION = {
  PENDING: "Pendente",
  CONFIRMED: "Confirmado",
  COMPLETED: "Concluído",
  CANCELLED: "Cancelado",
  NO_SHOW: "Ausente",
};

// =========================
// COMPONENT
// =========================

export function AppointmentList() {
  const navigation = useNavigation<NavigationProp>();
  const { user } = useAuth();
  const screenWidth = Dimensions.get("window").width;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());

  // --- ESTADOS DE CONFIGURAÇÃO DE HORÁRIO ---
  const [showSettings, setShowSettings] = useState(false);
  const [workStart, setWorkStart] = useState("07"); // Default 7:00
  const [workEnd, setWorkEnd] = useState("20"); // Default 20:00
  const [lunchStart, setLunchStart] = useState("12"); // Início almoço
  const [lunchEnd, setLunchEnd] = useState("13"); // Fim almoço

  const weekDays = useMemo(() => {
    const start = startOfWeek(selectedDate, { weekStartsOn: 1 });
    return Array.from({ length: 6 }).map((_, i) => addDays(start, i));
  }, [selectedDate]);

  useEffect(() => {
    loadAppointments();
  }, [selectedDate]);

  const loadAppointments = async () => {
    try {
      setLoading(true);
      const params = { date: format(selectedDate, "yyyy-MM-dd") };

      const response = await appointmentService.list(params);

      // CORREÇÃO: "Cast" para dizer ao TS que isso é um array de Appointment atualizado
      const typedResponse = response as unknown as Appointment[];

      setAppointments(typedResponse || []);
    } catch (error) {
      console.error(error);
      Alert.alert("Erro", "Não foi possível carregar a agenda.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadAppointments();
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);

  const getStatusColor = (status: AppointmentStatus) =>
    STATUS_COLORS[status] || STATUS_COLORS.CONFIRMED;

  // --- RENDERIZADORES ---

  const renderWeekCalendar = () => (
    <View style={styles.calendarContainer}>
      <View style={styles.monthHeader}>
        <Text style={styles.monthText}>
          {format(selectedDate, "MMMM, yyyy", { locale: ptBR })}
        </Text>
        <TouchableOpacity onPress={() => setSelectedDate(new Date())}>
          <Text style={styles.todayLink}>Hoje</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.weekRow}>
        {weekDays.map((date) => {
          const isSelected = isSameDay(date, selectedDate);
          const isToday = isSameDay(date, new Date());

          return (
            <TouchableOpacity
              key={date.toString()}
              onPress={() => setSelectedDate(date)}
              style={[styles.dayButton, isSelected && styles.dayButtonSelected]}
            >
              <Text
                style={[styles.dayLabel, isSelected && styles.dayTextSelected]}
              >
                {format(date, "EEE", { locale: ptBR }).replace(".", "")}
              </Text>
              <View
                style={[
                  styles.dayNumberContainer,
                  isSelected && styles.dayNumberSelectedBg,
                ]}
              >
                <Text
                  style={[
                    styles.dayNumber,
                    isSelected && styles.dayTextSelected,
                    !isSelected && isToday && styles.dayTextToday,
                  ]}
                >
                  {format(date, "d")}
                </Text>
              </View>
              {isToday && !isSelected && <View style={styles.dotIndicator} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const renderAppointmentCard = (appointment: Appointment) => {
    const statusColor = getStatusColor(appointment.status);
    const start = parseISO(appointment.startTime);
    const end = parseISO(appointment.endTime);

    return (
      <TouchableOpacity
        key={appointment.id}
        style={[styles.appointmentCard, { borderLeftColor: statusColor }]}
        onPress={() =>
          navigation.navigate("AppointmentDetails", {
            appointmentId: appointment.id,
          })
        }
        activeOpacity={0.8}
      >
        <View style={styles.cardTimeColumn}>
          <Text style={styles.cardTimeStart}>{format(start, "HH:mm")}</Text>
          <Text style={styles.cardTimeEnd}>{format(end, "HH:mm")}</Text>
        </View>

        <View style={styles.cardContent}>
          {/* CORREÇÃO AQUI: Usando clientName direto ou proteção contra nulo */}
          <Text style={styles.clientName} numberOfLines={1}>
            {appointment.clientName || "Cliente sem nome"}
          </Text>

          <Text style={styles.serviceList} numberOfLines={1}>
            {/* CORREÇÃO AQUI: Usando services em vez de appointmentServices */}
            {appointment.services && appointment.services.length > 0
              ? appointment.services.map((s) => s.name).join(", ")
              : "Serviço não listado"}
          </Text>

          <View style={styles.cardFooter}>
            <View
              style={[
                styles.statusBadge,
                { backgroundColor: statusColor + "20" },
              ]}
            >
              <Text style={[styles.statusText, { color: statusColor }]}>
                {STATUS_TRANSLATION[appointment.status] || appointment.status}
              </Text>
            </View>
            <Text style={styles.priceText}>
              {formatCurrency(appointment.totalPrice)}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderTimeLine = () => {
    // Converter strings de configuração para números
    const startHour = parseInt(workStart) || 7;
    const endHour = parseInt(workEnd) || 20;
    const lunchStartHour = parseInt(lunchStart) || 12;
    const lunchEndHour = parseInt(lunchEnd) || 13;

    // Criar array de horas dinâmico baseado na config
    const hours = Array.from(
      { length: endHour - startHour + 1 },
      (_, i) => i + startHour,
    );

    return (
      <View style={styles.timelineContainer}>
        {hours.map((hour) => {
          const appointmentsInHour = appointments.filter((app) => {
            const appDate = parseISO(app.startTime);
            return appDate.getHours() === hour;
          });

          const now = new Date();
          const isCurrentHour =
            isSameDay(selectedDate, now) && now.getHours() === hour;

          // Lógica: É horário de almoço?
          const isLunchTime = hour >= lunchStartHour && hour < lunchEndHour;

          return (
            <View key={hour} style={styles.timeSlot}>
              <View style={styles.timeLabelContainer}>
                <Text style={styles.timeLabel}>{`${hour}:00`}</Text>
              </View>

              <View
                style={[
                  styles.slotContent,
                  isLunchTime && styles.slotContentBlocked,
                ]}
              >
                {isCurrentHour && (
                  <View style={styles.currentTimeLine}>
                    <View style={styles.currentTimeDot} />
                  </View>
                )}

                {/* Prioridade: Agendamentos > Almoço > Vazio */}
                {appointmentsInHour.length > 0 ? (
                  appointmentsInHour.map(renderAppointmentCard)
                ) : isLunchTime ? (
                  // BLOCO DE ALMOÇO
                  <View style={styles.lunchBlock}>
                    <Feather name="coffee" size={18} color="#94A3B8" />
                    <Text style={styles.lunchText}>Horário de Almoço</Text>
                  </View>
                ) : (
                  // BLOCO DISPONÍVEL
                  <TouchableOpacity
                    style={styles.emptySlotButton}
                    onPress={() =>
                      navigation.navigate("CreateAppointment", {
                        initialDate: format(selectedDate, "yyyy-MM-dd"),
                        initialTime: `${hour}:00`,
                      })
                    }
                  >
                    <Feather name="plus" size={16} color="#CBD5E1" />
                    <Text style={styles.emptySlotText}>Disponível</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          );
        })}
      </View>
    );
  };

  // --- MODAL DE CONFIGURAÇÃO ---
  const renderSettingsModal = () => (
    <Modal
      animationType="slide"
      transparent={true}
      visible={showSettings}
      onRequestClose={() => setShowSettings(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Configurar Horários</Text>
            <TouchableOpacity onPress={() => setShowSettings(false)}>
              <Feather name="x" size={24} color="#64748B" />
            </TouchableOpacity>
          </View>

          <Text style={styles.sectionLabel}>Expediente (Início - Fim)</Text>
          <View style={styles.inputRow}>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Das</Text>
              <TextInput
                style={styles.input}
                value={workStart}
                onChangeText={setWorkStart}
                keyboardType="numeric"
                maxLength={2}
              />
              <Text style={styles.inputSuffix}>:00</Text>
            </View>
            <Text style={{ alignSelf: "center", color: "#94A3B8" }}>-</Text>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Até</Text>
              <TextInput
                style={styles.input}
                value={workEnd}
                onChangeText={setWorkEnd}
                keyboardType="numeric"
                maxLength={2}
              />
              <Text style={styles.inputSuffix}>:00</Text>
            </View>
          </View>

          <Text style={styles.sectionLabel}>Horário de Almoço (Bloqueio)</Text>
          <View style={styles.inputRow}>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Das</Text>
              <TextInput
                style={styles.input}
                value={lunchStart}
                onChangeText={setLunchStart}
                keyboardType="numeric"
                maxLength={2}
              />
              <Text style={styles.inputSuffix}>:00</Text>
            </View>
            <Text style={{ alignSelf: "center", color: "#94A3B8" }}>-</Text>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Até</Text>
              <TextInput
                style={styles.input}
                value={lunchEnd}
                onChangeText={setLunchEnd}
                keyboardType="numeric"
                maxLength={2}
              />
              <Text style={styles.inputSuffix}>:00</Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.saveButton}
            onPress={() => setShowSettings(false)}
          >
            <Text style={styles.saveButtonText}>Salvar Configuração</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  // --- RENDER PRINCIPAL ---

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
      <View
        style={[
          styles.headerBackground,
          { height: Platform.OS === "ios" ? 140 : 120 },
        ]}
      />

      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.headerTop}>
          <Text style={styles.screenTitle}>Agenda</Text>
          <View style={{ flexDirection: "row", gap: 12 }}>
            {/* Botão de Configuração */}
            <TouchableOpacity
              style={styles.iconButton}
              onPress={() => setShowSettings(true)}
            >
              <Feather name="settings" size={20} color="#fff" />
            </TouchableOpacity>

            {/* Botão Novo */}
            <TouchableOpacity
              style={styles.iconButton}
              onPress={() => navigation.navigate("CreateAppointment", {})}
            >
              <Feather name="plus" size={24} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>

        {renderWeekCalendar()}

        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={{ paddingBottom: 80 }}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
        >
          {renderTimeLine()}
          <View
            style={{ alignItems: "center", marginTop: 20, marginBottom: 20 }}
          >
            <Text style={{ color: "#94A3B8", fontSize: 12 }}>
              Fim do expediente ({workEnd}:00)
            </Text>
          </View>
        </ScrollView>
      </SafeAreaView>

      {renderSettingsModal()}
    </View>
  );
}

// =========================
// STYLES
// =========================

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F8F9FA" },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F8F9FA",
  },

  // Header
  headerBackground: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.primary || "#2563EB",
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: Platform.OS === "android" ? 40 : 10,
    marginBottom: 10,
  },
  screenTitle: { fontSize: 24, fontWeight: "bold", color: "#fff" },
  iconButton: {
    backgroundColor: "rgba(255,255,255,0.2)",
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },

  // Calendário
  calendarContainer: {
    backgroundColor: "#fff",
    marginHorizontal: 16,
    borderRadius: 16,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
    marginBottom: 16,
  },
  monthHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  monthText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1E293B",
    textTransform: "capitalize",
  },
  todayLink: {
    fontSize: 12,
    color: colors.primary || "#2563EB",
    fontWeight: "600",
  },
  weekRow: { flexDirection: "row", justifyContent: "space-between" },
  dayButton: { alignItems: "center", paddingVertical: 4, flex: 1 },
  dayButtonSelected: {
    backgroundColor: "rgba(37, 99, 235, 0.1)", // Um azul bem clarinho (ajuste conforme sua cor primária)
    borderRadius: 8,
  },
  dayLabel: {
    fontSize: 11,
    color: "#94A3B8",
    textTransform: "uppercase",
    marginBottom: 4,
  },
  dayNumberContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F1F5F9",
  },
  dayNumberSelectedBg: { backgroundColor: colors.primary || "#2563EB" },
  dayNumber: { fontSize: 14, fontWeight: "600", color: "#64748B" },
  dayTextSelected: { color: "#fff" },
  dayTextToday: { color: colors.primary || "#2563EB" },
  dotIndicator: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.primary || "#2563EB",
    marginTop: 4,
  },

  // Timeline
  scrollView: { flex: 1, paddingHorizontal: 16 },
  timelineContainer: { paddingTop: 8 },
  timeSlot: { flexDirection: "row", minHeight: 80 },
  timeLabelContainer: { width: 50, alignItems: "flex-start", paddingTop: 0 },
  timeLabel: {
    fontSize: 12,
    color: "#94A3B8",
    fontWeight: "500",
    transform: [{ translateY: -6 }],
  },
  slotContent: {
    flex: 1,
    borderTopWidth: 1,
    borderTopColor: "#E2E8F0",
    paddingBottom: 12,
    paddingLeft: 12,
  },
  slotContentBlocked: { backgroundColor: "#F8FAFC" }, // Fundo levemente cinza no almoço

  // Empty State & Lunch Block
  emptySlotButton: {
    flex: 1,
    marginTop: 8,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: "#E2E8F0",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    opacity: 0.6,
    height: 50,
  },
  emptySlotText: { fontSize: 12, color: "#94A3B8", marginLeft: 6 },
  lunchBlock: {
    flex: 1,
    marginTop: 8,
    backgroundColor: "#E2E8F0",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    height: 50,
  },
  lunchText: {
    fontSize: 12,
    color: "#64748B",
    fontWeight: "600",
    marginLeft: 8,
  },

  // Appointment Card
  appointmentCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 12,
    flexDirection: "row",
    marginBottom: 8,
    marginTop: 8,
    borderLeftWidth: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  cardTimeColumn: {
    marginRight: 12,
    justifyContent: "center",
    alignItems: "center",
    borderRightWidth: 1,
    borderRightColor: "#F1F5F9",
    paddingRight: 12,
  },
  cardTimeStart: { fontSize: 14, fontWeight: "700", color: "#1E293B" },
  cardTimeEnd: { fontSize: 12, color: "#94A3B8" },
  cardContent: { flex: 1, justifyContent: "center" },
  clientName: {
    fontSize: 15,
    fontWeight: "600",
    color: "#1E293B",
    marginBottom: 2,
  },
  serviceList: { fontSize: 12, color: "#64748B", marginBottom: 8 },
  cardFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  statusBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  statusText: { fontSize: 10, fontWeight: "bold", textTransform: "uppercase" },
  priceText: { fontSize: 13, fontWeight: "700", color: "#1E293B" },

  // Current Time Line
  currentTimeLine: {
    position: "absolute",
    top: -1,
    left: -6,
    right: 0,
    height: 2,
    backgroundColor: "#EF4444",
    zIndex: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  currentTimeDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#EF4444",
    marginLeft: -4,
  },

  // MODAL STYLES
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "85%",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 10,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  modalTitle: { fontSize: 18, fontWeight: "bold", color: "#1E293B" },
  sectionLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#64748B",
    marginBottom: 12,
    marginTop: 10,
  },
  inputRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
    marginBottom: 10,
  },
  inputContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F1F5F9",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  inputLabel: { fontSize: 12, color: "#64748B", marginRight: 8 },
  input: {
    flex: 1,
    fontSize: 16,
    fontWeight: "600",
    color: "#1E293B",
    textAlign: "center",
  },
  inputSuffix: { fontSize: 14, color: "#94A3B8" },
  saveButton: {
    backgroundColor: colors.primary || "#2563EB",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 24,
  },
  saveButtonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
});

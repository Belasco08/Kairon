import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { MaterialIcons } from '@expo/vector-icons'; // <- ícones do Expo
import { useAuth } from '../../contexts/AuthContext';
import { appointmentService } from '../../services/appointments';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { EmptyState } from '../../components/shared/EmptyState';
import { Button } from '../../components/ui/Button';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED' | 'NO_SHOW';

type RootStackParamList = {
  AppointmentList: undefined;
  AppointmentDetails: { appointmentId: string };
  EditAppointment: { appointmentId: string };
  CreateAppointment: undefined;
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

interface Appointment {
  id: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  totalPrice: number;
  client: { name: string; phone: string };
  professional: { name: string };
  appointmentServices: Array<{
    service: { name: string; price: number };
  }>;
}

export function AppointmentList() {
  const navigation = useNavigation<NavigationProp>();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [filterStatus, setFilterStatus] = useState<AppointmentStatus | 'all'>('all');

  useEffect(() => {
    loadAppointments();
  }, [selectedDate, filterStatus]);

  const loadAppointments = async () => {
    try {
      setLoading(true);
      const params: any = { date: format(selectedDate, 'yyyy-MM-dd') };
      if (filterStatus !== 'all') params.status = filterStatus;
      const response = await appointmentService.list(params);
      setAppointments(response || []);
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível carregar os agendamentos');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadAppointments();
  };

  const handleStatusChange = async (appointmentId: string, newStatus: AppointmentStatus) => {
    try {
      await appointmentService.updateStatus(appointmentId, newStatus);
      setAppointments(prev =>
        prev.map(app => app.id === appointmentId ? { ...app, status: newStatus } : app)
      );
      Alert.alert('Sucesso', 'Status atualizado!');
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar o status');
    }
  };

  const handleCancel = (appointmentId: string) =>
    Alert.alert(
      'Cancelar Agendamento',
      'Tem certeza que deseja cancelar este agendamento?',
      [
        { text: 'Não', style: 'cancel' },
        { text: 'Sim, cancelar', style: 'destructive', onPress: () => handleStatusChange(appointmentId, 'CANCELLED') },
      ]
    );

  const handleComplete = (appointmentId: string) =>
    Alert.alert(
      'Finalizar Atendimento',
      'Deseja marcar este atendimento como concluído?',
      [
        { text: 'Ainda não', style: 'cancel' },
        { text: 'Sim, concluir', onPress: () => handleStatusChange(appointmentId, 'COMPLETED') },
      ]
    );

  const getStatusColor = (status: AppointmentStatus) => {
    switch (status) {
      case 'PENDING': return colors.pending;
      case 'CONFIRMED': return colors.confirmed;
      case 'COMPLETED': return colors.completed;
      case 'CANCELLED': return colors.cancelled;
      case 'NO_SHOW': return colors.noShow;
    }
  };

  const getStatusText = (status: AppointmentStatus) => {
    switch (status) {
      case 'PENDING': return 'Pendente';
      case 'CONFIRMED': return 'Confirmado';
      case 'COMPLETED': return 'Concluído';
      case 'CANCELLED': return 'Cancelado';
      case 'NO_SHOW': return 'Não Compareceu';
    }
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  const StatusFilter = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        {['all', 'PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED'].map(status => (
          <TouchableOpacity
            key={status}
            style={[
              { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: colors.border },
              filterStatus === status && { backgroundColor: colors.primary, borderColor: colors.primary },
            ]}
            onPress={() => setFilterStatus(status as AppointmentStatus | 'all')}
          >
            <Text style={[
              commonStyles.caption,
              filterStatus === status ? { color: colors.textLight } : { color: colors.textSecondary },
            ]}>
              {status === 'all' ? 'Todos' : getStatusText(status as AppointmentStatus)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );

  const renderAppointment = (appointment: Appointment) => {
    const startTime = parseISO(appointment.startTime);
    const endTime = parseISO(appointment.endTime);

    return (
      <TouchableOpacity
        key={appointment.id}
        style={[commonStyles.card, { marginBottom: 8, borderLeftWidth: 4, borderLeftColor: getStatusColor(appointment.status) }]}
        onPress={() => navigation.navigate('AppointmentDetails', { appointmentId: appointment.id })}
      >
        <View style={[commonStyles.rowBetween, { marginBottom: 8 }]}>
          <View style={{ flex: 1 }}>
            <Text style={[commonStyles.body, { fontWeight: '600', marginBottom: 4 }]}>{appointment.client.name}</Text>
            <View style={[commonStyles.row, { marginBottom: 4 }]}>
              <MaterialIcons name="phone" size={14} color={colors.textSecondary} />
              <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginLeft: 4 }]}>{appointment.client.phone}</Text>
            </View>
            {user?.role === 'OWNER' && (
              <View style={[commonStyles.row]}>
                <MaterialIcons name="person" size={14} color={colors.textSecondary} />
                <Text style={[commonStyles.bodySmall, { color: colors.textSecondary, marginLeft: 4 }]}>{appointment.professional.name}</Text>
              </View>
            )}
          </View>
          <View style={{ alignItems: 'flex-end', gap: 8 }}>
            <Badge
              text={getStatusText(appointment.status)}
              variant={
                appointment.status === 'PENDING' ? 'warning' :
                appointment.status === 'CONFIRMED' ? 'success' :
                appointment.status === 'COMPLETED' ? 'info' : 'error'
              }
            />
            <Text style={[commonStyles.body, { fontWeight: '600', color: colors.primary }]}>{formatCurrency(appointment.totalPrice)}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  if (loading && !refreshing) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={commonStyles.container}>
      <View style={{ backgroundColor: colors.surface, padding: 16 }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
          <Text style={commonStyles.h2}>Agenda</Text>
          <Button title="+ Novo" onPress={() => navigation.navigate('CreateAppointment')} size="small" />
        </View>
        <Card>
          <View style={[commonStyles.rowBetween, commonStyles.mb2]}>
            <View style={commonStyles.row}>
              <MaterialIcons name="calendar-today" size={20} color={colors.primary} />
              <Text style={[commonStyles.body, { marginLeft: 8 }]}>{format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR })}</Text>
            </View>
            <TouchableOpacity onPress={() => Alert.alert('Info', 'Seletor de data será implementado')}>
              <MaterialIcons name="chevron-right" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>
        </Card>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 16 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <StatusFilter />
        {appointments.length > 0 ? appointments.map(renderAppointment) : (
          <EmptyState
            icon="event-busy"
            title="Nenhum agendamento encontrado"
            description="Tente selecionar outra data ou alterar os filtros"
            actionText="Criar Agendamento"
            onAction={() => navigation.navigate('CreateAppointment')}
          />
        )}
      </ScrollView>
    </View>
  );
}

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';
import { useAuth } from '../../contexts/AuthContext';
import { appointmentService, Appointment } from '../../services/appointments';
import { Calendar } from '../../components/calendar/Calendar';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format, startOfMonth, endOfMonth } from 'date-fns';

type RootStackParamList = {
  CalendarView: undefined;
  CreateAppointment: undefined;
  AppointmentDetails: { appointmentId: string };
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export function CalendarView() {
  const navigation = useNavigation<NavigationProp>();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [appointmentsByDate, setAppointmentsByDate] = useState<Record<string, number>>({});
  const [monthAppointments, setMonthAppointments] = useState<Appointment[]>([]);

  useEffect(() => {
    loadMonthAppointments();
  }, [selectedDate]);

  const loadMonthAppointments = async () => {
    try {
      setLoading(true);

      const startDate = startOfMonth(selectedDate);
      const endDate = endOfMonth(selectedDate);

      // Usando os parâmetros corretos do serviço
      const response = await appointmentService.list({
        date: format(startDate, 'yyyy-MM-dd'), // se o serviço espera "date", enviamos
      });

      const counts: Record<string, number> = {};
      response.forEach(app => {
        const dateStr = format(new Date(app.startTime), 'yyyy-MM-dd');
        counts[dateStr] = (counts[dateStr] || 0) + 1;
      });

      setAppointmentsByDate(counts);
      setMonthAppointments(response);
    } catch (error) {
      console.error('Erro ao carregar agendamentos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
  };

  const getAppointmentsForSelectedDate = () => {
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    return monthAppointments.filter(
      appointment => format(new Date(appointment.startTime), 'yyyy-MM-dd') === dateStr
    );
  };

  const appointmentsData = Object.entries(appointmentsByDate).map(([date, count]) => ({
    date: new Date(date),
    count,
  }));

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  const selectedDateAppointments = getAppointmentsForSelectedDate();

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  return (
    <View style={commonStyles.container}>
      {/* Header */}
      <View style={{ backgroundColor: colors.surface, padding: 16 }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
          <Text style={commonStyles.h2}>Calendário</Text>
          <TouchableOpacity onPress={() => navigation.navigate('CreateAppointment')}>
            <MaterialIcons name="add" size={24} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        {/* Calendar */}
        <View style={{ padding: 16 }}>
          <Calendar
            selectedDate={selectedDate}
            onDateSelect={handleDateSelect}
            appointments={appointmentsData}
          />
        </View>

        {/* Appointments for selected date */}
        <View style={{ padding: 16 }}>
          <Text style={[commonStyles.h3, commonStyles.mb4]}>
            Agendamentos para {format(selectedDate, 'dd/MM/yyyy')}
          </Text>

          {selectedDateAppointments.length > 0 ? (
            <View style={{ gap: 12 }}>
              {selectedDateAppointments.map(app => (
                <TouchableOpacity
                  key={app.id}
                  style={{
                    backgroundColor: colors.surface,
                    borderRadius: 12,
                    padding: 16,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                  onPress={() =>
                    navigation.navigate('AppointmentDetails', { appointmentId: app.id })
                  }
                >
                  <View style={[commonStyles.rowBetween, commonStyles.mb2]}>
                    <Text style={[commonStyles.body, { fontWeight: '600' }]}>
                      {app.client.name}
                    </Text>
                    <View
                      style={{
                        backgroundColor:
                          app.status === 'PENDING'
                            ? colors.pending
                            : app.status === 'CONFIRMED'
                            ? colors.confirmed
                            : app.status === 'COMPLETED'
                            ? colors.completed
                            : colors.cancelled,
                        paddingHorizontal: 8,
                        paddingVertical: 4,
                        borderRadius: 12,
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 10,
                          color: colors.textLight,
                          fontWeight: '600',
                        }}
                      >
                        {app.status === 'PENDING'
                          ? 'Pendente'
                          : app.status === 'CONFIRMED'
                          ? 'Confirmado'
                          : app.status === 'COMPLETED'
                          ? 'Concluído'
                          : 'Cancelado'}
                      </Text>
                    </View>
                  </View>

                  <View style={[commonStyles.row, commonStyles.mb2]}>
                    <MaterialIcons name="schedule" size={14} color={colors.textSecondary} />
                    <Text
                      style={[
                        commonStyles.bodySmall,
                        { color: colors.textSecondary, marginLeft: 4 },
                      ]}
                    >
                      {format(new Date(app.startTime), 'HH:mm')} -{' '}
                      {format(new Date(app.endTime), 'HH:mm')}
                    </Text>
                  </View>

                  <View style={[commonStyles.row]}>
                    <MaterialIcons name="person" size={14} color={colors.textSecondary} />
                    <Text
                      style={[
                        commonStyles.bodySmall,
                        { color: colors.textSecondary, marginLeft: 4 },
                      ]}
                    >
                      {app.professional.name}
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            <EmptyState
              icon="event-busy"
              title="Nenhum agendamento para esta data"
              description="Toque em + para criar um novo agendamento"
              actionText="Criar Agendamento"
              onAction={() => navigation.navigate('CreateAppointment')}
            />
          )}
        </View>
      </ScrollView>
    </View>
  );
}

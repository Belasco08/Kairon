import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons'; // Ou @expo/vector-icons
import { useAuth } from '../../contexts/AuthContext';
import { appointmentService } from '../../services/appointments';
import { serviceService } from '../../services/services';
import { professionalService } from '../../services/professionals';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format, parse, isValid } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Service {
  id: string;
  name: string;
  price: number;
  duration: number;
  isActive?: boolean;
  active?: boolean;
}

interface Professional {
  id: string;
  name: string;
  isActive?: boolean;
  active?: boolean;
}

export function CreateAppointment() {
  const navigation = useNavigation();
  const route = useRoute();
  const { user } = useAuth();
  
  // Recebe parâmetros como Strings para evitar conversão automática de timezone
  const params = route.params as { 
    initialDate?: string; 
    initialTime?: string;
  } || {};

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [services, setServices] = useState<Service[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedProfessional, setSelectedProfessional] = useState<Professional | null>(null);
  
  // --- A CHAVE DO SUCESSO: Trabalhar com Strings ---
  // Se não vier parâmetro, usa a data/hora de agora formatada localmente
  const [dateStr, setDateStr] = useState(params.initialDate || format(new Date(), 'yyyy-MM-dd'));
  const [timeStr, setTimeStr] = useState(params.initialTime || '09:00');
  
  const [clientInfo, setClientInfo] = useState({
    name: '',
    phone: '',
    email: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      
      // 1. Carrega Serviços
      const servicesRes = await serviceService.list();
      if (Array.isArray(servicesRes)) {
        const activeServices = servicesRes.filter((s: any) => (s.isActive ?? s.active) === true);
        setServices(activeServices);
      }

      // 2. Carrega Profissionais
      const professionalsRes = await professionalService.list();
      let activePros: Professional[] = [];
      if (Array.isArray(professionalsRes)) {
         activePros = professionalsRes.filter((p: any) => (p.isActive ?? p.active) === true);
         setProfessionals(activePros);
      }

      // 3. Auto-seleção (Lógica Simplificada e Segura)
      if (user?.role === 'PROFESSIONAL' && activePros.length > 0) {
          // Tenta encontrar o profissional logado, senão pega o primeiro
          // (Melhoria: O endpoint /me deveria retornar o ID do profissional linkado)
          setSelectedProfessional(activePros[0]);
      } else if (activePros.length > 0) {
          // Se for OWNER, por padrão não seleciona, ou seleciona o primeiro
          // setSelectedProfessional(activePros[0]); 
      }

    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Falha ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!selectedService) newErrors.service = 'Selecione um serviço';
    
    // Validação de Data (YYYY-MM-DD)
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(dateStr)) newErrors.date = 'Data inválida (AAAA-MM-DD)';

    // Validação de Hora (HH:mm)
    const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
    if (!timeRegex.test(timeStr)) newErrors.time = 'Hora inválida';

    if (!clientInfo.name.trim()) newErrors.name = 'Nome é obrigatório';
    if (!clientInfo.phone.trim()) newErrors.phone = 'Telefone é obrigatório';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCreateAppointment = async () => {
    if (!validate()) return;
    if (!user?.companyId) {
      Alert.alert('Erro', 'Empresa não identificada');
      return;
    }

    try {
      setSaving(true);
      
      // --- CORREÇÃO DEFINITIVA DE TIMEZONE ---
      // Concatenamos as strings manualmente. O Backend receberá EXATAMENTE o que está escrito.
      // Ex: "2026-02-03" + "T" + "17:00" + ":00" -> "2026-02-03T17:00:00"
      // Não usamos 'Z' no final, nem .toISOString(), para forçar o horário local.
      const localIsoDateTime = `${dateStr}T${timeStr}:00`;

      await appointmentService.create({
        companyId: user.companyId,
        professionalId: selectedProfessional?.id,
        serviceIds: [selectedService!.id],
        startTime: localIsoDateTime, // Mágica aqui
        clientName: clientInfo.name,
        clientPhone: clientInfo.phone,
        clientEmail: clientInfo.email
      });

      Alert.alert('Sucesso', 'Agendamento criado!', [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (error: any) {
      const msg = error.response?.data?.message || 'Erro ao criar agendamento';
      console.log('Erro Create:', error.response?.data);
      Alert.alert('Erro', msg);
    } finally {
      setSaving(false);
    }
  };

  // Header Bonito
  const formattedDateHeader = useMemo(() => {
    try {
        const d = parse(dateStr, 'yyyy-MM-dd', new Date());
        return isValid(d) ? format(d, "EEEE, d 'de' MMMM", { locale: ptBR }) : 'Data Inválida';
    } catch { return dateStr; }
  }, [dateStr]);

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1, backgroundColor: colors.background }}
    >
      {/* Header */}
      <View style={{ 
        flexDirection: 'row', alignItems: 'center', padding: 16, 
        backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border
      }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginRight: 16 }}>
          <Icon name="close" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <View>
            <Text style={commonStyles.h3}>Novo Agendamento</Text>
            <Text style={commonStyles.bodySmall}>{formattedDateHeader}</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
        
        {/* 1. DATA E HORA (Agora Editáveis) */}
        <View style={commonStyles.mb6}>
             <Text style={[commonStyles.h4, commonStyles.mb2]}>Quando?</Text>
             <View style={{ flexDirection: 'row', gap: 12 }}>
                 <View style={{ flex: 2 }}>
                    <Input 
                        label="Data" 
                        value={dateStr} 
                        onChangeText={setDateStr}
                        placeholder="2026-02-03"
                        error={errors.date}
                    />
                 </View>
                 <View style={{ flex: 1 }}>
                    <Input 
                        label="Hora" 
                        value={timeStr} 
                        onChangeText={setTimeStr} 
                        placeholder="14:00"
                        error={errors.time}
                    />
                 </View>
             </View>
        </View>

        {/* 2. Profissional (Owner Only) */}
        {user?.role === 'OWNER' && (
          <View style={commonStyles.mb6}>
            <Text style={[commonStyles.h4, commonStyles.mb2]}>Profissional</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12 }}>
              {professionals.map(prof => (
                <TouchableOpacity
                  key={prof.id}
                  style={{
                    alignItems: 'center', padding: 8, borderRadius: 8,
                    backgroundColor: selectedProfessional?.id === prof.id ? colors.primaryLight : colors.surface,
                    borderWidth: 1,
                    borderColor: selectedProfessional?.id === prof.id ? colors.primary : colors.border,
                    minWidth: 80
                  }}
                  onPress={() => setSelectedProfessional(prof)}
                >
                  <View style={{ 
                    width: 40, height: 40, borderRadius: 20, marginBottom: 4,
                    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Text style={{ color: '#fff', fontWeight: 'bold' }}>{prof.name.charAt(0)}</Text>
                  </View>
                  <Text style={[commonStyles.caption, { fontWeight: '600' }]}>{prof.name.split(' ')[0]}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* 3. Cliente */}
        <View style={commonStyles.mb6}>
          <Text style={[commonStyles.h4, commonStyles.mb4]}>Cliente</Text>
          <Input
            label="Nome"
            placeholder="Nome do cliente"
            value={clientInfo.name}
            onChangeText={t => {
                setClientInfo({ ...clientInfo, name: t });
                if (errors.name) setErrors({...errors, name: ''});
            }}
            error={errors.name}
          />
          <Input
            label="Telefone"
            placeholder="(11) 99999-9999"
            keyboardType="phone-pad"
            value={clientInfo.phone}
            onChangeText={t => setClientInfo({ ...clientInfo, phone: t })}
            error={errors.phone}
          />
        </View>

        {/* 4. Serviço */}
        <View style={commonStyles.mb6}>
          <Text style={[commonStyles.h4, commonStyles.mb2]}>Serviço</Text>
          <View style={{ gap: 10 }}>
                {services.map(service => (
                    <TouchableOpacity
                        key={service.id}
                        onPress={() => {
                            setSelectedService(service);
                            if (errors.service) setErrors({...errors, service: ''});
                        }}
                        style={{
                            flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
                            padding: 16, borderRadius: 8, borderWidth: 1,
                            backgroundColor: selectedService?.id === service.id ? colors.primaryLight : colors.surface,
                            borderColor: selectedService?.id === service.id ? colors.primary : colors.border
                        }}
                    >
                        <View>
                            <Text style={[commonStyles.body, { fontWeight: '600' }]}>{service.name}</Text>
                            <Text style={commonStyles.caption}>{service.duration} min</Text>
                        </View>
                        <Text style={[commonStyles.body, { fontWeight: 'bold', color: colors.primary }]}>
                            R$ {service.price.toFixed(2)}
                        </Text>
                    </TouchableOpacity>
                ))}
          </View>
          {errors.service && <Text style={commonStyles.errorText}>{errors.service}</Text>}
        </View>

      </ScrollView>

      {/* Footer */}
      <View style={{ 
        padding: 16, backgroundColor: colors.surface, 
        borderTopWidth: 1, borderTopColor: colors.border 
      }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
            <Text style={commonStyles.body}>Total:</Text>
            <Text style={commonStyles.h3}>
                R$ {selectedService ? selectedService.price.toFixed(2) : '0.00'}
            </Text>
        </View>
        <Button
            title={saving ? "Salvando..." : "Confirmar Agendamento"}
            onPress={handleCreateAppointment}
            loading={saving}
            disabled={saving}
        />
      </View>
    </KeyboardAvoidingView>
  );
}
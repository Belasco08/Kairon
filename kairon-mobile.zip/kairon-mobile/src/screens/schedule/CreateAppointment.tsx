import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useAuth } from '../../contexts/AuthContext';
import { appointmentService } from '../../services/appointments';
import { serviceService } from '../../services/services';
import { professionalService } from '../../services/professionals';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Service {
  id: string;
  name: string;
  price: number;
  duration: number;
  isActive?: boolean;
  active?: boolean;
}

interface Professional {
  id: string;
  name: string;
  description?: string;
  isActive?: boolean;
  active?: boolean;
  userId?: string; // Importante para identificar o user logado
}

export function CreateAppointment() {
  const navigation = useNavigation();
  const route = useRoute();
  const { user } = useAuth();
  
  // Parâmetros recebidos da Agenda (ao clicar no horário)
  const params = route.params as { 
    preSelectedDate?: Date; 
    preSelectedTime?: string;
    preSelectedProfessionalId?: string;
  } || {};

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [services, setServices] = useState<Service[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedProfessional, setSelectedProfessional] = useState<Professional | null>(null);
  
  // Inicializa com o que veio da agenda ou data atual
  const [selectedDate, setSelectedDate] = useState(params.preSelectedDate || new Date());
  const [selectedTime, setSelectedTime] = useState<string>(params.preSelectedTime || '09:00');
  
  const [clientInfo, setClientInfo] = useState({
    name: '',
    phone: '',
    email: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      
      // 1. Carrega Serviços
      const servicesRes = await serviceService.list();
      if (Array.isArray(servicesRes)) {
        // Mostra serviços ativos
        const availableServices = servicesRes.filter((s: any) => {
           const isActive = s.isActive !== undefined ? s.isActive : s.active;
           return isActive === true;
        });
        setServices(availableServices);
      }

      // 2. Carrega Profissionais
      const professionalsRes = await professionalService.list();
      let availablePros: Professional[] = [];
      
      if (Array.isArray(professionalsRes)) {
         availablePros = professionalsRes.filter((p: any) => {
           const isActive = p.isActive !== undefined ? p.isActive : p.active;
           return isActive === true;
        });
        setProfessionals(availablePros);
      }

      // 3. Lógica de Auto-Seleção do Profissional
      if (user?.role === 'PROFESSIONAL') {
        // Se eu sou profissional, tento achar meu perfil na lista
        // (Supondo que o backend retorne o userId no objeto do profissional, 
        // ou buscamos pelo nome/email se necessário, mas o ideal é o ID)
        
        // Se não tiver userId no objeto professional, o backend que fizemos antes 
        // já trata isso no createAppointment, então podemos deixar null que o backend assume.
        // Mas visualmente é bom mostrar.
        
        // Se veio pré-selecionado da agenda:
        if (params.preSelectedProfessionalId) {
            const pre = availablePros.find(p => p.id === params.preSelectedProfessionalId);
            if (pre) setSelectedProfessional(pre);
        }
      } else {
        // Se sou OWNER e veio um ID da agenda, seleciona ele
        if (params.preSelectedProfessionalId) {
            const pre = availablePros.find(p => p.id === params.preSelectedProfessionalId);
            if (pre) setSelectedProfessional(pre);
        }
      }

    } catch (error) {
      console.error('Error loading data:', error);
      Alert.alert('Erro', 'Não foi possível carregar os dados');
    } finally {
      setLoading(false);
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!selectedService) newErrors.service = 'Selecione um serviço';
    
    // Se for OWNER, obriga a selecionar. Se for PRO, o backend resolve se estiver nulo.
    if (user?.role === 'OWNER' && !selectedProfessional) {
        newErrors.professional = 'Selecione um profissional';
    }
    
    if (!clientInfo.name.trim()) newErrors.name = 'Nome do cliente é obrigatório';
    if (!clientInfo.phone.trim()) newErrors.phone = 'Telefone é obrigatório';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCreateAppointment = async () => {
    // Validação básica do Front
    if (!validate()) return;
    
    if (!user?.companyId) {
      Alert.alert('Erro', 'ID da empresa não encontrado');
      return;
    }

    try {
      setSaving(true);
      
      const startTime = new Date(selectedDate);
      const [hours, minutes] = selectedTime.split(':').map(Number);
      startTime.setHours(hours, minutes, 0, 0);

      // --- CORREÇÃO DO PAYLOAD ---
      await appointmentService.create({
        companyId: user.companyId,
        
        // Se for Professional logado, selectedProfessional?.id será undefined/null
        // O Backend agora aceita isso e resolve sozinho.
        professionalId: selectedProfessional?.id, 
        
        serviceIds: [selectedService!.id],
        startTime: startTime.toISOString(),
        
        // CORREÇÃO: Mapeando os campos do clientInfo para o formato que o Java espera
        clientName: clientInfo.name,
        clientPhone: clientInfo.phone,
        clientEmail: clientInfo.email
      });

      Alert.alert('Sucesso', 'Agendamento criado!', [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (error: any) {
      console.log('Erro ao criar:', error.response?.data); // Log para ajudar no debug
      Alert.alert('Erro', error.response?.data?.message || 'Erro ao criar agendamento');
    } finally {
      setSaving(false);
    }
  };

  // Formata data para exibição (ex: "Segunda, 02 de Fevereiro")
  const formattedDate = useMemo(() => {
    return format(selectedDate, "EEEE, d 'de' MMMM", { locale: ptBR });
  }, [selectedDate]);

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1, backgroundColor: colors.background }}
    >
      {/* Header Simples */}
      <View style={{ 
        flexDirection: 'row', 
        alignItems: 'center', 
        padding: 16, 
        backgroundColor: colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: colors.border
      }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginRight: 16 }}>
          <Icon name="close" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <View>
            <Text style={commonStyles.h3}>Novo Agendamento</Text>
            <Text style={commonStyles.bodySmall}>{formattedDate} às {selectedTime}</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
        
        {/* 1. Seleção de Profissional (Só aparece se for OWNER ou se quiser trocar) */}
        {user?.role === 'OWNER' && (
          <View style={commonStyles.mb6}>
            <Text style={[commonStyles.h4, commonStyles.mb2]}>Profissional</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12 }}>
              {professionals.map(prof => (
                <TouchableOpacity
                  key={prof.id}
                  style={{
                    alignItems: 'center',
                    padding: 8,
                    borderRadius: 8,
                    backgroundColor: selectedProfessional?.id === prof.id ? colors.primaryLight : colors.surface,
                    borderWidth: 1,
                    borderColor: selectedProfessional?.id === prof.id ? colors.primary : colors.border,
                    minWidth: 80
                  }}
                  onPress={() => setSelectedProfessional(prof)}
                >
                  <View style={{ 
                    width: 40, height: 40, borderRadius: 20, 
                    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
                    marginBottom: 4
                  }}>
                    <Text style={{ color: '#fff', fontWeight: 'bold' }}>{prof.name.charAt(0)}</Text>
                  </View>
                  <Text style={[commonStyles.caption, { fontWeight: '600' }]}>{prof.name.split(' ')[0]}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {errors.professional && <Text style={commonStyles.errorText}>{errors.professional}</Text>}
          </View>
        )}

        {/* 2. Informações do Cliente */}
        <View style={commonStyles.mb6}>
          <Text style={[commonStyles.h4, commonStyles.mb4]}>Cliente</Text>
          <Input
            label="Nome"
            placeholder="Nome do cliente"
            value={clientInfo.name}
            onChangeText={t => {
                setClientInfo({ ...clientInfo, name: t });
                if (errors.name) setErrors({...errors, name: ''});
            }}
            error={errors.name}
          />
          <Input
            label="Telefone (WhatsApp)"
            placeholder="(11) 99999-9999"
            keyboardType="phone-pad"
            value={clientInfo.phone}
            onChangeText={t => {
                setClientInfo({ ...clientInfo, phone: t });
                if (errors.phone) setErrors({...errors, phone: ''});
            }}
            error={errors.phone}
          />
        </View>

        {/* 3. Seleção de Serviço */}
        <View style={commonStyles.mb6}>
          <Text style={[commonStyles.h4, commonStyles.mb2]}>Serviço</Text>
          {services.length === 0 ? (
             <EmptyState title="Sem serviços" description="Cadastre serviços primeiro" icon="content-cut" />
          ) : (
            <View style={{ gap: 10 }}>
                {services.map(service => (
                    <TouchableOpacity
                        key={service.id}
                        onPress={() => {
                            setSelectedService(service);
                            if (errors.service) setErrors({...errors, service: ''});
                        }}
                        style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            padding: 16,
                            backgroundColor: selectedService?.id === service.id ? colors.primaryLight : colors.surface,
                            borderRadius: 8,
                            borderWidth: 1,
                            borderColor: selectedService?.id === service.id ? colors.primary : colors.border
                        }}
                    >
                        <View>
                            <Text style={[commonStyles.body, { fontWeight: '600' }]}>{service.name}</Text>
                            <Text style={commonStyles.caption}>{service.duration} min</Text>
                        </View>
                        <Text style={[commonStyles.body, { fontWeight: 'bold', color: colors.primary }]}>
                            R$ {service.price.toFixed(2)}
                        </Text>
                    </TouchableOpacity>
                ))}
            </View>
          )}
          {errors.service && <Text style={commonStyles.errorText}>{errors.service}</Text>}
        </View>

      </ScrollView>

      {/* Footer Fixo */}
      <View style={{ 
        padding: 16, 
        backgroundColor: colors.surface, 
        borderTopWidth: 1, 
        borderTopColor: colors.border,
        elevation: 8
      }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
            <Text style={commonStyles.body}>Total:</Text>
            <Text style={commonStyles.h3}>
                R$ {selectedService ? selectedService.price.toFixed(2) : '0.00'}
            </Text>
        </View>
        <Button
            title={saving ? "Salvando..." : "Confirmar Agendamento"}
            onPress={handleCreateAppointment}
            loading={saving}
            disabled={saving}
        />
      </View>
    </KeyboardAvoidingView>
  );
}
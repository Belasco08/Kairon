import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useAuth } from '../../contexts/AuthContext';
import { appointmentService } from '../../services/appointments';
import { serviceService } from '../../services/services';
import { professionalService } from '../../services/professionals';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { EmptyState } from '../../components/shared/EmptyState';
import { colors } from '../../styles/colors';
import { commonStyles } from '../../styles/common';
import { format, addDays } from 'date-fns';

interface Service {
  id: string;
  name: string;
  price: number;
  duration: number;
}

interface Professional {
  id: string;
  name: string;
  description?: string;
}

export function CreateAppointment() {
  const navigation = useNavigation();
  const { user } = useAuth();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [step, setStep] = useState(1);
  
  const [services, setServices] = useState<Service[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedProfessional, setSelectedProfessional] = useState<Professional | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState<string>('09:00');
  
  const [clientInfo, setClientInfo] = useState({
    name: '',
    phone: '',
    email: '',
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    if (selectedService && step >= 2) {
      loadProfessionals();
    }
  }, [selectedService, step]);

  const loadInitialData = async () => {
    try {
      const servicesRes = await serviceService.list();
      setServices(servicesRes.filter((s: any) => s.isActive && s.onlineBooking));
    } catch (error) {
      console.error('Error loading services:', error);
      Alert.alert('Erro', 'Não foi possível carregar os serviços');
    } finally {
      setLoading(false);
    }
  };

  const loadProfessionals = async () => {
    try {
      const professionalsRes = await professionalService.list();
      setProfessionals(professionalsRes.filter((p: any) => p.isActive));
    } catch (error) {
      console.error('Error loading professionals:', error);
    }
  };

  const validateStep = () => {
    const newErrors: Record<string, string> = {};

    if (step === 1 && !selectedService) {
      newErrors.service = 'Selecione um serviço';
    }
    
    if (step === 2 && !selectedProfessional) {
      newErrors.professional = 'Selecione um profissional';
    }
    
    if (step === 4) {
      if (!clientInfo.name.trim()) newErrors.name = 'Nome é obrigatório';
      if (!clientInfo.phone.trim()) newErrors.phone = 'Telefone é obrigatório';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (!validateStep()) return;
    
    if (step < 4) {
      setStep(step + 1);
    } else {
      handleCreateAppointment();
    }
  };

  const handlePrevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      navigation.goBack();
    }
  };

  const handleCreateAppointment = async () => {
    if (!selectedService || !selectedProfessional) {
      Alert.alert('Erro', 'Serviço e profissional são obrigatórios');
      return;
    }

    if (!user?.companyId) {
      Alert.alert('Erro', 'ID da empresa não encontrado');
      return;
    }

    try {
      setSaving(true);
      
      const startTime = new Date(selectedDate);
      const [hours, minutes] = selectedTime.split(':').map(Number);
      startTime.setHours(hours, minutes, 0, 0);

      await appointmentService.create({
        companyId: user.companyId, // ✅ ADICIONADO
        professionalId: selectedProfessional.id,
        serviceIds: [selectedService.id],
        startTime: startTime.toISOString(),
        clientInfo,
      });

      Alert.alert(
        'Sucesso!',
        'Agendamento criado com sucesso',
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('Schedule' as never),
          },
        ]
      );
    } catch (error: any) {
      Alert.alert('Erro', error.response?.data?.error || 'Erro ao criar agendamento');
    } finally {
      setSaving(false);
    }
  };

  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour <= 18; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        slots.push(time);
      }
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  const renderStepIndicator = () => (
    <View style={[commonStyles.row, { justifyContent: 'center', marginBottom: 24, gap: 8 }]}>
      {[1, 2, 3, 4].map((num) => (
        <React.Fragment key={num}>
          <View
            style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              backgroundColor: step >= num ? colors.primary : colors.background,
              borderWidth: 2,
              borderColor: step >= num ? colors.primary : colors.border,
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Text
              style={[
                commonStyles.body,
                {
                  color: step >= num ? colors.textLight : colors.textSecondary,
                  fontWeight: '600',
                },
              ]}
            >
              {num}
            </Text>
          </View>
          {num < 4 && (
            <View
              style={{
                width: 40,
                height: 2,
                backgroundColor: step > num ? colors.primary : colors.border,
              }}
            />
          )}
        </React.Fragment>
      ))}
    </View>
  );

  const renderStep1 = () => (
    <View>
      <Text style={[commonStyles.h3, commonStyles.mb4]}>Selecione o Serviço</Text>
      
      {services.length > 0 ? (
        <View style={{ gap: 12 }}>
          {services.map(service => (
            <TouchableOpacity
              key={service.id}
              style={[
                commonStyles.card,
                selectedService?.id === service.id && {
                  borderColor: colors.primary,
                  borderWidth: 2,
                  backgroundColor: colors.primary + '10',
                },
              ]}
              onPress={() => {
                setSelectedService(service);
                if (errors.service) setErrors({ ...errors, service: '' });
              }}
            >
              <View style={[commonStyles.rowBetween]}>
                <View style={{ flex: 1 }}>
                  <Text style={[commonStyles.body, { fontWeight: '600', marginBottom: 4 }]}>
                    {service.name}
                  </Text>
                  <Text style={[commonStyles.bodySmall, { color: colors.textSecondary }]}>
                    {service.duration} minutos
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={[commonStyles.h3, { color: colors.primary }]}>
                    R$ {service.price.toFixed(2)}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      ) : (
        <EmptyState
          icon="style"
          title="Nenhum serviço disponível"
          description="Cadastre serviços para começar a agendar"
        />
      )}
      
      {errors.service && (
        <Text style={commonStyles.errorText}>{errors.service}</Text>
      )}
    </View>
  );

  const renderStep2 = () => (
    <View>
      <Text style={[commonStyles.h3, commonStyles.mb4]}>Selecione o Profissional</Text>
      
      {professionals.length > 0 ? (
        <View style={{ gap: 12 }}>
          {professionals.map(professional => (
            <TouchableOpacity
              key={professional.id}
              style={[
                commonStyles.card,
                selectedProfessional?.id === professional.id && {
                  borderColor: colors.primary,
                  borderWidth: 2,
                  backgroundColor: colors.primary + '10',
                },
              ]}
              onPress={() => {
                setSelectedProfessional(professional);
                if (errors.professional) setErrors({ ...errors, professional: '' });
              }}
            >
              <View style={[commonStyles.row]}>
                <View
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius: 24,
                    backgroundColor: colors.primaryLight,
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginRight: 12,
                  }}
                >
                  <Icon name="person" size={24} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[commonStyles.body, { fontWeight: '600' }]}>
                    {professional.name}
                  </Text>
                  {professional.description && (
                    <Text style={[commonStyles.bodySmall, { color: colors.textSecondary }]}>
                      {professional.description}
                    </Text>
                  )}
                </View>
                {selectedProfessional?.id === professional.id && (
                  <Icon name="check-circle" size={24} color={colors.primary} />
                )}
              </View>
            </TouchableOpacity>
          ))}
        </View>
      ) : (
        <EmptyState
          icon="people"
          title="Nenhum profissional disponível"
          description="Cadastre profissionais para continuar"
        />
      )}
      
      {errors.professional && (
        <Text style={commonStyles.errorText}>{errors.professional}</Text>
      )}
    </View>
  );

  const renderStep3 = () => (
    <View>
      <Text style={[commonStyles.h3, commonStyles.mb4]}>Data e Horário</Text>
      {/* Date and time selection */}
      {/* ... mesmo código do seu passo 3 ... */}
    </View>
  );

  const renderStep4 = () => (
    <View>
      <Text style={[commonStyles.h3, commonStyles.mb4]}>Informações do Cliente</Text>
      {/* Inputs e resumo do agendamento */}
      {/* ... mesmo código do seu passo 4 ... */}
    </View>
  );

  const renderStepContent = () => {
    switch (step) {
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      case 4: return renderStep4();
      default: return null;
    }
  };

  const getStepTitle = () => {
    switch (step) {
      case 1: return 'Escolha o Serviço';
      case 2: return 'Escolha o Profissional';
      case 3: return 'Escolha Data e Hora';
      case 4: return 'Informações do Cliente';
      default: return 'Novo Agendamento';
    }
  };

  if (loading) {
    return (
      <View style={commonStyles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={commonStyles.container}>
      <View style={{ backgroundColor: colors.surface, padding: 16 }}>
        <View style={[commonStyles.rowBetween, commonStyles.mb4]}>
          <TouchableOpacity onPress={handlePrevStep}>
            <Icon name="arrow-back" size={24} color={colors.textPrimary} />
          </TouchableOpacity>
          <Text style={commonStyles.h2}>{getStepTitle()}</Text>
          <View style={{ width: 24 }} />
        </View>
        {renderStepIndicator()}
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }} showsVerticalScrollIndicator={false}>
        {renderStepContent()}
      </ScrollView>

      <View style={{ padding: 16, borderTopWidth: 1, borderTopColor: colors.border }}>
        <Button
          title={step === 4 ? 'Confirmar Agendamento' : 'Continuar'}
          onPress={handleNextStep}
          loading={saving}
          disabled={saving}
        />
      </View>
    </View>
  );
}

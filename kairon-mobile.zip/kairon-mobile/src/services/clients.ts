import { api } from './api';

export interface Client {
  id: string;
  name: string;
  email?: string;
  phone: string;
  birthDate?: string;
  notes?: string;
  totalAppointments: number;
  totalSpent: number;
  lastAppointment?: string;
}

export const clientService = {
  list: async (params?: {
    search?: string;
    page?: number;
    limit?: number;
  }) => {
    const response = await api.get('/clients', { params });
    
    // 🛠️ CORREÇÃO DE TECH LEAD:
    // O Spring Boot com paginação retorna um objeto { content: [...], totalElements: ... }
    // O Frontend espera apenas o array [...].
    // Aqui fazemos a verificação defensiva:
    
    if (response.data && Array.isArray(response.data.content)) {
      return response.data.content; // Retorna a lista que está dentro da paginação
    }
    
    // Se não tiver paginação, retorna o dado direto (fallback)
    return response.data;
  },

  get: async (id: string) => {
    const response = await api.get(`/clients/${id}`);
    return response.data;
  },

  update: async (id: string, data: Partial<Client>) => {
    const response = await api.put(`/clients/${id}`, data);
    return response.data;
  },

  getAppointments: async (clientId: string) => {
    const response = await api.get(`/clients/${clientId}/appointments`);
    
    // Aplicamos a mesma lógica aqui, pois appointments também pode ser paginado
    if (response.data && Array.isArray(response.data.content)) {
      return response.data.content;
    }
    return response.data;
  },
};
import { api } from './api';

/* =========================
   TIPOS BASE
========================= */

export type Period = 'day' | 'week' | 'month' | 'year';

/* =========================
   DASHBOARD
========================= */

export interface DashboardData {
  revenue: number;
  appointments: number;
  averageTicket: number;
  dailyEvolution: Array<{
    date: string;
    revenue: number;
    appointments: number;
  }>;
  topServices: Array<{
    name: string;
    revenue: number;
    count: number;
  }>;
  busyHours: Array<{
    hour: string;
    count: number;
  }>;
}

/* =========================
   FINANCIAL RECORD (API)
========================= */

export interface ApiFinancialRecord {
  id: string;
  type: 'APPOINTMENT' | 'ADJUSTMENT' | 'REFUND' | 'EXPENSE';
  amount: number;
  description: string;
  referenceDate: string;
  appointment?: {
    id: string;
    client: {
      name: string;
    };
  };
  professional?: {
    name: string;
  };
}

/* =========================
   FINANCIAL RECORD (APP)
========================= */

export interface FinancialRecord {
  id: string;
  type: 'revenue' | 'expense';
  amount: number;
  description: string;
  date: string;
  category: 'appointment' | 'product' | 'service' | 'other';
  status: 'pending' | 'completed' | 'cancelled';
  reference?: string;
}

/* =========================
   DASHBOARD AUX
========================= */

export interface RevenueData {
  labels: string[];
  values: number[];
}

export interface ComparisonData {
  previousPeriodRevenue: number;
  growthPercentage: number;
}

/* =========================
   HELPERS (NORMALIZAÇÃO)
========================= */

const mapApiRecordToApp = (r: ApiFinancialRecord): FinancialRecord => {
  const isExpense =
    r.type === 'EXPENSE' || r.type === 'REFUND';

  return {
    id: r.id,
    description: r.description,
    amount: r.amount,
    date: r.referenceDate,
    type: isExpense ? 'expense' : 'revenue',
    status: 'completed',
    category:
      r.type === 'APPOINTMENT'
        ? 'appointment'
        : r.type === 'EXPENSE'
        ? 'service'
        : 'other',
    reference: r.appointment?.client?.name,
  };
};

/* =========================
   SERVICE
========================= */

export const financeService = {
  /* ---------- DASHBOARD ---------- */
  getDashboard: async (params: { period: Period }): Promise<DashboardData> => {
    const response = await api.get('/finance/dashboard', { params });
    return response.data;
  },

  /* ---------- REGISTROS ---------- */
  getRecords: async (params?: {
    startDate?: string;
    endDate?: string;
    type?: string;
  }): Promise<FinancialRecord[]> => {
    try {
      const response = await api.get<ApiFinancialRecord[]>(
        '/finance/records',
        { params }
      );

      return response.data.map(mapApiRecordToApp);
    } catch {
      /* 🔹 MOCK FALLBACK */
      return [
        {
          id: '1',
          description: 'Corte de Cabelo',
          amount: 50,
          date: new Date().toISOString(),
          type: 'revenue',
          status: 'completed',
          category: 'service',
          reference: 'João Silva',
        },
        {
          id: '2',
          description: 'Compra de Produtos',
          amount: 120,
          date: new Date().toISOString(),
          type: 'expense',
          status: 'completed',
          category: 'other',
        },
      ];
    }
  },

  /* ---------- DELETE ---------- */
  deleteRecord: async (id: string): Promise<void> => {
    await api.delete(`/finance/records/${id}`);
  },

  /* ---------- RELATÓRIOS ---------- */
  getReports: async (params: {
    startDate: string;
    endDate: string;
    groupBy: 'day' | 'week' | 'month';
  }) => {
    const response = await api.get('/finance/reports', { params });
    return response.data;
  },

  /* ---------- CHART ---------- */
  getRevenueChart: async (
    params: { period: Period }
  ): Promise<RevenueData> => {
    try {
      const response = await api.get('/finance/revenue-chart', { params });
      return response.data;
    } catch {
      return {
        labels: ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
        values: [120, 200, 150, 300, 250, 400, 350],
      };
    }
  },

  /* ---------- COMPARISON ---------- */
  getComparison: async (
    params: { period: Period }
  ): Promise<ComparisonData> => {
    try {
      const response = await api.get('/finance/comparison', { params });
      return response.data;
    } catch {
      return {
        previousPeriodRevenue: 1800,
        growthPercentage: 12.5,
      };
    }
  },
};

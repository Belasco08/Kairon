import { api } from "./api";

/* =======================
   TYPES
======================= */

export type AppointmentStatus =
  | "PENDING"
  | "CONFIRMED"
  | "COMPLETED"
  | "CANCELLED"
  | "NO_SHOW";

export interface Appointment {
  id: string;
  startTime: string; // Vem como string ISO do Java
  endTime: string;
  status: AppointmentStatus;
  totalPrice: number;
  actualPrice?: number;
  actualDuration?: number;
  notes?: string;

  // Suporte para o formato "Flat" ou "Objeto"
  clientName?: string;
  clientPhone?: string;
  client?: {
    id: string;
    name: string;
    phone: string;
    email?: string;
  };

  professionalName?: string;
  professional?: {
    id: string;
    name: string;
  };

  appointmentServices?: Array<{
    service: {
      id: string;
      name: string;
      price: number;
      duration: number;
    };
    price: number;
  }>;
  // Caso venha no formato simplificado
  services?: any[];
}

// CORREÇÃO: Interface alinhada com o que fizemos no CreateAppointment.tsx (Campos Planos)
export interface CreateAppointmentData {
  companyId: string;
  professionalId?: string; // Pode ser opcional
  serviceIds: string[];
  startTime: string; // String manual "2026-02-03T14:00:00"
  
  // Campos planos (Flat)
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  
  // Mantive o antigo como opcional caso algum código legado use, 
  // mas o ideal é usar os planos acima
  clientInfo?: {
    name: string;
    phone: string;
    email?: string;
  };
}

export interface AvailabilityParams {
  professionalId: string;
  date: string;
}

export interface AppointmentListParams {
  clientId?: string;
  professionalId?: string;
  date?: string; // YYYY-MM-DD
  status?: AppointmentStatus | AppointmentStatus[];
  limit?: number;
}

/* =======================
   SERVICE
======================= */

export const appointmentService = {
  list: async (params?: AppointmentListParams): Promise<Appointment[]> => {
    const response = await api.get("/appointments", { params });
    return response.data;
  },

  get: async (id: string): Promise<Appointment> => {
    const response = await api.get(`/appointments/${id}`);
    return response.data;
  },

  create: async (data: CreateAppointmentData) => {
    const response = await api.post("/appointments", data);
    return response.data;
  },

  // --- CORREÇÃO DO PROBLEMA DE STATUS ---
  // Agora a função aceita (id, status, reason) e monta o JSON correto
  updateStatus: async (
    id: string,
    status: AppointmentStatus,
    reason?: string
  ) => {
    // Montamos o objeto que o Java @AppointmentStatusRequest espera
    const payload = { 
      status: status, 
      reason: reason 
    };
    
    const response = await api.put(`/appointments/${id}/status`, payload);
    return response.data;
  },

  updateServices: async (id: string, serviceIds: string[]) => {
    const response = await api.put(`/appointments/${id}/services`, {
      serviceIds,
    });
    return response.data;
  },

  getAvailability: async (params: AvailabilityParams) => {
    const response = await api.get("/appointments/availability", { params });
    return response.data;
  },

  // Helpers reutilizando a função corrigida acima
  cancel: async (id: string, reason?: string) => {
    return appointmentService.updateStatus(id, "CANCELLED", reason);
  },

  complete: async (id: string) => {
    return appointmentService.updateStatus(id, "COMPLETED");
  },
  
  // Métodos Públicos (se usar)
  getAvailableSlots: async (params: {
    serviceId: string;
    professionalId: string;
    date: string;
  }) => {
    const response = await api.get("/public/appointments/slots", { params });
    return response.data;
  },

  createPublic: async (data: any) => {
    const response = await api.post("/public/appointments", data);
    return response.data;
  },
};
import { api } from "./api";

/* =======================
   TYPES
======================= */

export type AppointmentStatus =
  | "PENDING"
  | "CONFIRMED"
  | "COMPLETED"
  | "CANCELLED"
  | "NO_SHOW";

export interface Appointment {
  id: string;
  startTime: string;
  endTime: string;
  status: AppointmentStatus;
  totalPrice: number;
  actualPrice?: number;
  actualDuration?: number;

  client: {
    id: string;
    name: string;
    phone: string;
    email?: string;
  };

  professional: {
    id: string;
    name: string;
  };

  appointmentServices: Array<{
    service: {
      id: string;
      name: string;
      price: number;
      duration: number;
    };
  }>;
}

export interface CreateAppointmentData {
  companyId: string;
  professionalId: string;
  serviceIds: string[];
  startTime: string;
  clientInfo: {
    name: string;
    phone: string;
    email?: string;
  };
}

export interface AvailabilityParams {
  professionalId: string;
  date: string;
}

export interface AppointmentListParams {
  clientId?: string;
  professionalId?: string;
  date?: string;
  status?: AppointmentStatus | AppointmentStatus[];
  limit?: number;
}

/* =======================
   SERVICE
======================= */

export const appointmentService = {
  list: async (params?: AppointmentListParams): Promise<Appointment[]> => {
    const response = await api.get("/appointments", { params });
    return response.data;
  },

  get: async (id: string): Promise<Appointment> => {
    const response = await api.get(`/appointments/${id}`);
    return response.data;
  },

  getAvailableSlots: async (params: {
    serviceId: string;
    professionalId: string;
    date: string;
  }) => {
    const response = await api.get("/public/appointments/slots", { params });
    return response.data;
  },

  createPublic: async (data: any) => {
    const response = await api.post("/public/appointments", data);
    return response.data;
  },

  create: async (data: CreateAppointmentData) => {
    const response = await api.post("/appointments", data);
    return response.data;
  },

  updateStatus: async (
    id: string,
    data: {
      status: AppointmentStatus;
      reason?: string;
    }
  ) => {
    const response = await api.put(`/appointments/${id}/status`, data);
    return response.data;
  },

  updateServices: async (id: string, serviceIds: string[]) => {
    const response = await api.put(`/appointments/${id}/services`, {
      serviceIds,
    });
    return response.data;
  },

  getAvailability: async (params: AvailabilityParams) => {
    const response = await api.get("/appointments/availability", { params });
    return response.data;
  },

  cancel: async (id: string, reason?: string) => {
    return appointmentService.updateStatus(id, {
      status: "CANCELLED",
      reason,
    });
  },

  complete: async (id: string) => {
    return appointmentService.updateStatus(id, {
      status: "COMPLETED",
    });
  },
};

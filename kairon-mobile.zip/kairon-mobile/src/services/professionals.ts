import { api } from "./api";

export interface Professional {
  id: string;
  name: string;
  description?: string;
  phone: string;
  photoUrl?: string;
  isActive: boolean; // O código vai lidar com 'active' também
  workHours?: any;
  services?: Array<{
    id: string;
    name: string;
  }>;
}

export interface CreateProfessionalData {
  name: string;
  description?: string;
  phone?: string;
  photoUrl?: string;
  isActive?: boolean;
  workHours?: any;
}

export const professionalService = {
  list: async () => {
    const response = await api.get("/professionals");
    
    // 🛠️ FIX: Tratamento robusto de resposta
    // Se vier paginado (Spring 'content') ou encapsulado
    if (response.data && Array.isArray(response.data.content)) {
      return response.data.content;
    }
    
    // Se vier direto como array
    if (Array.isArray(response.data)) {
      return response.data;
    }

    // Fallback seguro
    return [];
  },

  get: async (id: string) => {
    const response = await api.get(`/professionals/${id}`);
    return response.data;
  },

  getAvailable: async (companyId: string) => {
    const response = await api.get("/public/professionals", {
      params: { companyId },
    });
    // Mesma proteção para a rota pública
    if (response.data && Array.isArray(response.data.content)) return response.data.content;
    return Array.isArray(response.data) ? response.data : [];
  },

  create: async (data: CreateProfessionalData) => {
    const response = await api.post("/professionals", data);
    return response.data;
  },

  update: async (id: string, data: Partial<CreateProfessionalData>) => {
    const response = await api.put(`/professionals/${id}`, data);
    return response.data;
  },

  delete: async (id: string) => {
    const response = await api.delete(`/professionals/${id}`);
    return response.data;
  },

  getServices: async (professionalId: string) => {
    const response = await api.get(`/professionals/${professionalId}/services`);
    return response.data;
  },
};
import { api } from './api';
import {
  CompanyUpdateRequest,
  CompanyPublic,
} from '../types/company';

export const companyService = {
  /* =======================
     PUBLIC (SEM AUTH)
  ======================= */
  getPublic: async (companyId: string): Promise<CompanyPublic> => {
    if (!companyId) {
      throw new Error('companyId não informado');
    }

    const response = await api.get(
      `/companies/public/${companyId}`
    );

    return response.data;
  },

  /* =======================
     PRIVATE (JWT)
     🔐 companyId vem do token
  ======================= */
  getSettings: async () => {
    const response = await api.get(
      '/settings/company'
    );

    return response.data;
  },

  updateSettings: async (
    data: CompanyUpdateRequest
  ) => {
    const response = await api.put(
      '/settings/company',
      data
    );

    return response.data;
  },

  uploadLogo: async (
    formData: FormData
  ) => {
    const response = await api.post(
      '/companies/logo',
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    return response.data;
  },
};

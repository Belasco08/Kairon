import { api } from './api';
import {
  CompanyUpdateRequest,
  CompanyPublic,
} from '../types/company';

export const companyService = {
  getPublic: async (companyId: string): Promise<CompanyPublic> => {
    const response = await api.get(`/companies/public/${companyId}`);
    return response.data;
  },

  getSettings: async (companyId: string) => {
    const response = await api.get(`/companies/${companyId}/settings`);
    return response.data;
  },

  updateSettings: async (
    companyId: string,
    data: CompanyUpdateRequest
  ) => {
    const response = await api.put(`/companies/${companyId}`, data);
    return response.data;
  },

  uploadLogo: async (companyId: string, formData: FormData) => {
    const response = await api.post(
      `/companies/${companyId}/logo`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    return response.data;
  },
};

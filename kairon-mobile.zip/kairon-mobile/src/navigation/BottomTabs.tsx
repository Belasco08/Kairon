import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialIcons } from '@expo/vector-icons';

import { Home } from '../screens/dashboard/Home';
import { AppointmentList } from '../screens/schedule/AppointmentList';
import { ServiceList } from '../screens/services/ServiceList';
import { ProfessionalList } from '../screens/professionals/ProfessionalList';
import { ClientList } from '../screens/clients/ClientList';
import { FinanceDashboard } from '../screens/finance/Dashboard';
import { CompanySettings } from '../screens/settings/CompanySettings';

import { colors } from '../styles/colors';

type BottomTabParamList = {
  Dashboard: undefined;
  Schedule: undefined;
  Services: undefined;
  Professionals: undefined;
  Clients: undefined;
  Finance: undefined;
  Settings: undefined;
};

const Tab = createBottomTabNavigator<BottomTabParamList>();

export function BottomTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }: { color: string; size: number }) => {
          let iconName: keyof typeof MaterialIcons.glyphMap = 'circle';

          switch (route.name) {
            case 'Dashboard':
              iconName = 'dashboard';
              break;
            case 'Schedule':
              iconName = 'calendar-today';
              break;
            case 'Services':
              iconName = 'style';
              break;
            case 'Professionals':
              iconName = 'people';
              break;
            case 'Clients':
              iconName = 'person';
              break;
            case 'Finance':
              iconName = 'attach-money';
              break;
            case 'Settings':
              iconName = 'settings';
              break;
          }

          return <MaterialIcons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        headerShown: false,
      })}
    >
      <Tab.Screen name="Dashboard" component={Home} options={{ tabBarLabel: 'Início' }} />
      <Tab.Screen name="Schedule" component={AppointmentList} options={{ tabBarLabel: 'Agenda' }} />
      <Tab.Screen name="Services" component={ServiceList} options={{ tabBarLabel: 'Serviços' }} />
      <Tab.Screen name="Professionals" component={ProfessionalList} options={{ tabBarLabel: 'Profissionais' }} />
      <Tab.Screen name="Clients" component={ClientList} options={{ tabBarLabel: 'Clientes' }} />
      <Tab.Screen name="Finance" component={FinanceDashboard} options={{ tabBarLabel: 'Financeiro' }} />
      <Tab.Screen name="Settings" component={CompanySettings} options={{ tabBarLabel: 'Configurações' }} />
    </Tab.Navigator>
  );
}

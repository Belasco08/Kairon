import React from 'react';
import { View, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Stacks
import { AuthStack } from './AuthStack';
import { AppStack } from './AppStack';
import { PublicStack } from './PublicStack';

// Contexts
import { useAuth } from '../hooks/useAuth';

const Stack = createNativeStackNavigator();

export function Navigation() {
  const { user, loading, company } = useAuth();

  // Loading simples (sem LoadingScreen)
  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!user ? (
          // Não logado
          <Stack.Screen name="Auth" component={AuthStack} />
        ) : !company ? (
          // Logado, mas sem empresa
          <Stack.Screen name="Auth" component={AuthStack} />
        ) : user.role === 'CLIENT' ? (
          // Fluxo público
          <Stack.Screen name="Public" component={PublicStack} />
        ) : (
          // Fluxo principal
          <Stack.Screen name="App" component={AppStack} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

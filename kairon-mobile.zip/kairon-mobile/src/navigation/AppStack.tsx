import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { BottomTabs } from './BottomTabs';

// Service Screens
import { ServiceList } from '../screens/services/ServiceList';
import { CreateService } from '../screens/services/CreateService';
import { EditService } from '../screens/services/EditService';

// Professional Screens
import { ProfessionalList } from '../screens/professionals/ProfessionalList';
import { CreateProfessional } from '../screens/professionals/CreateProfessional';
import { EditProfessional } from '../screens/professionals/EditProfessional';

// Client Screens
import { ClientList } from '../screens/clients/ClientList';
import { ClientDetails } from '../screens/clients/ClientDetails';

// Appointment Screens
import { AppointmentDetails } from '../screens/schedule/AppointmentDetails';
import { CreateAppointment } from '../screens/schedule/CreateAppointment';
import { EditAppointment } from '../screens/schedule/EditAppointment';
import { CalendarView } from '../screens/schedule/CalendarView';

// Finance Screens
import { FinanceDashboard } from '../screens/finance/Dashboard';
import { Reports } from '../screens/finance/Reports';
import { FinancialRecords } from '../screens/finance/FinancialRecords';

// Settings Screens
import { CompanySettings } from '../screens/settings/CompanySettings';
import { ProfileSettings } from '../screens/settings/ProfileSettings';
import { NotificationSettings } from '../screens/settings/NotificationSettings';

// Public Screens (for company owners/admins to view their public page)
import { CompanyPublic } from '../screens/public/CompanyPublic';
import { BookingScreen } from '../screens/public/BookingScreen';

const Stack = createNativeStackNavigator();

export function AppStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen name="BottomTabs" component={BottomTabs} />
      
      {/* Service Screens */}
      <Stack.Screen name="ServiceList" component={ServiceList} />
      <Stack.Screen name="CreateService" component={CreateService} />
      <Stack.Screen name="EditService" component={EditService} />
      
      {/* Professional Screens */}
      <Stack.Screen name="ProfessionalList" component={ProfessionalList} />
      <Stack.Screen name="CreateProfessional" component={CreateProfessional} />
      <Stack.Screen name="EditProfessional" component={EditProfessional} />
      
      {/* Client Screens */}
      <Stack.Screen name="ClientList" component={ClientList} />
      <Stack.Screen name="ClientDetails" component={ClientDetails} />
      
      {/* Appointment Screens */}
      <Stack.Screen name="AppointmentDetails" component={AppointmentDetails} />
      <Stack.Screen name="CreateAppointment" component={CreateAppointment} />
      <Stack.Screen name="EditAppointment" component={EditAppointment} />
      <Stack.Screen name="CalendarView" component={CalendarView} />
      
      {/* Finance Screens */}
      <Stack.Screen name="FinanceDashboard" component={FinanceDashboard} />
      <Stack.Screen name="Reports" component={Reports} />
      <Stack.Screen name="FinancialRecords" component={FinancialRecords} />
      
      {/* Settings Screens */}
      <Stack.Screen name="CompanySettings" component={CompanySettings} />
      <Stack.Screen name="ProfileSettings" component={ProfileSettings} />
      <Stack.Screen name="NotificationSettings" component={NotificationSettings} />
      
      {/* Public Screens (for preview) */}
      <Stack.Screen name="CompanyPublic" component={CompanyPublic} />
      <Stack.Screen name="BookingScreen" component={BookingScreen} />
    </Stack.Navigator>
  );
}
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios'; // Importe o Axios direto
import { ChevronLeft, CheckCircle, Calendar, Clock, User, Sparkles } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';

// Configura o Axios para bater no seu backend
const api = axios.create({
    baseURL: 'http://localhost:8080'
});

type Step = 'SERVICE' | 'PROFESSIONAL' | 'DATETIME' | 'CONFIRM' | 'SUCCESS';

export function Booking() {
  const { companyId } = useParams();
  const [step, setStep] = useState<Step>('SERVICE');
  const [loading, setLoading] = useState(false);

  // Estados de DADOS REAIS
  const [services, setServices] = useState<any[]>([]);
  const [professionals, setProfessionals] = useState<any[]>([]);
  const [timeSlots, setTimeSlots] = useState<string[]>([]);

  // Estados de SELEÇÃO
  const [selectedService, setSelectedService] = useState<any>(null);
  const [selectedPro, setSelectedPro] = useState<any>(null);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');

  // 1. CARREGAR SERVIÇOS AO ABRIR A PÁGINA
  useEffect(() => {
    if (companyId) {
        api.get(`/public/services/${companyId}`)
           .then(res => setServices(res.data))
           .catch(err => console.error("Erro ao buscar serviços", err));
    }
  }, [companyId]);

  // 2. CARREGAR PROFISSIONAIS (Quando escolhe serviço ou ao carregar, depende da lógica)
  // Aqui vamos carregar todos da empresa. Se quiser filtrar por quem faz o serviço, precisaria de ajuste no back.
  useEffect(() => {
      if (companyId && step === 'PROFESSIONAL') {
          api.get(`/public/professionals/${companyId}`)
             .then(res => setProfessionals(res.data))
             .catch(err => console.error("Erro ao buscar profissionais", err));
      }
  }, [companyId, step]);

  // 3. CARREGAR HORÁRIOS (Quando muda Data ou Profissional)
  useEffect(() => {
      if (selectedPro && date) {
          api.get('/public/availability', {
              params: {
                  professionalId: selectedPro.id,
                  date: date
              }
          })
          .then(res => setTimeSlots(res.data))
          .catch(err => console.error("Erro ao buscar horários", err));
      }
  }, [selectedPro, date]);

  function handleBack() {
    if (step === 'PROFESSIONAL') setStep('SERVICE');
    if (step === 'DATETIME') setStep('PROFESSIONAL');
    if (step === 'CONFIRM') setStep('DATETIME');
  }

  async function handleConfirm() {
    if (!clientName || !clientPhone) return alert('Por favor, preencha seus dados!');
    
    setLoading(true);
    
    try {
        // ENVIAR PARA O BANCO DE DADOS
        await api.post('/public/appointments', {
            companyId,
            serviceId: selectedService.id,
            professionalId: selectedPro.id,
            date,
            time, // Formato "14:00" ou "14:00:00" dependendo do back
            clientName,
            clientPhone
        });

        setStep('SUCCESS');
    } catch (error) {
        console.error(error);
        alert('Erro ao realizar agendamento. Tente novamente.');
    } finally {
        setLoading(false);
    }
  }

  if (step === 'SUCCESS') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6 animate-bounce">
          <CheckCircle className="text-green-600 w-12 h-12" />
        </div>
        <h1 className="text-2xl font-bold text-green-900 mb-2">Agendamento Confirmado!</h1>
        <p className="text-green-700">Obrigado, {clientName}. Seu horário está reservado.</p>
        
        {/* Resumo final */}
        <div className="mt-8 bg-white p-6 rounded-2xl shadow-sm w-full max-w-sm text-left border border-green-100">
            <div className="flex justify-between mb-2">
                <span className="text-gray-500">Serviço</span>
                <span className="font-bold">{selectedService?.name}</span>
            </div>
            <div className="flex justify-between mb-2">
                <span className="text-gray-500">Profissional</span>
                <span className="font-bold">{selectedPro?.name}</span>
            </div>
            <div className="flex justify-between">
                <span className="text-gray-500">Data</span>
                <span className="font-bold">{date} às {time}</span>
            </div>
        </div>
      </div>
    );
  }

  // O RESTANTE DO RENDER (JSX) É IGUAL, SÓ CUIDAR AS VARIÁVEIS
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header Fixo */}
      <header className="bg-white p-4 sticky top-0 z-10 shadow-sm border-b border-slate-100">
        <div className="flex items-center gap-3">
            {step !== 'SERVICE' && (
                <button onClick={handleBack} className="p-2 -ml-2 hover:bg-slate-100 rounded-full transition-colors">
                    <ChevronLeft className="text-slate-600" />
                </button>
            )}
            <div>
                <h1 className="font-bold text-slate-900">Agendamento Online</h1>
                <p className="text-xs text-slate-500 flex items-center gap-1">
                    Passo {step === 'SERVICE' ? 1 : step === 'PROFESSIONAL' ? 2 : step === 'DATETIME' ? 3 : 4} de 4
                </p>
            </div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4">
        
        {/* PASSO 1: SERVIÇOS (DINÂMICO) */}
        {step === 'SERVICE' && (
            <div className="space-y-4">
                <h2 className="text-xl font-bold text-slate-900 mb-2">Qual procedimento deseja?</h2>
                
                {services.length === 0 && <p>Carregando serviços...</p>}

                {services.map(service => (
                    <button 
                        key={service.id}
                        onClick={() => { setSelectedService(service); setStep('PROFESSIONAL'); }}
                        className="w-full bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center hover:border-slate-900 transition-all group"
                    >
                        <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-600 group-hover:bg-slate-900 group-hover:text-white transition-colors">
                                <Sparkles size={20} />
                            </div>
                            <div className="text-left">
                                <span className="block font-bold text-slate-900">{service.name}</span>
                                {/* Ajuste se seu backend manda 'duration' como numero */}
                                <span className="text-xs text-slate-500">{service.duration} min</span>
                            </div>
                        </div>
                        <span className="font-bold text-slate-900">R$ {service.price}</span>
                    </button>
                ))}
            </div>
        )}

        {/* PASSO 2: PROFISSIONAL (DINÂMICO) */}
        {step === 'PROFESSIONAL' && (
            <div className="space-y-4">
                <h2 className="text-xl font-bold text-slate-900 mb-2">Escolha o profissional</h2>

                {professionals.length === 0 && <p>Carregando profissionais...</p>}

                {professionals.map(pro => (
                    <button 
                        key={pro.id}
                        onClick={() => { setSelectedPro(pro); setStep('DATETIME'); }}
                        className="w-full bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 hover:border-slate-900 transition-all group"
                    >
                        <div className="w-14 h-14 bg-slate-200 rounded-full flex items-center justify-center text-slate-600 font-bold text-lg group-hover:bg-slate-900 group-hover:text-white transition-colors">
                            {pro.name.charAt(0)}
                        </div>
                        <div className="text-left">
                            <span className="block font-bold text-slate-900 text-lg">{pro.name}</span>
                        </div>
                    </button>
                ))}
            </div>
        )}

        {/* PASSO 3: DATA E HORA (DINÂMICO) */}
        {step === 'DATETIME' && (
            <div className="space-y-6">
                <div>
                    <h2 className="text-xl font-bold text-slate-900 mb-4">Escolha a data</h2>
                    <input 
                        type="date" 
                        className="w-full p-4 bg-white border border-slate-200 rounded-xl text-slate-900 text-lg outline-none focus:ring-2 focus:ring-slate-900"
                        onChange={(e) => setDate(e.target.value)}
                    />
                </div>

                {date && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <h2 className="text-xl font-bold text-slate-900 mb-4">Horários disponíveis</h2>
                        
                        {timeSlots.length === 0 ? (
                            <p className="text-red-500">Sem horários livres nesta data.</p>
                        ) : (
                            <div className="grid grid-cols-3 gap-3">
                                {timeSlots.map(slot => (
                                    <button
                                        key={slot}
                                        onClick={() => { setTime(slot); setStep('CONFIRM'); }}
                                        className="py-3 px-2 bg-white border border-slate-200 rounded-xl font-bold text-slate-700 hover:bg-slate-900 hover:text-white transition-colors shadow-sm"
                                    >
                                        {slot}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
        )}

        {/* PASSO 4: CONFIRMAÇÃO (IGUAL AO ANTERIOR) */}
        {step === 'CONFIRM' && (
            <div className="space-y-6">
                {/* ... (Mesmo código de confirmação visual do anterior) ... */}
                {/* Apenas certifique-se que o botão chama handleConfirm */}
                <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-lg">
                    <h2 className="text-xl font-bold mb-4">Resumo</h2>
                    <div className="space-y-3 text-slate-300">
                        <div className="flex items-center gap-3">
                            <Sparkles size={18} />
                            <span>{selectedService?.name}</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <User size={18} />
                            <span>{selectedPro?.name}</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <Calendar size={18} />
                            <span>{date}</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <Clock size={18} />
                            <span>{time}</span>
                        </div>
                        <div className="pt-4 mt-4 border-t border-slate-700 flex justify-between text-white font-bold text-lg">
                            <span>Total Estimado</span>
                            <span>R$ {selectedService?.price}</span>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <h3 className="font-bold text-slate-900">Seus dados para contato</h3>
                    <Input 
                        placeholder="Seu Nome Completo" 
                        value={clientName}
                        onChange={e => setClientName(e.target.value)}
                    />
                    <Input 
                        placeholder="Seu WhatsApp (11 99999...)" 
                        type="tel"
                        value={clientPhone}
                        onChange={e => setClientPhone(e.target.value)}
                    />
                </div>

                <div className="pt-4">
                    <Button onClick={handleConfirm} loading={loading}>
                        Confirmar Agendamento
                    </Button>
                </div>
            </div>
        )}

      </main>
    </div>
  );
}
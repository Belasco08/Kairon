package com.kairon.repository;

import com.kairon.domain.entity.Appointment;
import com.kairon.domain.enums.AppointmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, String> {

    List<Appointment> findByCompanyId(String companyId);

    List<Appointment> findByCompanyIdAndProfessionalId(String companyId, String professionalId);

    List<Appointment> findByCompanyIdAndClientId(String companyId, String clientId);

    Optional<Appointment> findByIdAndCompanyId(String id, String companyId);

    @Query("""
        SELECT a
        FROM Appointment a
        WHERE a.company.id = :companyId
          AND a.startTime >= :start
          AND a.startTime < :end
    """)
    List<Appointment> findByCompanyIdAndDateRange(
            @Param("companyId") String companyId,
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end
    );

    @Query("""
        SELECT COUNT(a)
        FROM Appointment a
        WHERE a.company.id = :companyId
          AND a.status = 'COMPLETED'
          AND a.completedAt >= :start
          AND a.completedAt < :end
    """)
    Long countCompletedAppointments(
            @Param("companyId") String companyId,
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end
    );

    @Query("""
        SELECT COALESCE(SUM(a.totalPrice), 0)
        FROM Appointment a
        WHERE a.company.id = :companyId
          AND a.status = 'COMPLETED'
          AND a.completedAt >= :start
          AND a.completedAt < :end
    """)
    BigDecimal sumRevenue(
            @Param("companyId") String companyId,
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end
    );

    @Query("SELECT COUNT(a) > 0 FROM Appointment a " +
            "WHERE a.professional.id = :professionalId " +
            "AND a.status != 'CANCELED' " +  // Ignora agendamentos cancelados
            "AND (" +
            "  (a.startTime < :endTime AND a.endTime > :startTime)" + // Lógica de Sobreposição
            ")")
    boolean existsByProfessionalAndDateOverlap(
            @Param("professionalId") String professionalId,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime
    );
    // Consultas Globais (Para o Dono)
    @Query("SELECT COALESCE(SUM(a.totalPrice), 0) FROM Appointment a WHERE a.company.id = :companyId AND a.status = 'COMPLETED'")
    BigDecimal sumTotalPriceByCompanyId(String companyId);

    int countByCompanyId(String companyId);

    // Consultas Filtradas (Para o Profissional)
    @Query("SELECT COALESCE(SUM(a.totalPrice), 0) FROM Appointment a WHERE a.professional.id = :professionalId AND a.status = 'COMPLETED'")
    BigDecimal sumTotalPriceByProfessionalId(String professionalId);

    int countByProfessionalId(String professionalId);
}

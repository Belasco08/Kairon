package com.kairon.repository;

import com.kairon.domain.entity.FinancialRecord;
import com.kairon.domain.enums.FinancialType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface FinancialRecordRepository extends JpaRepository<FinancialRecord, String> {

    /* =========================
       BÁSICOS
       ========================= */

    List<FinancialRecord> findByCompanyId(String companyId);

    Page<FinancialRecord> findByCompanyId(String companyId, Pageable pageable);

    List<FinancialRecord> findByCompanyIdAndProfessionalId(
            String companyId,
            String professionalId
    );

    List<FinancialRecord> findByCompanyIdAndReferenceDateBetween(
            String companyId,
            LocalDateTime startDate,
            LocalDateTime endDate
    );

    List<FinancialRecord> findByCompanyIdAndTypeInAndReferenceDateBetween(
            String companyId,
            List<FinancialType> types,
            LocalDateTime startDate,
            LocalDateTime endDate
    );

    Page<FinancialRecord> findByCompanyIdAndTypeIn(
            String companyId,
            List<FinancialType> types,
            Pageable pageable
    );

    Page<FinancialRecord> findByCompanyIdAndReferenceDateBetween(
            String companyId,
            LocalDateTime startDate,
            LocalDateTime endDate,
            Pageable pageable
    );

    Page<FinancialRecord> findByCompanyIdAndTypeInAndReferenceDateBetween(
            String companyId,
            List<FinancialType> types,
            LocalDateTime startDate,
            LocalDateTime endDate,
            Pageable pageable
    );

    /* =========================
       SOMAS (BIGDECIMAL ✅)
       ========================= */

    @Query("""
        SELECT COALESCE(SUM(fr.amount), 0)
        FROM FinancialRecord fr
        WHERE fr.company.id = :companyId
          AND fr.type IN :types
          AND fr.referenceDate >= :startDate
          AND fr.referenceDate < :endDate
    """)
    BigDecimal sumAmountByDateRange(
            @Param("companyId") String companyId,
            @Param("types") List<FinancialType> types,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate
    );

    /* =========================
       APPOINTMENT
       ========================= */

    @Query("""
        SELECT fr
        FROM FinancialRecord fr
        WHERE fr.company.id = :companyId
          AND fr.appointment.id = :appointmentId
          AND fr.type = com.kairon.domain.enums.FinancialType.APPOINTMENT
    """)
    List<FinancialRecord> findAppointmentRecords(
            @Param("companyId") String companyId,
            @Param("appointmentId") String appointmentId
    );

    /* =========================
       DASHBOARD
       ========================= */

    @Query("""
        SELECT
            DATE(fr.referenceDate),
            COALESCE(SUM(fr.amount), 0),
            COUNT(DISTINCT fr.appointment.id)
        FROM FinancialRecord fr
        WHERE fr.company.id = :companyId
          AND fr.referenceDate >= :startDate
          AND fr.referenceDate < :endDate
          AND fr.type IN :types
        GROUP BY DATE(fr.referenceDate)
        ORDER BY DATE(fr.referenceDate)
    """)
    List<Object[]> findDailyRevenue(
            @Param("companyId") String companyId,
            @Param("types") List<FinancialType> types,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate
    );
}

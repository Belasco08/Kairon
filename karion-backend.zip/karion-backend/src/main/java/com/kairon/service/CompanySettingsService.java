package com.kairon.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kairon.domain.entity.Company;
import com.kairon.dto.request.CompanySettingsRequest;
import com.kairon.dto.response.CompanySettingsResponse;
import com.kairon.dto.response.CompanySettingsResponse.WorkHoursResponse;
import com.kairon.exception.BusinessException;
import com.kairon.exception.EntityNotFoundException;
import com.kairon.repository.CompanyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class CompanySettingsService {

    private final CompanyRepository companyRepository;
    private final ObjectMapper objectMapper;
    private final BaseService baseService;

    /* =========================
       GET BY ID
       ========================= */
    @Transactional(readOnly = true)
    public CompanySettingsResponse getCompanySettings(String companyId) {
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new EntityNotFoundException("Company not found"));

        return mapToResponse(company);
    }

    /* =========================
       UPDATE
       ========================= */
    @Transactional
    public CompanySettingsResponse updateCompanySettings(
            String companyId,
            CompanySettingsRequest request,
            String userCompanyId) {

        baseService.validateCompanyAccess(companyId, userCompanyId);

        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new EntityNotFoundException("Company not found"));

        validateBusinessRules(request);

        company.setName(request.getName());
        company.setBusinessType(request.getBusinessType());
        company.setSlotDuration(request.getSlotDuration());
        company.setBufferTime(request.getBufferTime());
        company.setCurrency(request.getCurrency().toUpperCase());
        company.setLogoUrl(request.getLogoUrl());
        company.setWebsite(request.getWebsite());
        company.setWorkHours(convertWorkHoursToJson(request.getWorkHours()));

        return mapToResponse(companyRepository.save(company));
    }

    /* =========================
       GET BY SLUG
       ========================= */
    @Transactional(readOnly = true)
    public CompanySettingsResponse getCompanySettingsBySlug(String slug) {
        Company company = companyRepository.findBySlug(slug)
                .orElseThrow(() -> new EntityNotFoundException("Company not found"));

        if (!company.isActive()) {
            throw new BusinessException("Company is inactive");
        }

        return mapToResponse(company);
    }

    /* =========================
       HELPERS
       ========================= */

    private CompanySettingsResponse mapToResponse(Company company) {

        return CompanySettingsResponse.builder()
                .id(company.getId())
                .name(company.getName())
                .slug(company.getSlug())
                .businessType(company.getBusinessType())
                .timezone(company.getTimezone())
                .slotDuration(company.getSlotDuration())
                .bufferTime(company.getBufferTime())
                .currency(company.getCurrency())
                .logoUrl(company.getLogoUrl())
                .website(company.getWebsite())
                .isActive(company.isActive())
                .isVerified(company.isVerified())
                .createdAt(company.getCreatedAt())
                .updatedAt(company.getUpdatedAt())
                .workHours(convertWorkHoursToResponse(company.getWorkHours()))
                .build();
    }

    private void validateBusinessRules(CompanySettingsRequest request) {

        if (request.getSlotDuration() == null || request.getSlotDuration() <= 0) {
            throw new BusinessException("Slot duration must be greater than zero");
        }

        if (request.getBufferTime() == null || request.getBufferTime() < 0) {
            throw new BusinessException("Buffer time cannot be negative");
        }

        if (request.getCurrency() == null || request.getCurrency().length() != 3) {
            throw new BusinessException("Invalid currency code");
        }

        if (request.getWorkHours() == null || request.getWorkHours().isEmpty()) {
            throw new BusinessException("Work hours must be provided");
        }
    }

    private JsonNode convertWorkHoursToJson(
            Map<String, CompanySettingsRequest.WorkHours> workHours) {

        ObjectNode root = objectMapper.createObjectNode();

        workHours.forEach((day, hours) -> {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("start", hours.getStart().toString());
            node.put("end", hours.getEnd().toString());
            node.put("active", hours.getActive());
            root.set(day, node);
        });

        return root;
    }

    private Map<String, WorkHoursResponse> convertWorkHoursToResponse(JsonNode jsonNode) {

        Map<String, WorkHoursResponse> response = new HashMap<>();

        if (jsonNode == null || !jsonNode.isObject()) {
            return response;
        }

        Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();

        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> entry = fields.next();
            JsonNode node = entry.getValue();

            WorkHoursResponse workHours = WorkHoursResponse.builder()
                    .start(LocalTime.parse(node.get("start").asText()))
                    .end(LocalTime.parse(node.get("end").asText()))
                    .active(node.get("active").asBoolean())
                    .build();

            response.put(entry.getKey(), workHours);
        }

        return response;
    }
}

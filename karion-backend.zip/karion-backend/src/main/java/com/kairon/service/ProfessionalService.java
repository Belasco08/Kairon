package com.kairon.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kairon.domain.entity.Company;
import com.kairon.domain.entity.Professional;
import com.kairon.domain.entity.Services;
import com.kairon.domain.entity.User;
import com.kairon.dto.request.AssignUserToProfessionalRequest;
import com.kairon.dto.request.ProfessionalRequest;
import com.kairon.dto.request.ProfessionalUpdateRequest;
import com.kairon.dto.response.ProfessionalResponse;
import com.kairon.dto.response.ProfessionalWithServicesResponse;
import com.kairon.dto.response.ServiceResponse;
import com.kairon.exception.BusinessException;
import com.kairon.repository.CompanyRepository;
import com.kairon.repository.ProfessionalRepository;
import com.kairon.repository.ServiceRepository;
import com.kairon.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProfessionalService extends BaseService {

    private final ProfessionalRepository professionalRepository;
    private final CompanyRepository companyRepository;
    private final UserRepository userRepository;
    private final ServiceRepository serviceRepository;
    private final ObjectMapper objectMapper;

    @Transactional
    public ProfessionalResponse createProfessional(String companyId, ProfessionalRequest request) {
        log.info("Creating professional for company: {}", companyId);

        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new BusinessException("Company not found"));

        // Check if phone already exists in company
        professionalRepository.findByCompanyId(companyId).stream()
                .filter(p -> p.getPhone().equals(request.getPhone()))
                .findFirst()
                .ifPresent(p -> {
                    throw new BusinessException("Phone number already registered for another professional in this company");
                });

        Professional professional = Professional.builder()
                //.id(UUID.randomUUID().toString())
                .name(request.getName())
                .description(request.getDescription())
                .phone(request.getPhone())
                .photoUrl(request.getPhotoUrl())
                .isActive(true)
                .workHours(request.getWorkHours() != null ?
                        request.getWorkHours() : createDefaultWorkHours())
                .daysOff(request.getDaysOff())
                .company(company)
                .build();

        professional = professionalRepository.save(professional);
        log.info("Professional created: {}", professional.getId());

        return mapToResponse(professional);
    }

    @Transactional
    public ProfessionalResponse updateProfessional(
            String companyId,
            String professionalId,
            ProfessionalUpdateRequest request
    ) {
        log.info("Updating professional: {} for company: {}", professionalId, companyId);

        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        // Validate phone uniqueness if changed
        if (request.getPhone() != null && !request.getPhone().equals(professional.getPhone())) {
            professionalRepository.findByCompanyId(companyId).stream()
                    .filter(p -> p.getPhone().equals(request.getPhone()))
                    .findFirst()
                    .ifPresent(p -> {
                        throw new BusinessException("Phone number already registered for another professional in this company");
                    });
            professional.setPhone(request.getPhone());
        }

        // Update fields if provided
        if (request.getName() != null) {
            professional.setName(request.getName());
        }

        if (request.getDescription() != null) {
            professional.setDescription(request.getDescription());
        }

        if (request.getPhotoUrl() != null) {
            professional.setPhotoUrl(request.getPhotoUrl());
        }

        if (request.getWorkHours() != null) {
            professional.setWorkHours(request.getWorkHours());
        }

        if (request.getDaysOff() != null) {
            professional.setDaysOff(request.getDaysOff());
        }

        if (request.getIsActive() != null) {
            professional.setActive(request.getIsActive());

            // If deactivating, disconnect from user
            if (!request.getIsActive() && professional.getUser() != null) {
                User user = professional.getUser();
                user.setProfessional(null);
                userRepository.save(user);
                professional.setUser(null);
            }
        }

        professional = professionalRepository.save(professional);
        log.info("Professional updated: {}", professionalId);

        return mapToResponse(professional);
    }

    @Transactional
    public void deleteProfessional(String companyId, String professionalId) {
        log.info("Deleting professional: {} for company: {}", professionalId, companyId);

        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        // Check if professional has appointments
        if (!professional.getAppointments().isEmpty()) {
            throw new BusinessException("Cannot delete professional with existing appointments. Deactivate instead.");
        }

        // Disconnect from user if linked
        if (professional.getUser() != null) {
            User user = professional.getUser();
            user.setProfessional(null);
            userRepository.save(user);
        }

        // Remove professional from services
        professional.getServices().forEach(service -> {
            service.setProfessional(null);
            serviceRepository.save(service);
        });

        professionalRepository.delete(professional);
        log.info("Professional deleted: {}", professionalId);
    }

    public ProfessionalResponse getProfessional(String companyId, String professionalId) {
        log.debug("Getting professional: {} for company: {}", professionalId, companyId);

        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        return mapToResponse(professional);
    }

    public List<ProfessionalResponse> getAllProfessionals(String companyId, Boolean activeOnly) {
        log.debug("Getting professionals for company: {}, activeOnly: {}", companyId, activeOnly);

        List<Professional> professionals;

        if (activeOnly != null && activeOnly) {
            professionals = professionalRepository.findByCompanyIdAndIsActive(companyId, true);
        } else {
            professionals = professionalRepository.findByCompanyId(companyId);
        }

        return professionals.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public ProfessionalResponse assignUserToProfessional(
            String companyId,
            String professionalId,
            AssignUserToProfessionalRequest request
    ) {
        log.info("Assigning user {} to professional {} for company: {}",
                request.getUserId(), professionalId, companyId);

        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        User user = userRepository.findByIdAndCompanyId(request.getUserId(), companyId)
                .orElseThrow(() -> new BusinessException("User not found in company"));

        // Check if user is already assigned to another professional
        professionalRepository.findByUserId(request.getUserId())
                .ifPresent(p -> {
                    if (!p.getId().equals(professionalId)) {
                        throw new BusinessException("User is already assigned to another professional");
                    }
                });

        // Check if user has correct role
        if (user.getRole() != com.kairon.domain.enums.Role.PROFESSIONAL) {
            throw new BusinessException("User must have PROFESSIONAL role");
        }

        // Check if professional is active
        if (!professional.isActive()) {
            throw new BusinessException("Cannot assign user to inactive professional");
        }

        // Update both sides of the relationship
        professional.setUser(user);
        user.setProfessional(professional);

        professional = professionalRepository.save(professional);
        userRepository.save(user);

        log.info("User {} assigned to professional {}", user.getId(), professionalId);

        return mapToResponse(professional);
    }

    @Transactional
    public ProfessionalResponse unassignUserFromProfessional(
            String companyId,
            String professionalId
    ) {
        log.info("Unassigning user from professional {} for company: {}", professionalId, companyId);

        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        if (professional.getUser() == null) {
            throw new BusinessException("Professional is not assigned to any user");
        }

        User user = professional.getUser();

        // Remove relationship
        professional.setUser(null);
        user.setProfessional(null);

        professional = professionalRepository.save(professional);
        userRepository.save(user);

        log.info("User unassigned from professional {}", professionalId);

        return mapToResponse(professional);
    }

    public List<ServiceResponse> getProfessionalServices(
            String companyId,
            String professionalId,
            Boolean activeOnly
    ) {
        log.debug("Getting services for professional: {} in company: {}", professionalId, companyId);

        // 1. Valida se o profissional existe e pertence à empresa
        professionalRepository.findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        // 2. Define o filtro de status (se activeOnly for true, filtra true. Se for false/null, traz tudo)
        Boolean statusFilter = (activeOnly != null && activeOnly) ? true : null;

        // 3. Usa o método unificado searchServices
        // Isso corrige o erro e garante segurança (filtra por companyId)
        Page<Services> servicesPage = serviceRepository.searchServices(
                companyId,
                null,           // category
                statusFilter,   // isActive
                null,           // onlineBooking
                professionalId, // professionalId
                Pageable.unpaged() // Traz todos os resultados sem paginar
        );

        return servicesPage.getContent().stream()
                .map(this::mapToServiceResponse)
                .collect(Collectors.toList());
    }

    public ProfessionalWithServicesResponse getProfessionalWithServices(
            String companyId,
            String professionalId
    ) {
        log.debug("Getting professional with services: {} for company: {}", professionalId, companyId);

        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalId, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        List<ServiceResponse> services = professional.getServices().stream()
                .map(this::mapToServiceResponse)
                .collect(Collectors.toList());

        return ProfessionalWithServicesResponse.builder()
                .id(professional.getId())
                .name(professional.getName())
                .description(professional.getDescription())
                .phone(professional.getPhone())
                .photoUrl(professional.getPhotoUrl())
                .isActive(professional.isActive())
                .services(services)
                .createdAt(professional.getCreatedAt())
                .build();
    }

    private ProfessionalResponse mapToResponse(Professional professional) {
        return ProfessionalResponse.builder()
                .id(professional.getId())
                .name(professional.getName())
                .description(professional.getDescription())
                .phone(professional.getPhone())
                .photoUrl(professional.getPhotoUrl())
                .isActive(professional.isActive())
                .workHours(professional.getWorkHours())
                .daysOff(professional.getDaysOff())
                .userId(professional.getUser() != null ? professional.getUser().getId() : null)
                .createdAt(professional.getCreatedAt())
                .updatedAt(professional.getUpdatedAt())
                .build();
    }

    private ServiceResponse mapToServiceResponse(Services service) {
        return ServiceResponse.builder()
                .id(service.getId())
                .name(service.getName())
                .description(service.getDescription())
                .price(service.getPrice())
                .duration(service.getDuration())
                .color(service.getColor())
                .isActive(service.isActive())
                .onlineBooking(service.isOnlineBooking())
                .category(service.getCategory())
                .professionalId(service.getProfessional() != null
                        ? service.getProfessional().getId()
                        : null)
                .professionalName(service.getProfessional() != null
                        ? service.getProfessional().getName()
                        : null)
                .createdAt(service.getCreatedAt())
                .build();
    }



    private JsonNode createDefaultWorkHours() {
        ObjectNode workHours = objectMapper.createObjectNode();

        ObjectNode monday = objectMapper.createObjectNode();
        monday.put("start", "08:00");
        monday.put("end", "18:00");
        monday.put("active", true);
        workHours.set("monday", monday);

        ObjectNode tuesday = objectMapper.createObjectNode();
        tuesday.put("start", "08:00");
        tuesday.put("end", "18:00");
        tuesday.put("active", true);
        workHours.set("tuesday", tuesday);

        ObjectNode wednesday = objectMapper.createObjectNode();
        wednesday.put("start", "08:00");
        wednesday.put("end", "18:00");
        wednesday.put("active", true);
        workHours.set("wednesday", wednesday);

        ObjectNode thursday = objectMapper.createObjectNode();
        thursday.put("start", "08:00");
        thursday.put("end", "18:00");
        thursday.put("active", true);
        workHours.set("thursday", thursday);

        ObjectNode friday = objectMapper.createObjectNode();
        friday.put("start", "08:00");
        friday.put("end", "18:00");
        friday.put("active", true);
        workHours.set("friday", friday);

        ObjectNode saturday = objectMapper.createObjectNode();
        saturday.put("start", "09:00");
        saturday.put("end", "13:00");
        saturday.put("active", true);
        workHours.set("saturday", saturday);

        ObjectNode sunday = objectMapper.createObjectNode();
        sunday.put("start", "09:00");
        sunday.put("end", "13:00");
        sunday.put("active", false);
        workHours.set("sunday", sunday);

        return workHours;
    }
}
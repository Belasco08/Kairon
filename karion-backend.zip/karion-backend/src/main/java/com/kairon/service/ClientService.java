package com.kairon.service;

import com.kairon.domain.entity.Client;
import com.kairon.domain.entity.Company;
import com.kairon.dto.request.ClientRequest;
import com.kairon.dto.response.ClientListResponse;
import com.kairon.dto.response.ClientResponse;
import com.kairon.exception.BusinessException;
import com.kairon.mapper.ClientMapper;
import com.kairon.repository.ClientRepository;
import com.kairon.repository.CompanyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class ClientService {

    private final ClientRepository clientRepository;
    private final CompanyRepository companyRepository;
    private final ClientMapper clientMapper;
    private final BaseService baseService;

    /* =========================
       CREATE
       ========================= */
    @Transactional
    public ClientResponse createClient(String companyId, ClientRequest request) {

        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new BusinessException("Company not found"));

        clientRepository.findByPhoneAndCompanyId(request.getPhone(), companyId)
                .ifPresent(c -> {
                    throw new BusinessException("Client with this phone already exists");
                });

        Client client = clientMapper.toEntity(request);
        client.setId(UUID.randomUUID().toString());
        client.setCompany(company);

        return clientMapper.toResponse(clientRepository.save(client));
    }

    /* =========================
       READ
       ========================= */
    @Transactional(readOnly = true)
    public ClientResponse getClient(String companyId, String clientId) {

        Client client = clientRepository.findByIdAndCompanyId(clientId, companyId)
                .orElseThrow(() -> new BusinessException("Client not found"));

        baseService.validateResourceBelongsToCompany(
                client.getCompany().getId(),
                companyId
        );

        return enrichClientResponse(client);
    }

    /* =========================
       UPDATE
       ========================= */
    @Transactional
    public ClientResponse updateClient(String companyId, String clientId, ClientRequest request) {

        Client client = clientRepository.findByIdAndCompanyId(clientId, companyId)
                .orElseThrow(() -> new BusinessException("Client not found"));

        baseService.validateResourceBelongsToCompany(
                client.getCompany().getId(),
                companyId
        );

        if (!client.getPhone().equals(request.getPhone())) {
            clientRepository.findByPhoneAndCompanyId(request.getPhone(), companyId)
                    .ifPresent(c -> {
                        if (!c.getId().equals(clientId)) {
                            throw new BusinessException("Another client already has this phone");
                        }
                    });
        }

        clientMapper.updateEntity(request, client);

        return enrichClientResponse(clientRepository.save(client));
    }

    /* =========================
       LIST
       ========================= */
    @Transactional(readOnly = true)
    public Page<ClientListResponse> listClients(
            String companyId,
            String search,
            Pageable pageable
    ) {

        baseService.validateCompanyAccess(companyId, companyId);

        Page<Client> clients = (search != null && !search.isBlank())
                ? clientRepository.searchByCompanyId(companyId, search.trim(), pageable)
                : clientRepository.findByCompanyId(companyId, pageable);

        return clients.map(client -> {
            ClientListResponse response = clientMapper.toListResponse(client);
            enrichListResponse(response, client);
            return response;
        });
    }

    @Transactional(readOnly = true)
    public List<ClientListResponse> searchClients(String companyId, String searchTerm) {

        baseService.validateCompanyAccess(companyId, companyId);

        return clientRepository.searchByCompanyId(companyId, searchTerm)
                .stream()
                .map(client -> {
                    ClientListResponse response = clientMapper.toListResponse(client);
                    enrichListResponse(response, client);
                    return response;
                })
                .toList();
    }

    /* =========================
       HELPERS
       ========================= */

    private ClientResponse enrichClientResponse(Client client) {
        // hoje não há enrich extra, apenas mapeia
        return clientMapper.toResponse(client);
    }

    private void enrichListResponse(
            ClientListResponse response,
            Client client
    ) {
        // reservado para futuras regras (ex: totalAppointments, lastVisit)
        // por enquanto, não faz nada
    }
}

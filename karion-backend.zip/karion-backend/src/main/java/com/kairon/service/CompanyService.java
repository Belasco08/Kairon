package com.kairon.service;

import com.kairon.domain.entity.Company;
import com.kairon.domain.entity.User;
import com.kairon.dto.request.CompanyUpdateRequest;
import com.kairon.dto.response.CompanyResponse;
import com.kairon.dto.response.PublicCompanyResponse;
import com.kairon.exception.BusinessException;
import com.kairon.exception.EntityNotFoundException;
import com.kairon.mapper.CompanyMapper;
import com.kairon.repository.CompanyRepository;
import com.kairon.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CompanyService {

    private final CompanyRepository companyRepository;
    private final UserRepository userRepository;
    private final CompanyMapper companyMapper;

    /* =======================
       PRIVATE (JWT)
    ======================= */

    @Transactional(readOnly = true)
    public CompanyResponse getCompanyData() {
        User user = getAuthenticatedUser();

        Company company = companyRepository.findActiveById(user.getCompany().getId())
                .orElseThrow(() -> new BusinessException("Company not found"));

        return companyMapper.toResponse(company);
    }

    @Transactional
    public CompanyResponse updateCompany(CompanyUpdateRequest request) {
        User user = getAuthenticatedUser();

        if (!user.getRole().name().equals("OWNER")) {
            throw new BusinessException("Only company owner can update company data");
        }

        Company company = companyRepository.findActiveById(user.getCompany().getId())
                .orElseThrow(() -> new BusinessException("Company not found"));

        company.setName(request.getName());
        company.setBusinessType(request.getBusinessType());
        company.setTimezone(request.getTimezone());
        company.setLogoUrl(request.getLogoUrl());
        company.setWebsite(request.getWebsite());
        company.setSlotDuration(request.getSlotDuration());
        company.setBufferTime(request.getBufferTime());
        company.setCurrency(request.getCurrency());

        company = companyRepository.save(company);

        return companyMapper.toResponse(company);
    }

    /* =======================
       PUBLIC
    ======================= */

    @Transactional(readOnly = true)
    public PublicCompanyResponse getPublicCompanyData(String slug) {
        Company company = companyRepository.findBySlug(slug)
                .orElseThrow(() -> new BusinessException("Company not found"));

        if (!company.isActive()) {
            throw new BusinessException("Company is not active");
        }

        return companyMapper.toPublicResponse(company);
    }

    /* =======================
       INTERNAL
    ======================= */

    @Transactional(readOnly = true)
    public Company getCompanyEntity(String companyId) {
        return companyRepository.findById(companyId)
                .orElseThrow(() -> new EntityNotFoundException("Company not found"));
    }

    private User getAuthenticatedUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();

        return userRepository.findActiveUserByEmail(email)
                .orElseThrow(() -> new BusinessException("User not found"));
    }
}

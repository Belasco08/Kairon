package com.kairon.service;

import com.kairon.domain.entity.*;
import com.kairon.domain.enums.FinancialType;
import com.kairon.dto.request.*;
import com.kairon.dto.response.*;
import com.kairon.exception.BusinessException;
import com.kairon.repository.*;
import com.kairon.repository.AppointmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class FinancialService extends BaseService {

    private final FinancialRecordRepository financialRecordRepository;
    private final AppointmentRepository appointmentRepository;
    private final ProfessionalRepository professionalRepository;
    private final ServiceRepository serviceRepository;
    private final CompanyService companyService;

    /* =========================
       CRUD
       ========================= */

    @Transactional(readOnly = true)
    public Page<FinancialResponse> getFinancialRecords(String companyId, FinancialFilterRequest filter) {

        Pageable pageable = PageRequest.of(
                filter.getPage(),
                filter.getSize(),
                Sort.by(Sort.Direction.DESC, "referenceDate")
        );

        return financialRecordRepository
                .findByCompanyId(companyId, pageable)
                .map(this::mapToResponse);
    }

    @Transactional
    public FinancialResponse createFinancialRecord(String companyId, FinancialRequest request) {

        Company company = companyService.getCompanyEntity(companyId);

        Professional professional = null;
        if (request.getProfessionalId() != null) {
            professional = professionalRepository
                    .findByIdAndCompanyId(request.getProfessionalId(), companyId)
                    .orElseThrow(() -> new BusinessException("Professional not found"));
        }

        Appointment appointment = null;
        if (request.getAppointmentId() != null) {
            appointment = appointmentRepository
                    .findByIdAndCompanyId(request.getAppointmentId(), companyId)
                    .orElseThrow(() -> new BusinessException("Appointment not found"));
        }

        FinancialRecord record = FinancialRecord.builder()
                .id(UUID.randomUUID().toString())
                .type(request.getType())
                // ✅ DTO → BigDecimal
                .amount(BigDecimal.valueOf(request.getAmount()))
                .description(request.getDescription())
                .appointment(appointment)
                .company(company)
                .professional(professional)
                .paymentMethod(request.getPaymentMethod())
                .referenceDate(request.getReferenceDate())
                .build();

        return mapToResponse(financialRecordRepository.save(record));
    }

    /* =========================
       DASHBOARD
       ========================= */

    @Transactional(readOnly = true)
    public DashboardResponse getDashboard(String companyId, DashboardRequest request) {

        LocalDateTime startDate = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        LocalDateTime endDate = LocalDateTime.now();

        BigDecimal revenue = Optional.ofNullable(
                financialRecordRepository.sumAmountByDateRange(
                        companyId,
                        List.of(FinancialType.APPOINTMENT, FinancialType.ADJUSTMENT),
                        startDate,
                        endDate
                )
        ).orElse(BigDecimal.ZERO);

        BigDecimal expenses = Optional.ofNullable(
                financialRecordRepository.sumAmountByDateRange(
                        companyId,
                        List.of(FinancialType.REFUND, FinancialType.EXPENSE),
                        startDate,
                        endDate
                )
        ).orElse(BigDecimal.ZERO);

        Long appointmentCount =
                appointmentRepository.countCompletedAppointments(
                        companyId, startDate, endDate
                );

        BigDecimal averageTicket =
                appointmentCount > 0
                        ? revenue.divide(BigDecimal.valueOf(appointmentCount), 2, RoundingMode.HALF_UP)
                        : BigDecimal.ZERO;

        return DashboardResponse.builder()
                .revenue(revenue.doubleValue())
                .expenses(expenses.doubleValue())
                .balance(revenue.subtract(expenses).doubleValue())
                .appointmentCount(appointmentCount.intValue())
                .averageTicket(averageTicket.doubleValue())
                .dailyEvolution(getDailyEvolution(companyId, startDate, endDate))
                .topServices(getTopServices(companyId, startDate, endDate))
                .build();
    }

    /* =========================
       HELPERS
       ========================= */

    private List<DashboardResponse.DailySummary> getDailyEvolution(
            String companyId, LocalDateTime start, LocalDateTime end) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM");

        return financialRecordRepository
                .findDailyRevenue(companyId, List.of(FinancialType.APPOINTMENT), start, end)
                .stream()
                .map(row -> DashboardResponse.DailySummary.builder()
                        .date(((java.sql.Date) row[0]).toLocalDate().format(formatter))
                        .revenue(((BigDecimal) row[1]).doubleValue())
                        .appointments(((Long) row[2]).intValue())
                        .build())
                .toList();
    }

    private List<DashboardResponse.ServiceSummary> getTopServices(
            String companyId,
            LocalDateTime start,
            LocalDateTime end
    ) {

        int limit = 5;
        Pageable pageable = PageRequest.of(0, limit);

        return serviceRepository
                .findTopServicesByRevenue(companyId, start, end, pageable)
                .stream()
                .map(row -> DashboardResponse.ServiceSummary.builder()
                        .serviceId((String) row[0])
                        .serviceName((String) row[1])
                        .revenue(((BigDecimal) row[2]).doubleValue())
                        .count(((Long) row[3]).intValue())
                        .build())
                .toList();
    }

    private FinancialResponse mapToResponse(FinancialRecord record) {
        return FinancialResponse.builder()
                .id(record.getId())
                .type(record.getType())
                .amount(record.getAmount().doubleValue())
                .description(record.getDescription())
                .referenceDate(record.getReferenceDate())
                .build();
    }
    public FinancialResponse getFinancialRecordById(
            String companyId,
            String recordId) {

        FinancialRecord record = financialRecordRepository.findById(recordId)
                .orElseThrow(() -> new BusinessException("Financial record not found"));

        if (!record.getCompany().getId().equals(companyId)) {
            throw new BusinessException("Access denied");
        }

        return mapToResponse(record);
    }

    public FinancialResponse updateFinancialRecord(
            String companyId,
            String recordId,
            FinancialRequest request) {

        FinancialRecord record = financialRecordRepository.findById(recordId)
                .orElseThrow(() -> new BusinessException("Financial record not found"));

        if (!record.getCompany().getId().equals(companyId)) {
            throw new BusinessException("Access denied");
        }

        record.setType(request.getType());
        record.setAmount(BigDecimal.valueOf(request.getAmount()));
        record.setDescription(request.getDescription());
        record.setPaymentMethod(request.getPaymentMethod());
        record.setReferenceDate(request.getReferenceDate());

        return mapToResponse(financialRecordRepository.save(record));
    }

    public void deleteFinancialRecord(
            String companyId,
            String recordId) {

        FinancialRecord record = financialRecordRepository.findById(recordId)
                .orElseThrow(() -> new BusinessException("Financial record not found"));

        if (!record.getCompany().getId().equals(companyId)) {
            throw new BusinessException("Access denied");
        }

        financialRecordRepository.delete(record);
    }

}

package com.kairon.service;

import com.kairon.domain.entity.*;
import com.kairon.domain.enums.FinancialType;
import com.kairon.domain.enums.Role;
import com.kairon.dto.request.*;
import com.kairon.dto.response.*;
import com.kairon.exception.BusinessException;
import com.kairon.repository.*;
import com.kairon.security.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class FinancialService extends BaseService {

    private final FinancialRecordRepository financialRecordRepository;
    private final AppointmentRepository appointmentRepository;
    private final ProfessionalRepository professionalRepository;
    private final ServiceRepository serviceRepository;
    private final CompanyService companyService;
    private final UserRepository userRepository;

    /* =========================
       CRUD
       ========================= */

    @Transactional(readOnly = true)
    public Page<FinancialResponse> getFinancialRecords(String companyId, FinancialFilterRequest filter) {

        Pageable pageable = PageRequest.of(
                filter.getPage(),
                filter.getSize(),
                Sort.by(Sort.Direction.DESC, "referenceDate")
        );

        return financialRecordRepository
                .findByCompanyId(companyId, pageable)
                .map(this::mapToResponse);
    }

    @Transactional
    public FinancialResponse createFinancialRecord(String companyId, FinancialRequest request) {

        Company company = companyService.getCompanyEntity(companyId);

        Professional professional = null;
        if (request.getProfessionalId() != null) {
            professional = professionalRepository
                    .findByIdAndCompanyId(request.getProfessionalId(), companyId)
                    .orElseThrow(() -> new BusinessException("Professional not found"));
        }

        Appointment appointment = null;
        if (request.getAppointmentId() != null) {
            appointment = appointmentRepository
                    .findByIdAndCompanyId(request.getAppointmentId(), companyId)
                    .orElseThrow(() -> new BusinessException("Appointment not found"));
        }

        FinancialRecord record = FinancialRecord.builder()
                .id(UUID.randomUUID().toString())
                .type(request.getType())
                .amount(BigDecimal.valueOf(request.getAmount()))
                .description(request.getDescription())
                .appointment(appointment)
                .company(company)
                .professional(professional)
                .paymentMethod(request.getPaymentMethod())
                .referenceDate(request.getReferenceDate())
                .build();

        return mapToResponse(financialRecordRepository.save(record));
    }

    /* =========================
       DASHBOARD
       ========================= */

    @Transactional(readOnly = true)
    public DashboardResponse getDashboard(String companyId, DashboardRequest request) {

        // Garante o intervalo do mês atual até o final do dia de hoje
        LocalDateTime startDate = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        LocalDateTime endDate = LocalDate.now().atTime(23, 59, 59);

        String currentUserId = SecurityUtils.getCurrentUserId();
        User currentUser = userRepository.findById(currentUserId).orElseThrow();

        BigDecimal revenue = BigDecimal.ZERO;
        BigDecimal expenses = BigDecimal.ZERO;
        Long appointmentCount = 0L;
        List<DashboardResponse.DailySummary> dailyEvolution;
        List<DashboardResponse.ServiceSummary> topServices;

        if (currentUser.getRole() == Role.PROFESSIONAL) {
            // === LÓGICA DO PROFISSIONAL (Vê suas Comissões) ===
            Professional prof = professionalRepository.findByUserId(currentUserId).orElseThrow();
            String profId = prof.getId();

            // 1. Receita: Soma das COMISSÕES (Registradas como EXPENSE da empresa vinculadas a ele)
            revenue = Optional.ofNullable(
                    financialRecordRepository.sumAmountByProfessionalAndDateRange(
                            companyId, profId, List.of(FinancialType.EXPENSE), startDate, endDate
                    )
            ).orElse(BigDecimal.ZERO);

            // 2. Contagem: Atendimentos concluídos dele
            Long count = appointmentRepository.countCompletedAppointmentsByProfessional(
                    companyId, profId, startDate, endDate
            );
            appointmentCount = count != null ? count : 0L;

            // 3. Gráficos filtrados
            dailyEvolution = getDailyEvolutionByProfessional(companyId, profId, startDate, endDate);
            topServices = getTopServicesByProfessional(companyId, profId, startDate, endDate);

        } else {
            // === LÓGICA DO OWNER (Vê o Todo) ===

            // 1. Receita Bruta (Agendamentos + Ajustes manuais de entrada)
            revenue = Optional.ofNullable(
                    financialRecordRepository.sumAmountByDateRange(
                            companyId, List.of(FinancialType.APPOINTMENT, FinancialType.ADJUSTMENT), startDate, endDate
                    )
            ).orElse(BigDecimal.ZERO);

            // 2. Despesas (Reembolsos + Despesas Manuais + COMISSÕES PAGAS)
            expenses = Optional.ofNullable(
                    financialRecordRepository.sumAmountByDateRange(
                            companyId, List.of(FinancialType.REFUND, FinancialType.EXPENSE), startDate, endDate
                    )
            ).orElse(BigDecimal.ZERO);

            // 3. Contagem Total
            Long count = appointmentRepository.countCompletedAppointments(
                    companyId, startDate, endDate
            );
            appointmentCount = count != null ? count : 0L;

            // 4. Gráficos Gerais
            dailyEvolution = getDailyEvolution(companyId, startDate, endDate);
            topServices = getTopServices(companyId, startDate, endDate);
        }

        BigDecimal balance = revenue.subtract(expenses);

        // Ticket Médio (Evita divisão por zero)
        BigDecimal averageTicket = BigDecimal.ZERO;
        if (appointmentCount > 0) {
            averageTicket = revenue.divide(BigDecimal.valueOf(appointmentCount), 2, RoundingMode.HALF_UP);
        }

        return DashboardResponse.builder()
                .revenue(revenue.doubleValue())
                .expenses(expenses.doubleValue())
                .balance(balance.doubleValue())
                .appointmentCount(appointmentCount.intValue())
                .averageTicket(averageTicket.doubleValue())
                .dailyEvolution(dailyEvolution)
                .topServices(topServices)
                .build();
    }

    /* =========================
       CHART DATA (ENDPOINT NOVO)
       ========================= */

    @Transactional(readOnly = true)
    public List<DashboardResponse.DailySummary> getRevenueChartData(String companyId) {
        LocalDateTime startDate = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        LocalDateTime endDate = LocalDate.now().atTime(23, 59, 59);

        String currentUserId = SecurityUtils.getCurrentUserId();
        User currentUser = userRepository.findById(currentUserId).orElseThrow();

        if (currentUser.getRole() == Role.PROFESSIONAL) {
            Professional prof = professionalRepository.findByUserId(currentUserId).orElseThrow();
            return getDailyEvolutionByProfessional(companyId, prof.getId(), startDate, endDate);
        } else {
            return getDailyEvolution(companyId, startDate, endDate);
        }
    }

    // --- HELPERS PARA O PROFISSIONAL ---

    private List<DashboardResponse.DailySummary> getDailyEvolutionByProfessional(
            String companyId, String profId, LocalDateTime start, LocalDateTime end) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM");
        // Mostra evolução das Comissões (EXPENSE)
        return financialRecordRepository
                .findDailyRevenueByProfessional(companyId, profId, List.of(FinancialType.EXPENSE), start, end)
                .stream()
                .map(row -> DashboardResponse.DailySummary.builder()
                        .date(((java.sql.Date) row[0]).toLocalDate().format(formatter))
                        .revenue(((BigDecimal) row[1]).doubleValue())
                        .appointments(((Long) row[2]).intValue())
                        .build())
                .toList();
    }

    private List<DashboardResponse.ServiceSummary> getTopServicesByProfessional(
            String companyId, String profId, LocalDateTime start, LocalDateTime end) {
        Pageable pageable = PageRequest.of(0, 5);
        return serviceRepository
                .findTopServicesByRevenueAndProfessional(companyId, profId, start, end, pageable)
                .stream()
                .map(row -> DashboardResponse.ServiceSummary.builder()
                        .serviceId((String) row[0])
                        .serviceName((String) row[1])
                        .revenue(((BigDecimal) row[2]).doubleValue())
                        .count(((Long) row[3]).intValue())
                        .build())
                .toList();
    }

    // --- HELPERS PARA O OWNER ---

    private List<DashboardResponse.DailySummary> getDailyEvolution(
            String companyId, LocalDateTime start, LocalDateTime end) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM");

        return financialRecordRepository
                .findDailyRevenue(companyId, List.of(FinancialType.APPOINTMENT), start, end)
                .stream()
                .map(row -> DashboardResponse.DailySummary.builder()
                        .date(((java.sql.Date) row[0]).toLocalDate().format(formatter))
                        .revenue(((BigDecimal) row[1]).doubleValue())
                        .appointments(((Long) row[2]).intValue())
                        .build())
                .toList();
    }

    private List<DashboardResponse.ServiceSummary> getTopServices(
            String companyId,
            LocalDateTime start,
            LocalDateTime end
    ) {

        int limit = 5;
        Pageable pageable = PageRequest.of(0, limit);

        return serviceRepository
                .findTopServicesByRevenue(companyId, start, end, pageable)
                .stream()
                .map(row -> DashboardResponse.ServiceSummary.builder()
                        .serviceId((String) row[0])
                        .serviceName((String) row[1])
                        .revenue(((BigDecimal) row[2]).doubleValue())
                        .count(((Long) row[3]).intValue())
                        .build())
                .toList();
    }

    // --- MAPPERS E CRUD AUXILIARES ---

    private FinancialResponse mapToResponse(FinancialRecord record) {
        return FinancialResponse.builder()
                .id(record.getId())
                .type(record.getType())
                .amount(record.getAmount().doubleValue())
                .description(record.getDescription())
                .referenceDate(record.getReferenceDate())
                .build();
    }

    public FinancialResponse getFinancialRecordById(String companyId, String recordId) {
        FinancialRecord record = financialRecordRepository.findById(recordId)
                .orElseThrow(() -> new BusinessException("Financial record not found"));
        if (!record.getCompany().getId().equals(companyId)) {
            throw new BusinessException("Access denied");
        }
        return mapToResponse(record);
    }

    public FinancialResponse updateFinancialRecord(String companyId, String recordId, FinancialRequest request) {
        FinancialRecord record = financialRecordRepository.findById(recordId)
                .orElseThrow(() -> new BusinessException("Financial record not found"));
        if (!record.getCompany().getId().equals(companyId)) {
            throw new BusinessException("Access denied");
        }
        record.setType(request.getType());
        record.setAmount(BigDecimal.valueOf(request.getAmount()));
        record.setDescription(request.getDescription());
        record.setPaymentMethod(request.getPaymentMethod());
        record.setReferenceDate(request.getReferenceDate());
        return mapToResponse(financialRecordRepository.save(record));
    }

    public void deleteFinancialRecord(String companyId, String recordId) {
        FinancialRecord record = financialRecordRepository.findById(recordId)
                .orElseThrow(() -> new BusinessException("Financial record not found"));
        if (!record.getCompany().getId().equals(companyId)) {
            throw new BusinessException("Access denied");
        }
        financialRecordRepository.delete(record);
    }
}
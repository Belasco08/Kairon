package com.kairon.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kairon.domain.entity.Company;
import com.kairon.domain.entity.User;
import com.kairon.domain.enums.Role;
import com.kairon.dto.request.AuthRequest;
import com.kairon.dto.request.RegisterRequest;
import com.kairon.dto.request.RefreshTokenRequest;
import com.kairon.dto.response.AuthResponse;
import com.kairon.dto.response.TokenRefreshResponse;
import com.kairon.exception.BusinessException;
import com.kairon.repository.CompanyRepository;
import com.kairon.repository.UserRepository;
import com.kairon.security.auth.UserDetailsImpl;
import com.kairon.security.auth.UserDetailsServiceImpl;
import com.kairon.security.jwt.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsServiceImpl userDetailsService;
    private final ObjectMapper objectMapper;

    /* =======================
       REGISTER
    ======================= */

    @Transactional
    public AuthResponse register(RegisterRequest request) {

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException("Email já cadastrado");
        }

        String slug = generateSlug(request.getCompanyName());

        if (companyRepository.existsBySlug(slug)) {
            throw new BusinessException("Nome da empresa já está em uso");
        }

        Company company = companyRepository.save(
                Company.builder()
                        .name(request.getCompanyName())
                        .slug(slug)
                        .businessType(request.getBusinessType())
                        .workHours(createDefaultWorkHours())
                        .timezone("America/Sao_Paulo")
                        .currency("BRL")
                        .slotDuration(30)
                        .bufferTime(10)
                        .isActive(true)
                        .isVerified(false)
                        .build()
        );

        User user = userRepository.save(
                User.builder()
                        .name(request.getName())
                        .email(request.getEmail())
                        .password(passwordEncoder.encode(request.getPassword()))
                        .phone(request.getPhone())
                        .role(Role.OWNER)
                        .company(company)
                        .isActive(true)
                        .createdAt(LocalDateTime.now())
                        .build()
        );

        return buildAuthResponse(user);
    }

    /* =======================
       LOGIN
    ======================= */

    public AuthResponse login(AuthRequest request) {

        // 1️⃣ Autentica e RECUPERA o principal real
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        UserDetailsImpl userDetails =
                (UserDetailsImpl) authentication.getPrincipal();

        // 2️⃣ Busca o usuário real
        User user = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new BusinessException("Usuário não encontrado"));

        // 3️⃣ Atualiza last login
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        // 4️⃣ Gera tokens A PARTIR DO USERDETAILS
        String token = jwtService.generateToken(userDetails);
        String refreshToken = jwtService.generateRefreshToken(userDetails);

        // 5️⃣ Retorna DTO LIMPO
        return AuthResponse.builder()
                .token(token)
                .refreshToken(refreshToken)
                .user(AuthResponse.UserResponse.builder()
                        .id(user.getId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .role(user.getRole().name())
                        .companyId(user.getCompany().getId())
                        .phone(user.getPhone())
                        .build())
                .build();
    }


    /* =======================
       REFRESH
    ======================= */

    @Transactional
    public TokenRefreshResponse refreshToken(RefreshTokenRequest request) {

        String email =
                jwtService.extractUsernameFromRefreshToken(
                        request.getRefreshToken()
                );

        UserDetailsImpl userDetails =
                (UserDetailsImpl) userDetailsService.loadUserByUsername(email);

        if (!jwtService.isRefreshTokenValid(
                request.getRefreshToken(),
                userDetails
        )) {
            throw new BusinessException("Refresh token inválido");
        }

        String newToken = jwtService.generateToken(userDetails);
        String newRefresh = jwtService.generateRefreshToken(userDetails);

        User user = userRepository.findById(userDetails.getId())
                .orElseThrow();

        user.setRefreshToken(newRefresh);

        return TokenRefreshResponse.builder()
                .token(newToken)
                .refreshToken(newRefresh)
                .build();
    }

    /* =======================
       LOGOUT
    ======================= */

    @Transactional
    public void logout(String email) {
        User user = userRepository.findActiveUserByEmail(email)
                .orElseThrow(() -> new BusinessException("Usuário não encontrado"));
        user.setRefreshToken(null);
    }

    /* =======================
       PROFILE
    ======================= */

    public AuthResponse getProfile(String email) {
        User user = userRepository.findActiveUserByEmail(email)
                .orElseThrow(() -> new BusinessException("Usuário não encontrado"));
        return buildAuthResponse(user, null, null);
    }

    /* =======================
       HELPERS
    ======================= */

    private AuthResponse buildAuthResponse(User user) {
        UserDetailsImpl userDetails =
                (UserDetailsImpl) userDetailsService
                        .loadUserByUsername(user.getEmail());

        String token = jwtService.generateToken(userDetails);
        String refresh = jwtService.generateRefreshToken(userDetails);

        user.setRefreshToken(refresh);

        return buildAuthResponse(user, token, refresh);
    }

    private AuthResponse buildAuthResponse(
            User user,
            String token,
            String refresh
    ) {
        return AuthResponse.builder()
                .user(AuthResponse.UserResponse.builder()
                        .id(user.getId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .role(user.getRole().name())
                        .companyId(user.getCompany().getId())
                        .phone(user.getPhone())
                        .build())
                .token(token)
                .refreshToken(refresh)
                .build();
    }

    /* =======================
       UTILS
    ======================= */

    private String generateSlug(String name) {
        return name.toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .replaceAll("\\s+", "-")
                .replaceAll("-+", "-");
    }

    private ObjectNode createDefaultWorkHours() {
        ObjectNode node = objectMapper.createObjectNode();
        node.set("monday", workDay("08:00", "18:00", true));
        node.set("tuesday", workDay("08:00", "18:00", true));
        node.set("wednesday", workDay("08:00", "18:00", true));
        node.set("thursday", workDay("08:00", "18:00", true));
        node.set("friday", workDay("08:00", "18:00", true));
        node.set("saturday", workDay("09:00", "13:00", true));
        node.set("sunday", workDay("09:00", "13:00", false));
        return node;
    }

    private ObjectNode workDay(String start, String end, boolean active) {
        ObjectNode node = objectMapper.createObjectNode();
        node.put("start", start);
        node.put("end", end);
        node.put("active", active);
        return node;
    }
}

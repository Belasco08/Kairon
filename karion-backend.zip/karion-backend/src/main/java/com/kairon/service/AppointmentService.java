package com.kairon.service;

import com.kairon.domain.entity.*;
import com.kairon.domain.enums.AppointmentStatus;
import com.kairon.domain.enums.Role;
import com.kairon.dto.request.*;
import com.kairon.dto.response.*;
import com.kairon.exception.BusinessException;
import com.kairon.repository.*;
import com.kairon.security.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final ProfessionalRepository professionalRepository;
    private final ServiceRepository serviceRepository;
    private final ClientRepository clientRepository;
    private final AppointmentItemRepository appointmentItemRepository;
    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;

    /* ================= CREATE ================= */

    @Transactional
    public AppointmentResponse createAppointment(String companyId, AppointmentRequest request) {

        // 1. Tenta identificar quem está logado (pode ser nulo se for rota pública)
        String currentUserId = null;
        try {
            // Se o SecurityUtils lançar erro quando não tem user, o catch pega.
            // Se ele retornar null, tratamos abaixo.
            currentUserId = SecurityUtils.getCurrentUserId();
        } catch (Exception e) {
            // Ignora: Significa que é um acesso público (cliente agendando pelo link)
        }

        String professionalIdToUse = request.getProfessionalId();

        // 2. Lógica Híbrida
        if (currentUserId != null) {
            // --- CENÁRIO: USUÁRIO LOGADO (App Interno) ---
            User currentUser = userRepository.findById(currentUserId).orElse(null);

            if (currentUser != null && currentUser.getRole() == Role.PROFESSIONAL) {
                // Se é Profissional, força o ID dele mesmo
                Professional selfProfile = professionalRepository.findByUserId(currentUserId)
                        .orElseThrow(() -> new BusinessException("Professional profile not found for this user"));

                professionalIdToUse = selfProfile.getId();
            }
            // Se é OWNER, mantém o request.getProfessionalId()
        }
        // --- CENÁRIO: PÚBLICO (Cliente clicou no link) ---
        // Se currentUserId for null, confiamos no professionalId que veio do front (request).

        // Validação final
        if (professionalIdToUse == null) {
            throw new BusinessException("Professional ID is required");
        }

        // 3. Busca o Profissional Definitivo
        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalIdToUse, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found in this company"));

        // 4. Busca Serviços
        List<Services> services = serviceRepository.findAllById(request.getServiceIds());

        if (services.isEmpty()) {
            throw new BusinessException("At least one service must be selected");
        }

        BigDecimal totalPrice = services.stream()
                .map(Services::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        int totalDuration = services.stream()
                .mapToInt(Services::getDuration)
                .sum();

        LocalDateTime start = request.getStartTime();
        LocalDateTime end = start.plusMinutes(totalDuration);

        // 5. Validação de Conflito de Horário
        if (appointmentRepository.existsByProfessionalAndDateOverlap(professional.getId(), start, end)) {
            throw new BusinessException("Este horário já foi preenchido por outro cliente.");
        }

        // 6. Cliente (Cria ou Busca pelo Telefone)
        Client client = clientRepository
                .findByPhoneAndCompanyId(request.getClientPhone(), companyId)
                .orElseGet(() -> createClient(companyId, request));

        // 7. Salva Agendamento
        Appointment appointment = Appointment.builder()
                .startTime(start)
                .endTime(end)
                .status(AppointmentStatus.PENDING)
                .totalPrice(totalPrice)
                .company(professional.getCompany())
                .professional(professional)
                .client(client)
                .timezone(companyId)
                .build();

        appointmentRepository.save(appointment);

        // 8. Salva Itens do Agendamento
        appointmentItemRepository.saveAll(
                services.stream()
                        .map(s -> AppointmentItem.builder()
                                .appointment(appointment)
                                .service(s)
                                .price(s.getPrice())
                                .duration(s.getDuration())
                                .build())
                        .toList()
        );

        return buildResponse(appointment);
    }

    /* ================= GET ================= */

    public AppointmentResponse getAppointment(String companyId, String appointmentId) {
        return appointmentRepository.findByIdAndCompanyId(appointmentId, companyId)
                .map(this::buildResponse)
                .orElseThrow(() -> new BusinessException("Appointment not found"));
    }

    @Transactional(readOnly = true)
    public List<AppointmentResponse> getAppointmentsByCompany(String companyId) {
        return appointmentRepository.findByCompanyId(companyId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByProfessional(String companyId, String professionalId) {
        return appointmentRepository.findByCompanyIdAndProfessionalId(companyId, professionalId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByClient(String companyId, String clientId) {
        return appointmentRepository.findByCompanyIdAndClientId(companyId, clientId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByDate(String companyId, LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = date.plusDays(1).atStartOfDay();

        return appointmentRepository.findByCompanyIdAndDateRange(companyId, start, end)
                .stream().map(this::buildResponse).toList();
    }

    /* ================= UPDATE ================= */

    @Transactional
    public AppointmentResponse updateAppointmentStatus(
            String companyId,
            String appointmentId,
            AppointmentStatusRequest request) {

        Appointment appointment = appointmentRepository
                .findByIdAndCompanyId(appointmentId, companyId)
                .orElseThrow(() -> new BusinessException("Appointment not found"));

        appointment.setStatus(request.getStatus());
        appointment.setCancellationReason(request.getReason());

        return buildResponse(appointment);
    }

    @Transactional
    public AppointmentResponse updateAppointmentServices(
            String companyId,
            String appointmentId,
            AppointmentUpdateRequest request) {

        Appointment appointment = appointmentRepository
                .findByIdAndCompanyId(appointmentId, companyId)
                .orElseThrow(() -> new BusinessException("Appointment not found"));

        appointmentItemRepository.deleteByAppointmentId(appointmentId);

        List<Services> services = serviceRepository.findAllById(request.getServiceIds());

        BigDecimal totalPrice = services.stream()
                .map(Services::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        appointment.setTotalPrice(totalPrice);

        appointmentItemRepository.saveAll(
                services.stream()
                        .map(s -> AppointmentItem.builder()
                                .id(UUID.randomUUID().toString())
                                .appointment(appointment)
                                .service(s)
                                .price(s.getPrice())
                                .duration(s.getDuration())
                                .build())
                        .toList()
        );

        return buildResponse(appointment);
    }

    /* ================= AVAILABILITY ================= */

    public AvailabilityResponse getAvailability(
            String companyId,
            AppointmentAvailabilityRequest request) {

        return AvailabilityResponse.builder()
                .professionalId(request.getProfessionalId())
                .date(request.getDate().toString())
                .availableSlots(List.of("08:00", "09:00", "10:00"))
                .build();
    }

    /* ================= HELPERS ================= */

    private Client createClient(String companyId, AppointmentRequest request) {
        // É melhor buscar a empresa para garantir que ela existe e evitar Foreign Key Error
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new BusinessException("Company not found"));

        return clientRepository.save(
                Client.builder()
                        // REMOVIDO: .id(UUID.randomUUID().toString())
                        // MOTIVO: O Hibernate gera automático. Se passar manual, dá erro.
                        .name(request.getClientName())
                        .phone(request.getClientPhone())
                        .email(request.getClientEmail())
                        .company(company)
                        .build()
        );
    }

    private AppointmentResponse buildResponse(Appointment appointment) {
        if (appointment == null) return null;

        return AppointmentResponse.builder()
                .id(appointment.getId())
                .startTime(appointment.getStartTime())
                .endTime(appointment.getEndTime())
                // CORREÇÃO 1: Converter Enum para String
                .status(appointment.getStatus().name())
                .totalPrice(appointment.getTotalPrice().doubleValue())
                .notes(appointment.getNotes())

                // --- MAPEAMENTO DO CLIENTE ---
                .clientName(appointment.getClient() != null ? appointment.getClient().getName() : "Cliente Desconhecido")
                .clientPhone(appointment.getClient() != null ? appointment.getClient().getPhone() : "")

                // --- MAPEAMENTO DO PROFISSIONAL ---
                .professionalName(appointment.getProfessional() != null ? appointment.getProfessional().getName() : "Sem Profissional")

                // --- MAPEAMENTO DOS SERVIÇOS ---
                .services(
                        appointment.getAppointmentServices().stream()
                                .map(i -> AppointmentServiceResponse.builder()
                                        .id(i.getService().getId())
                                        .name(i.getService().getName())
                                        // CORREÇÃO 2: Converter BigDecimal para Double
                                        .price(i.getPrice().doubleValue())
                                        .duration(i.getDuration())
                                        .build())
                                .collect(Collectors.toList())
                )
                .build();
    }
}

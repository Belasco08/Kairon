package com.kairon.service;

import com.kairon.domain.entity.*;
import com.kairon.domain.enums.AppointmentStatus;
import com.kairon.domain.enums.FinancialType; // ✅ Novo Enum
import com.kairon.domain.enums.Role;
import com.kairon.dto.request.*;
import com.kairon.dto.response.*;
import com.kairon.exception.BusinessException;
import com.kairon.repository.*;
import com.kairon.security.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final ProfessionalRepository professionalRepository;
    private final ServiceRepository serviceRepository;
    private final ClientRepository clientRepository;
    private final AppointmentItemRepository appointmentItemRepository;
    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;

    // ✅ Injetando o Repositório Financeiro correto
    private final FinancialRecordRepository financialRecordRepository;

    /* ================= CREATE ================= */

    @Transactional
    public AppointmentResponse createAppointment(String companyId, AppointmentRequest request) {

        // 1. Tenta identificar quem está logado (pode ser nulo se for rota pública)
        String currentUserId = null;
        try {
            currentUserId = SecurityUtils.getCurrentUserId();
        } catch (Exception e) {
            // Ignora: Acesso público
        }

        String professionalIdToUse = request.getProfessionalId();

        // 2. Lógica Híbrida
        if (currentUserId != null) {
            User currentUser = userRepository.findById(currentUserId).orElse(null);

            if (currentUser != null && currentUser.getRole() == Role.PROFESSIONAL) {
                // Se é Profissional, força o ID dele mesmo
                Professional selfProfile = professionalRepository.findByUserId(currentUserId)
                        .orElseThrow(() -> new BusinessException("Professional profile not found for this user"));

                professionalIdToUse = selfProfile.getId();
            }
        }

        // Validação final
        if (professionalIdToUse == null) {
            throw new BusinessException("Professional ID is required");
        }

        // 3. Busca o Profissional Definitivo
        Professional professional = professionalRepository
                .findByIdAndCompanyId(professionalIdToUse, companyId)
                .orElseThrow(() -> new BusinessException("Professional not found in this company"));

        // 4. Busca Serviços
        List<Services> services = serviceRepository.findAllById(request.getServiceIds());

        if (services.isEmpty()) {
            throw new BusinessException("At least one service must be selected");
        }

        BigDecimal totalPrice = services.stream()
                .map(Services::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        int totalDuration = services.stream()
                .mapToInt(Services::getDuration)
                .sum();

        LocalDateTime start = request.getStartTime();
        LocalDateTime end = start.plusMinutes(totalDuration);

        // 5. Validação de Conflito de Horário
        if (appointmentRepository.existsByProfessionalAndDateOverlap(professional.getId(), start, end)) {
            throw new BusinessException("Este horário já foi preenchido por outro cliente.");
        }

        // 6. Cliente (Cria ou Busca pelo Telefone)
        Client client = clientRepository
                .findByPhoneAndCompanyId(request.getClientPhone(), companyId)
                .orElseGet(() -> createClient(companyId, request));

        // 7. Salva Agendamento
        Appointment appointment = Appointment.builder()
                .startTime(start)
                .endTime(end)
                .status(AppointmentStatus.PENDING)
                .totalPrice(totalPrice)
                .company(professional.getCompany())
                .professional(professional)
                .client(client)
                .timezone(companyId)
                .build();

        appointmentRepository.save(appointment);

        // 8. Salva Itens do Agendamento
        appointmentItemRepository.saveAll(
                services.stream()
                        .map(s -> AppointmentItem.builder()
                                .appointment(appointment)
                                .service(s)
                                .price(s.getPrice())
                                .duration(s.getDuration())
                                .build())
                        .toList()
        );

        return buildResponse(appointment);
    }

    /* ================= GET ================= */

    @Transactional(readOnly = true)
    public AppointmentResponse getAppointment(String companyId, String appointmentId) {
        return appointmentRepository.findByIdAndCompanyId(appointmentId, companyId)
                .map(this::buildResponse)
                .orElseThrow(() -> new BusinessException("Appointment not found"));
    }

    @Transactional(readOnly = true)
    // 👇 Novo parâmetro: filterProfessionalId
    public List<AppointmentResponse> listAppointments(String companyId, LocalDate date, String filterProfessionalId) {
        if (date == null) {
            date = LocalDate.now();
        }

        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(23, 59, 59);

        String currentUserId = SecurityUtils.getCurrentUserId();
        User currentUser = userRepository.findById(currentUserId).orElseThrow();

        // Lógica de Segregação
        if (currentUser.getRole() == Role.PROFESSIONAL) {
            // 🔒 PROFISSIONAL: Sempre vê APENAS o dele (Ignora filtro)
            Professional prof = professionalRepository.findByUserId(currentUserId)
                    .orElseThrow(() -> new BusinessException("Perfil profissional não encontrado"));

            return appointmentRepository.findByCompanyAndProfessionalAndDateRange(
                    companyId, prof.getId(), startOfDay, endOfDay
            ).stream().map(this::buildResponse).collect(Collectors.toList());

        } else {
            // 🔓 OWNER: Lógica de Filtro
            if (filterProfessionalId != null && !filterProfessionalId.isEmpty()) {
                // Se o Owner mandou um ID (clicou em "Meus" ou filtrou um funcionário)
                return appointmentRepository.findByCompanyAndProfessionalAndDateRange(
                        companyId, filterProfessionalId, startOfDay, endOfDay
                ).stream().map(this::buildResponse).collect(Collectors.toList());
            } else {
                // Se não mandou ID (clicou em "Todos")
                return appointmentRepository.findByCompanyAndDateRange(
                        companyId, startOfDay, endOfDay
                ).stream().map(this::buildResponse).collect(Collectors.toList());
            }
        }
    }


    public List<AppointmentResponse> getAppointmentsByProfessional(String companyId, String professionalId) {
        return appointmentRepository.findByCompanyIdAndProfessionalId(companyId, professionalId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByClient(String companyId, String clientId) {
        return appointmentRepository.findByCompanyIdAndClientId(companyId, clientId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByDate(String companyId, LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = date.plusDays(1).atStartOfDay();

        return appointmentRepository.findByCompanyIdAndDateRange(companyId, start, end)
                .stream().map(this::buildResponse).toList();
    }

    /* ================= UPDATE ================= */

    @Transactional
    public AppointmentResponse updateAppointmentStatus(
            String companyId,
            String appointmentId,
            AppointmentStatusRequest request) {

        Appointment appointment = appointmentRepository
                .findByIdAndCompanyId(appointmentId, companyId)
                .orElseThrow(() -> new BusinessException("Appointment not found"));

        if (appointment.getStatus() == AppointmentStatus.COMPLETED && request.getStatus() == AppointmentStatus.COMPLETED) {
            return buildResponse(appointment);
        }

        appointment.setStatus(request.getStatus());
        appointment.setCancellationReason(request.getReason());

        // 👇 LÓGICA FINANCEIRA INTELIGENTE
        if (request.getStatus() == AppointmentStatus.COMPLETED) {
            processFinancialSplit(appointment);
        }

        appointmentRepository.save(appointment);
        return buildResponse(appointment);
    }

    @Transactional
    public AppointmentResponse updateAppointmentServices(
            String companyId,
            String appointmentId,
            AppointmentUpdateRequest request) {

        Appointment appointment = appointmentRepository
                .findByIdAndCompanyId(appointmentId, companyId)
                .orElseThrow(() -> new BusinessException("Appointment not found"));

        appointmentItemRepository.deleteByAppointmentId(appointmentId);

        List<Services> services = serviceRepository.findAllById(request.getServiceIds());

        BigDecimal totalPrice = services.stream()
                .map(Services::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        appointment.setTotalPrice(totalPrice);

        appointmentItemRepository.saveAll(
                services.stream()
                        .map(s -> AppointmentItem.builder()
                                .id(UUID.randomUUID().toString())
                                .appointment(appointment)
                                .service(s)
                                .price(s.getPrice())
                                .duration(s.getDuration())
                                .build())
                        .toList()
        );

        return buildResponse(appointment);
    }

    // Em AppointmentService.java

    // ... dentro de AppointmentService.java

    private void processFinancialSplit(Appointment appointment) {
        Professional prof = appointment.getProfessional();
        BigDecimal totalAmount = appointment.getTotalPrice();

        System.out.println(">>> PROCESSANDO FINANCEIRO: " + appointment.getId());
        System.out.println(">>> Valor Total: " + totalAmount);
        System.out.println(">>> Profissional: " + prof.getName() + " | % Comissão: " + prof.getCommissionPercentage());

        // 1. Cria Registro de RECEITA TOTAL (Entrada para a Empresa)
        FinancialRecord incomeRecord = FinancialRecord.builder()
                .type(FinancialType.APPOINTMENT)
                .amount(totalAmount)
                .description("Serviço: " + appointment.getClient().getName())
                .appointment(appointment)
                .company(appointment.getCompany())
                .professional(prof)
                .paymentMethod("DINHEIRO")
                .referenceDate(LocalDateTime.now())
                .createdAt(LocalDateTime.now())
                .build();
        financialRecordRepository.save(incomeRecord);

        // 2. Cria Registro de COMISSÃO (Despesa para Empresa / Receita para Profissional)

        // TRUQUE: Se estiver Nulo, assume 50% só para não ficar zerado nos seus testes
        // (Em produção, o ideal é ser 0 e obrigar o cadastro correto)
        BigDecimal commissionRate = prof.getCommissionPercentage();
        if (commissionRate == null) {
            System.out.println(">>> ALERTA: Profissional sem porcentagem. Usando 50% padrão para teste.");
            commissionRate = new BigDecimal("50.00");
        }

        if (commissionRate.compareTo(BigDecimal.ZERO) > 0) {

            BigDecimal commissionAmount = totalAmount
                    .multiply(commissionRate)
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

            System.out.println(">>> Gerando Comissão de: " + commissionAmount);

            FinancialRecord commissionRecord = FinancialRecord.builder()
                    .type(FinancialType.EXPENSE) // Importante ser EXPENSE
                    .amount(commissionAmount)
                    .description("Comissão - " + prof.getName())
                    .appointment(appointment)
                    .company(appointment.getCompany())
                    .professional(prof) // VINCULA AO PROFISSIONAL
                    .paymentMethod("INTERNO")
                    .referenceDate(LocalDateTime.now())
                    .createdAt(LocalDateTime.now())
                    .build();

            financialRecordRepository.save(commissionRecord);
        } else {
            System.out.println(">>> NENHUMA COMISSÃO GERADA (Porcentagem é 0)");
        }
    }

    /* ================= AVAILABILITY ================= */

    public AvailabilityResponse getAvailability(
            String companyId,
            AppointmentAvailabilityRequest request) {

        return AvailabilityResponse.builder()
                .professionalId(request.getProfessionalId())
                .date(request.getDate().toString())
                .availableSlots(List.of("08:00", "09:00", "10:00"))
                .build();
    }

    /* ================= HELPERS ================= */

    // 👇 MÉTODO PRIVADO PARA CRIAR O REGISTRO FINANCEIRO (FinancialRecord)
    private void createFinancialRecordFromAppointment(Appointment appointment) {
        FinancialRecord record = FinancialRecord.builder()
                .type(FinancialType.APPOINTMENT) // Usa o Enum correto
                .amount(appointment.getTotalPrice())
                .description("Serviço: " + appointment.getClient().getName())
                .appointment(appointment)
                .company(appointment.getCompany())
                .professional(appointment.getProfessional()) // ✅ Essencial para o Dashboard do Profissional
                .paymentMethod("DINHEIRO") // Pode evoluir para vir do request depois
                .referenceDate(LocalDateTime.now())
                .createdAt(LocalDateTime.now())
                .build();

        financialRecordRepository.save(record);
    }

    private Client createClient(String companyId, AppointmentRequest request) {
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new BusinessException("Company not found"));

        return clientRepository.save(
                Client.builder()
                        .name(request.getClientName())
                        .phone(request.getClientPhone())
                        .email(request.getClientEmail())
                        .company(company)
                        .build()
        );
    }

    private AppointmentResponse buildResponse(Appointment appointment) {
        if (appointment == null) return null;

        return AppointmentResponse.builder()
                .id(appointment.getId())
                .startTime(appointment.getStartTime())
                .endTime(appointment.getEndTime())
                .status(appointment.getStatus().name())
                .totalPrice(appointment.getTotalPrice().doubleValue())
                .clientName(appointment.getClient().getName())
                .clientPhone(appointment.getClient().getPhone())
                .professionalName(appointment.getProfessional().getName())
                .services(
                        appointment.getAppointmentServices().stream()
                                .map(i -> AppointmentServiceResponse.builder()
                                        .id(i.getService().getId())
                                        .name(i.getService().getName())
                                        .price(i.getPrice().doubleValue())
                                        .duration(i.getDuration())
                                        .build())
                                .collect(Collectors.toList())
                )
                .build();
    }
}
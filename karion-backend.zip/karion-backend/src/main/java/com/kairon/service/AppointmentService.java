package com.kairon.service;

import com.kairon.domain.entity.*;
import com.kairon.domain.enums.AppointmentStatus;
import com.kairon.dto.request.*;
import com.kairon.dto.response.*;
import com.kairon.exception.BusinessException;
import com.kairon.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final ProfessionalRepository professionalRepository;
    private final ServiceRepository serviceRepository;
    private final ClientRepository clientRepository;
    private final AppointmentItemRepository appointmentItemRepository;

    /* ================= CREATE ================= */

    @Transactional
    public AppointmentResponse createAppointment(String companyId, AppointmentRequest request) {

        Professional professional = professionalRepository
                .findByIdAndCompanyId(request.getProfessionalId(), companyId)
                .orElseThrow(() -> new BusinessException("Professional not found"));

        List<Services> services = serviceRepository.findAllById(request.getServiceIds());

        BigDecimal totalPrice = services.stream()
                .map(Services::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        int totalDuration = services.stream()
                .mapToInt(Services::getDuration)
                .sum();

        LocalDateTime start = request.getStartTime();
        LocalDateTime end = start.plusMinutes(totalDuration);

        Client client = clientRepository
                .findByPhoneAndCompanyId(request.getClientPhone(), companyId)
                .orElseGet(() -> createClient(companyId, request));

        Appointment appointment = Appointment.builder()
                .id(UUID.randomUUID().toString())
                .startTime(start)
                .endTime(end)
                .status(AppointmentStatus.PENDING)
                .totalPrice(totalPrice)
                .company(professional.getCompany())
                .professional(professional)
                .client(client)
                .build();

        appointmentRepository.save(appointment);

        appointmentItemRepository.saveAll(
                services.stream()
                        .map(s -> AppointmentItem.builder()
                                .id(UUID.randomUUID().toString())
                                .appointment(appointment)
                                .service(s)
                                .price(s.getPrice())
                                .duration(s.getDuration())
                                .build())
                        .toList()
        );

        return buildResponse(appointment);
    }

    /* ================= GET ================= */

    public AppointmentResponse getAppointment(String companyId, String appointmentId) {
        return appointmentRepository.findByIdAndCompanyId(appointmentId, companyId)
                .map(this::buildResponse)
                .orElseThrow(() -> new BusinessException("Appointment not found"));
    }

    public List<AppointmentResponse> getAppointmentsByCompany(String companyId) {
        return appointmentRepository.findByCompanyId(companyId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByProfessional(String companyId, String professionalId) {
        return appointmentRepository.findByCompanyIdAndProfessionalId(companyId, professionalId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByClient(String companyId, String clientId) {
        return appointmentRepository.findByCompanyIdAndClientId(companyId, clientId)
                .stream().map(this::buildResponse).toList();
    }

    public List<AppointmentResponse> getAppointmentsByDate(String companyId, LocalDate date) {
        LocalDateTime start = date.atStartOfDay();
        LocalDateTime end = date.plusDays(1).atStartOfDay();

        return appointmentRepository.findByCompanyIdAndDateRange(companyId, start, end)
                .stream().map(this::buildResponse).toList();
    }

    /* ================= UPDATE ================= */

    @Transactional
    public AppointmentResponse updateAppointmentStatus(
            String companyId,
            String appointmentId,
            AppointmentStatusRequest request) {

        Appointment appointment = appointmentRepository
                .findByIdAndCompanyId(appointmentId, companyId)
                .orElseThrow(() -> new BusinessException("Appointment not found"));

        appointment.setStatus(request.getStatus());
        appointment.setCancellationReason(request.getReason());

        return buildResponse(appointment);
    }

    @Transactional
    public AppointmentResponse updateAppointmentServices(
            String companyId,
            String appointmentId,
            AppointmentUpdateRequest request) {

        Appointment appointment = appointmentRepository
                .findByIdAndCompanyId(appointmentId, companyId)
                .orElseThrow(() -> new BusinessException("Appointment not found"));

        appointmentItemRepository.deleteByAppointmentId(appointmentId);

        List<Services> services = serviceRepository.findAllById(request.getServiceIds());

        BigDecimal totalPrice = services.stream()
                .map(Services::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        appointment.setTotalPrice(totalPrice);

        appointmentItemRepository.saveAll(
                services.stream()
                        .map(s -> AppointmentItem.builder()
                                .id(UUID.randomUUID().toString())
                                .appointment(appointment)
                                .service(s)
                                .price(s.getPrice())
                                .duration(s.getDuration())
                                .build())
                        .toList()
        );

        return buildResponse(appointment);
    }

    /* ================= AVAILABILITY ================= */

    public AvailabilityResponse getAvailability(
            String companyId,
            AppointmentAvailabilityRequest request) {

        return AvailabilityResponse.builder()
                .professionalId(request.getProfessionalId())
                .date(request.getDate().toString())
                .availableSlots(List.of("08:00", "09:00", "10:00"))
                .build();
    }

    /* ================= HELPERS ================= */

    private Client createClient(String companyId, AppointmentRequest request) {
        Company company = new Company();
        company.setId(companyId);

        return clientRepository.save(
                Client.builder()
                        .id(UUID.randomUUID().toString())
                        .name(request.getClientName())
                        .phone(request.getClientPhone())
                        .email(request.getClientEmail())
                        .company(company)
                        .build()
        );
    }

    private AppointmentResponse buildResponse(Appointment appointment) {
        return AppointmentResponse.builder()
                .id(appointment.getId())
                .startTime(appointment.getStartTime())
                .endTime(appointment.getEndTime())
                .status(appointment.getStatus().name())
                .totalPrice(appointment.getTotalPrice().doubleValue())
                .services(
                        appointment.getAppointmentServices().stream()
                                .map(i -> AppointmentServiceResponse.builder()
                                        .id(i.getService().getId())
                                        .name(i.getService().getName())
                                        .price(i.getPrice().doubleValue())
                                        .duration(i.getDuration())
                                        .build())
                                .toList()
                )
                .build();
    }
}

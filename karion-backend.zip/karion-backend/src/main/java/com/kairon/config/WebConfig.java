package com.kairon.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Mapeia a URL "/api/uploads/**" para a pasta física "./uploads/" na raiz do projeto
        registry.addResourceHandler("/api/uploads/**")
                .addResourceLocations("file:./uploads/");
    }
}
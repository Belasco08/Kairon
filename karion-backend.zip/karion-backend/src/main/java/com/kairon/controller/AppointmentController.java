package com.kairon.controller;

import com.kairon.dto.request.*;
import com.kairon.dto.response.AppointmentResponse;
import com.kairon.dto.response.AvailabilityResponse;
import com.kairon.security.util.SecurityUtils;
import com.kairon.service.AppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/appointments")
@RequiredArgsConstructor
@Tag(name = "Appointments", description = "Appointment management endpoints")
public class AppointmentController {

    private final AppointmentService appointmentService;

    @PostMapping
    @Operation(summary = "Create a new appointment")
    public ResponseEntity<AppointmentResponse> createAppointment(
            @Valid @RequestBody AppointmentRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        AppointmentResponse response =
                appointmentService.createAppointment(companyId, request);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get appointment by ID")
    public ResponseEntity<AppointmentResponse> getAppointment(
            @PathVariable String id) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        AppointmentResponse response =
                appointmentService.getAppointment(companyId, id);

        return ResponseEntity.ok(response);
    }

    @GetMapping
    @Operation(summary = "Get all appointments for company")
    public ResponseEntity<List<AppointmentResponse>> getAppointments() {

        String companyId = SecurityUtils.getCurrentCompanyId();

        List<AppointmentResponse> responses =
                appointmentService.getAppointmentsByCompany(companyId);

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/professional/{professionalId}")
    @Operation(summary = "Get appointments by professional")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByProfessional(
            @PathVariable String professionalId) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        List<AppointmentResponse> responses =
                appointmentService.getAppointmentsByProfessional(companyId, professionalId);

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/client/{clientId}")
    @Operation(summary = "Get appointments by client")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByClient(
            @PathVariable String clientId) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        List<AppointmentResponse> responses =
                appointmentService.getAppointmentsByClient(companyId, clientId);

        return ResponseEntity.ok(responses);
    }

    @GetMapping("/date/{date}")
    @Operation(summary = "Get appointments by date")
    public ResponseEntity<List<AppointmentResponse>> getAppointmentsByDate(
            @PathVariable
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        List<AppointmentResponse> responses =
                appointmentService.getAppointmentsByDate(companyId, date);

        return ResponseEntity.ok(responses);
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "Update appointment status")
    public ResponseEntity<AppointmentResponse> updateAppointmentStatus(
            @PathVariable String id,
            @Valid @RequestBody AppointmentStatusRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        AppointmentResponse response =
                appointmentService.updateAppointmentStatus(companyId, id, request);

        return ResponseEntity.ok(response);
    }

    @PutMapping("/{id}/services")
    @Operation(summary = "Update appointment services")
    public ResponseEntity<AppointmentResponse> updateAppointmentServices(
            @PathVariable String id,
            @Valid @RequestBody AppointmentUpdateRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        AppointmentResponse response =
                appointmentService.updateAppointmentServices(companyId, id, request);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/availability")
    @Operation(summary = "Check availability for appointments")
    public ResponseEntity<AvailabilityResponse> checkAvailability(
            @Valid @RequestBody AppointmentAvailabilityRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        AvailabilityResponse response =
                appointmentService.getAvailability(companyId, request);

        return ResponseEntity.ok(response);
    }
}

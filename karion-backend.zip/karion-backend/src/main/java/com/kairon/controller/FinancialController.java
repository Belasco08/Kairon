package com.kairon.controller;

import com.kairon.dto.request.DashboardRequest;
import com.kairon.dto.request.FinancialFilterRequest;
import com.kairon.dto.request.FinancialRequest;
import com.kairon.dto.response.DashboardResponse;
import com.kairon.dto.response.FinancialResponse;
import com.kairon.security.util.SecurityUtils;
import com.kairon.service.FinancialService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/finance")
@RequiredArgsConstructor
@Tag(name = "Financial", description = "Financial management endpoints")
public class FinancialController {

    private final FinancialService financialService;

    @GetMapping("/records")
    @PreAuthorize("hasRole('OWNER')")
    @Operation(summary = "Get financial records with filters")
    public ResponseEntity<Page<FinancialResponse>> getFinancialRecords(
            @Valid @ModelAttribute FinancialFilterRequest filter) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        return ResponseEntity.ok(
                financialService.getFinancialRecords(companyId, filter)
        );
    }

    @GetMapping("/records/{recordId}")
    @PreAuthorize("hasRole('OWNER')")
    @Operation(summary = "Get financial record by ID")
    public ResponseEntity<FinancialResponse> getFinancialRecordById(
            @PathVariable String recordId) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        return ResponseEntity.ok(
                financialService.getFinancialRecordById(companyId, recordId)
        );
    }

    @PostMapping("/records")
    @PreAuthorize("hasRole('OWNER')")
    @Operation(summary = "Create a new financial record")
    public ResponseEntity<FinancialResponse> createFinancialRecord(
            @Valid @RequestBody FinancialRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        FinancialResponse record =
                financialService.createFinancialRecord(companyId, request);

        return ResponseEntity.status(HttpStatus.CREATED).body(record);
    }

    @PutMapping("/records/{recordId}")
    @PreAuthorize("hasRole('OWNER')")
    @Operation(summary = "Update a financial record")
    public ResponseEntity<FinancialResponse> updateFinancialRecord(
            @PathVariable String recordId,
            @Valid @RequestBody FinancialRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        return ResponseEntity.ok(
                financialService.updateFinancialRecord(companyId, recordId, request)
        );
    }

    @DeleteMapping("/records/{recordId}")
    @PreAuthorize("hasRole('OWNER')")
    @Operation(summary = "Delete a financial record")
    public ResponseEntity<Void> deleteFinancialRecord(
            @PathVariable String recordId) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        financialService.deleteFinancialRecord(companyId, recordId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('OWNER')")
    @Operation(summary = "Get financial dashboard data")
    public ResponseEntity<DashboardResponse> getDashboard(
            @Valid @ModelAttribute DashboardRequest request) {

        String companyId = SecurityUtils.getCurrentCompanyId();

        return ResponseEntity.ok(
                financialService.getDashboard(companyId, request)
        );
    }
}

package com.kairon.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalTime;
import java.util.Map;

@Data
public class CompanySettingsRequest {

    @NotBlank(message = "Company name is required")
    @Size(min = 3, max = 100, message = "Company name must be between 3 and 100 characters")
    private String name;

    @NotBlank(message = "Business type is required")
    private String businessType;

    @NotNull(message = "Work hours are required")
    private Map<String, WorkHours> workHours;

    @NotNull(message = "Slot duration is required")
    private Integer slotDuration; // em minutos

    @NotNull(message = "Buffer time is required")
    private Integer bufferTime; // em minutos

    @NotBlank(message = "Currency is required")
    @Size(min = 3, max = 3, message = "Currency must be 3 characters (ex: BRL, USD)")
    private String currency;

    private String logoUrl;
    private String website;

    @Data
    public static class WorkHours {
        @NotNull(message = "Start time is required")
        @JsonFormat(pattern = "HH:mm")
        private LocalTime start;

        @NotNull(message = "End time is required")
        @JsonFormat(pattern = "HH:mm")
        private LocalTime end;

        @NotNull(message = "Active status is required")
        private Boolean active;
    }
}
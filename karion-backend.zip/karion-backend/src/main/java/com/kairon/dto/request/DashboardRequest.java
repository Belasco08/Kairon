package com.kairon.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class DashboardRequest {

    @NotBlank(message = "Period is required")
    private String period; // day, week, month, year

    private LocalDateTime startDate;
    private LocalDateTime endDate;
}
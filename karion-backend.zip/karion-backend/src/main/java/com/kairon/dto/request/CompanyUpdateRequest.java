package com.kairon.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class CompanyUpdateRequest {

    @NotBlank(message = "Company name is required")
    private String name;

    @NotBlank(message = "Business type is required")
    private String businessType;

    @NotBlank(message = "Timezone is required")
    @Pattern(regexp = "^[A-Za-z_]+/[A-Za-z_]+$",
            message = "Timezone must be in format 'Region/City'")
    private String timezone;

    private String logoUrl;

    private String website;

    @NotNull(message = "Slot duration is required")
    private Integer slotDuration;

    @NotNull(message = "Buffer time is required")
    private Integer bufferTime;

    @NotBlank(message = "Currency is required")
    @Pattern(regexp = "^[A-Z]{3}$", message = "Currency must be 3 uppercase letters")
    private String currency;
}
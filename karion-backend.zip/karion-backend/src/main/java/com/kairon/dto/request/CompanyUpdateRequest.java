package com.kairon.dto.request;

import jakarta.validation.constraints.Size;
import lombok.Data;
import java.util.Map;

@Data
public class CompanyUpdateRequest {

    // --- Campos Principais (Enviados pelo App) ---

    @Size(min = 2, max = 100, message = "Company name must be between 2 and 100 characters")
    private String name;

    private String phone;
    private String email;
    private String description;

    // --- Endereço ---
    private String address;
    private String city;
    private String state;
    private String zipCode;

    // --- Configurações Web/Logo ---
    private String website;
    private String logoUrl; // Geralmente atualizado via endpoint separado, mas mantido aqui

    // --- Campos JSON (Mapeados como Map para o Backend processar) ---
    private Map<String, Object> settings;       // Regras de agendamento
    private Map<String, Object> businessHours;  // Horários de funcionamento

    // --- Campos de Regra de Negócio (Opcionais nesta tela) ---
    // Removi @NotBlank para não quebrar a edição se o frontend não enviar estes dados

    private String businessType;

    // Pattern removido temporariamente ou mantido apenas se o campo não for nulo
    private String timezone;

    private Integer slotDuration;

    private Integer bufferTime;

    private String currency;
}
package com.kairon.dto.response;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentResponse {

    private String id;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    private Double totalPrice;

    private ProfessionalResponse professional;
    private ClientResponse client;

    // ⚠️ APENAS ISSO
    private List<AppointmentServiceResponse> services;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
